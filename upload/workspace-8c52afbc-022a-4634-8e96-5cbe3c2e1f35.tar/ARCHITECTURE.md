# SPACE ARCHER — Архитектура проекта

> Неоновая космическая стрелковая аркада. Игрок управляет луком в центре экрана,
> отбиваясь от волн врагов. Режимы: обычный (волны) и бой с боссом «Омега».

## Технологический стек

- **Next.js 16** (App Router) + **TypeScript** — фронтенд и API
- **Prisma ORM** + **SQLite** — база данных (пользователи, прогресс, рекорды)
- **bcryptjs** — хеширование паролей
- **Canvas 2D API** — игровой рендеринг (все в `src/game/`)
- **Tailwind CSS 4** + **shadcn/ui** — UI компоненты
- **Web Audio API** — звуковые эффекты и музыка (через `AudioContext` + `HTMLAudioElement`)

## Структура каталогов

```
src/
├── app/                        # Next.js App Router
│   ├── api/                    # API маршруты (server-side)
│   │   ├── auth/               # Аутентификация: register, login, logout, me
│   │   ├── user/progress/      # Чтение/запись прогресса пользователя
│   │   ├── leaderboard/        # Таблица лидеров (GET/POST)
│   │   └── admin/users/        # Админ-панель: список, редактирование, удаление
│   ├── globals.css             # Глобальные стили + неоновая тема + анимации
│   ├── layout.tsx              # Root layout (шрифты Orbitron + Rajdhani)
│   └── page.tsx                # Главная страница → динамический импорт GameApp
│
├── components/
│   ├── GameApp.tsx             # Обёртка: AuthProvider + QueryClient + Index
│   └── ui/                     # shadcn/ui компоненты (кнопки, диалоги, и т.д.)
│
├── contexts/
│   └── AuthContext.tsx         # Контекст аутентификации (fetch /api/auth/me)
│
├── game/                       # ===== ИГРОВОЙ ДВИЖОК (Canvas 2D) =====
│   ├── config.ts               # Вся конфигурация: статы игрока, врагов, улучшения
│   ├── enemies.ts              # Типы врагов, создание, отрисовка (drawShape)
│   ├── gameLogic.ts            # Игровая логика: спавн, движение, столкновения
│   ├── gameRenderer.ts         # Рендеринг: фон, частицы, враги, снаряды, босс
│   ├── useGameLoop.ts          # React-хук: игровой цикл (requestAnimationFrame)
│   ├── GameCanvas.tsx          # React-компонент: canvas + инициализация состояния
│   └── audioManager.ts         # Звук: SFX через Web Audio API, музыка через <audio>
│
├── lib/
│   ├── db.ts                   # Prisma Client (singleton)
│   ├── auth.ts                 # Хеширование паролей, session-токены (HMAC-SHA256)
│   ├── api.ts                  # Клиентские API-функции (fetch обёртки)
│   └── utils.ts                # Утилиты (cn для Tailwind)
│
├── pages/                      # ===== ЭКРАНЫ ИГРЫ =====
│   ├── Index.tsx               # Главный оркестратор: навигация между экранами
│   ├── AuthScreen.tsx          # Экран авторизации (вход/регистрация)
│   ├── MenuScreen.tsx          # Главное меню (с анимированным фоном)
│   ├── GameScreen.tsx          # Игровой экран (HUD + GameCanvas)
│   ├── UpgradesScreen.tsx      # Дерево прокачки + вкладка характеристик
│   ├── LeaderboardScreen.tsx   # Таблица лидеров
│   ├── ProfileScreen.tsx       # Профиль пилота (статистика + достижения)
│   ├── AdminScreen.tsx         # Админ-панель (управление пользователями)
│   └── InfoScreens.tsx         # Настройки + Справка (типы врагов)
│
└── types/
    └── game.ts                 # TypeScript типы: GameProgress, GameSettings

prisma/
└── schema.prisma               # Схема БД: User, LeaderboardEntry
```

## Поток данных

### Аутентификация
```
Пользователь → AuthScreen (email+пароль)
  → POST /api/auth/register или /api/auth/login
  → bcrypt проверка → создание session token (HMAC-SHA256)
  → Set httpOnly cookie → response
  → AuthContext.refreshAuth() → GET /api/auth/me
  → Загрузка прогресса из БД → переход в меню
```

### Игровой цикл
```
GameCanvas → useGameLoop (requestAnimationFrame ~60fps)
  ├── tickSpawn()          — спавн врагов (обычный/босс режимы)
  ├── tickReload()         — перезарядка стрел
  ├── tickPlayer()         — регенерация HP, таймер неуязвимости
  ├── tickEnemies()        — движение врагов, столкновения с луком
  ├── tickProjectiles()    — движение стрел, попадания по врагам
  ├── tickCleanup()        — удаление мёртвых врагов, магнитные стрелы
  ├── tickDustParticles()  — пыль в режиме босса (только boss mode)
  └── render*()            — отрисовка всех слоёв на canvas
```

### Прогресс
```
Игра окончена → handleGameOver()
  → расчёт ядер (очки + враги + doubleCores)
  → updateProgressAPI() → PUT /api/user/progress → SQLite
  → saveScoreAPI() → POST /api/leaderboard → SQLite
```

## Ключевые механики

### Улучшения (15 типов)
- **Нападение** (розовая ветка): урон, боезапас, перезарядка, скорость стрел, пробивание
- **Мини магнит** (сателлит): последняя стрела магнитится к врагам
- **Крит** (оранжевая ветка): шанс и сила крита
- **Защита** (зелёная ветка): HP, регенерация, броня
- **Ударная волна** (сателлит): волна при получении урона (требует все 3 зелёных на MAX)
- **Экономика** (голубая ветка): сборщик ядер, двойные ядра (шанс ×2)
- Каждое улучшение имеет maxLevel (1-5), стоимость, условие разблокировки

### Босс «Омега» (3 фазы)
- **Фаза 0** (100-67% HP): гравитационные лучи к врагам (притяжение + орбита)
- **Фаза 1** (67-33% HP): + мини-чёрные дыры (поглощают стрелы)
- **Фаза 2** (33-0% HP): + все типы врагов спавнятся
- Босс рендерится в 9 слоёв (линза, аккреционный диск, искры, горизонт событий, и т.д.)

### Враги (12 типов)
- scout, tank, zigzagger, ghost (телепорт), splitter, berserker, bouncer, spiraler,
  juggernaut, phantom (невидимость), necromancer (призыв), boss_omega
- Каждый имеет уникальный паттерн движения, HP, урон, очки

## Добавление новых механик

### Новый тип врага
1. Добавить объект в `ENEMY_TYPES` (`src/game/enemies.ts`)
2. Добавить паттерн движения в `tickEnemies()` (`src/game/gameLogic.ts`)
3. Добавить веса спавна в `tickSpawn()` (обычный режим) и boss-режим
4. При необходимости — добавить отрисовку в `drawShape()` (если нужна уникальная форма)

### Новое улучшение
1. Добавить поле в `GameProgress.upgrades` (`src/types/game.ts`)
2. Добавить в `GAME_CONFIG.maxLevels` (`src/game/config.ts`)
3. Добавить в `defaultProgress()` (`src/pages/Index.tsx` и `src/lib/localStore.ts`)
4. Добавить в `BRANCHES` или `SATELLITE_NODES` (`src/pages/UpgradesScreen.tsx`)
5. Добавить в `buildStatCategories()` (вкладка характеристик)
6. Реализовать эффект в `GameCanvas.tsx` (чтение значения) и `gameLogic.ts` (применение)

### Новая способность босса
1. Добавить поля состояния в `InternalGameState` (`src/game/gameLogic.ts`)
2. Инициализировать в `GameCanvas.tsx` (gameStateRef)
3. Добавить логику в `tickSpawn()` (boss-секция) или новую функцию `tick*`
4. Добавить рендеринг в `gameRenderer.ts`
5. Вызвать рендер в `useGameLoop.ts` (секция Draw)
6. Добавить таймер/кулдаун в boss-секцию `tickSpawn()`

## Производительность

- Кэширование звёзд в `renderBackground` (модуль-level кэш)
- `Set` вместо `Array.includes()` в горячих циклах (`tickProjectiles`, `tickEnemies`)
- Пакетная отрисовка: группировка по `fillStyle` (звёзды, искры, частицы)
- Предвычисление `TAU = Math.PI * 2`, геометрии, цветов фаз
- Ограничение частиц (max 300, auto-reduce count при >200)
- Пыль только в boss-режиме (90 частиц)
