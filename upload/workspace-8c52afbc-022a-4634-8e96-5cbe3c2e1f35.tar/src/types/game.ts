/**
 * @fileoverview TypeScript типы игры SPACE ARCHER.
 *
 * GameProgress — состояние прогресса игрока (ядра, улучшения, статистика).
 * GameSettings — настройки (громкость SFX/музыки).
 *
 * @see config.ts → GAME_CONFIG.maxLevels — максимальные уровни улучшений
 * @see pages/Index.tsx — где используется GameProgress
 */

/**
 * Прогресс игрока.
 * Хранится в БД (User.cores, User.upgrades JSON, User.stats JSON).
 * Синхронизируется через updateProgressAPI() при покупке улучшений / конце игры.
 */
export interface GameProgress {
  cores: number;
  upgrades: {
    baseNode: number;
    damage: number;
    maxArrows: number;
    reloadSpeed: number;
    maxHp: number;
    regenSpeed: number;
    coreBonus: number;
    piercing: number;
    projectileSpeed: number;
    critChance: number;
    critDamage: number;
    defense: number;
    magnetArrow: number;
    shockwave: number;
    doubleCores: number;
  };
  stats?: {
    highScore: number;
    maxWave: number;
    gamesPlayed: number;
    totalEnemiesKilled: number;
  };
}

export interface GameSettings {
  sfxVolume: number;
  musicVolume: number;
}
