'use client';

/**
 * @fileoverview AdminScreen — админ-панель управления пользователями.
 *
 * Доступна только для роли admin (проверяется через useAuth).
 * Функции:
 * - Список всех пользователей (GET /api/admin/users)
 * - Редактирование: роль, ядра, рекорд, волна (PUT /api/admin/users/[id])
 * - Удаление (DELETE /api/admin/users/[id])
 *
 * @see contexts/AuthContext → isAdmin — проверка роли
 * @see app/api/admin/users — API маршруты
 */

import React, { useState, useEffect } from 'react';
import { audio } from '@/game/audioManager';
import { useAuth } from '@/contexts/AuthContext';

interface AdminScreenProps {
  onBack: () => void;
}

interface UserData {
  id: string;
  email: string;
  displayName: string;
  role: string;
  cores: number;
  stats: {
    highScore: number;
    maxWave: number;
    gamesPlayed: number;
    totalEnemiesKilled: number;
  };
  createdAt: string;
}

export function AdminScreen({ onBack }: AdminScreenProps) {
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingUser, setEditingUser] = useState<UserData | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/users', { credentials: 'include' });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'Ошибка при загрузке пользователей.');
        return;
      }
      const data = await res.json();
      setUsers(data.users || []);
    } catch {
      setError('Ошибка сети при загрузке пользователей.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) fetchUsers();
  }, [isAdmin]);

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    audio.playClick();
    try {
      const res = await fetch(`/api/admin/users/${editingUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ role: editingUser.role, cores: editingUser.cores, stats: editingUser.stats }),
      });
      if (!res.ok) { setError('Ошибка при обновлении пользователя.'); return; }
      setEditingUser(null);
      fetchUsers();
    } catch {
      setError('Ошибка сети при обновлении.');
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!window.confirm('Вы уверены, что хотите удалить этого пользователя? Это действие необратимо.')) return;
    audio.playClick();
    try {
      const res = await fetch(`/api/admin/users/${id}`, { method: 'DELETE', credentials: 'include' });
      if (!res.ok) { setError('Ошибка при удалении пользователя.'); return; }
      fetchUsers();
    } catch {
      setError('Ошибка сети при удалении.');
    }
  };

  if (!isAdmin) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-50">
        <div className="text-center">
          <h2 className="text-red-500 font-orbitron text-2xl mb-4">ДОСТУП ЗАПРЕЩЕН</h2>
          <button onClick={onBack} className="neon-btn py-2 px-4 rounded-lg">ВЕРНУТЬСЯ</button>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 bg-black/95 z-50 flex flex-col p-6 overflow-hidden animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h2 className="font-orbitron text-3xl font-black text-red-500 tracking-wider flex items-center gap-3">
          🛡️ ПАНЕЛЬ АДМИНИСТРАТОРА
        </h2>
        <button onClick={() => { audio.playClick(); onBack(); }} className="neon-btn py-2 px-4 rounded-lg text-sm">
          ЗАКРЫТЬ
        </button>
      </div>

      {error && (
        <div className="bg-red-500/20 border border-red-500/50 text-red-200 p-3 rounded-lg mb-4 font-rajdhani text-sm">
          {error}
        </div>
      )}

      <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
        {loading ? (
          <div className="text-center text-cyan-500 font-orbitron animate-pulse mt-10">ЗАГРУЗКА БАЗЫ ДАННЫХ...</div>
        ) : users.length === 0 ? (
          <div className="text-center text-white/50 font-rajdhani mt-10">Пользователей пока нет.</div>
        ) : (
          <div className="grid gap-4">
            {users.map(u => (
              <div key={u.id} className="glass-panel p-4 rounded-xl border border-white/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-orbitron text-lg text-white">{u.displayName || 'Без имени'}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${u.role === 'admin' ? 'bg-red-500/20 text-red-400 border border-red-500/50' : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'}`}>
                      {u.role.toUpperCase()}
                    </span>
                  </div>
                  <div className="font-rajdhani text-sm text-white/50 mb-2">{u.email}</div>
                  <div className="flex gap-4 font-orbitron text-xs text-white/70">
                    <span>Ядра: <span className="text-purple-400">{u.cores || 0}</span></span>
                    <span>Рекорд: <span className="text-cyan-400">{u.stats?.highScore || 0}</span></span>
                    <span>Волна: <span className="text-green-400">{u.stats?.maxWave || 1}</span></span>
                  </div>
                </div>
                <div className="flex gap-2 w-full md:w-auto">
                  <button onClick={() => setEditingUser(u)} className="flex-1 md:flex-none bg-white/10 hover:bg-white/20 text-white py-2 px-4 rounded-lg text-sm font-rajdhani transition-colors">
                    ИЗМЕНИТЬ
                  </button>
                  <button onClick={() => handleDeleteUser(u.id)} className="flex-1 md:flex-none bg-red-500/20 hover:bg-red-500/40 text-red-300 border border-red-500/30 py-2 px-4 rounded-lg text-sm font-rajdhani transition-colors">
                    УДАЛИТЬ
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {editingUser && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="glass-panel p-6 rounded-2xl border border-white/20 w-full max-w-md animate-scale-in">
            <h3 className="font-orbitron text-xl text-white mb-4">Редактирование: {editingUser.displayName}</h3>
            <form onSubmit={handleUpdateUser} className="flex flex-col gap-4">
              <div>
                <label className="font-rajdhani text-white/70 text-xs mb-1 block">Роль</label>
                <select value={editingUser.role} onChange={e => setEditingUser({ ...editingUser, role: e.target.value as 'user' | 'admin' })} className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-white font-orbitron">
                  <option value="user">USER</option>
                  <option value="admin">ADMIN</option>
                </select>
              </div>
              <div>
                <label className="font-rajdhani text-white/70 text-xs mb-1 block">Космические ядра</label>
                <input type="number" value={editingUser.cores} onChange={e => setEditingUser({ ...editingUser, cores: parseInt(e.target.value) || 0 })} className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-white font-orbitron" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-rajdhani text-white/70 text-xs mb-1 block">Рекорд (Очки)</label>
                  <input type="number" value={editingUser.stats.highScore} onChange={e => setEditingUser({ ...editingUser, stats: { ...editingUser.stats, highScore: parseInt(e.target.value) || 0 } })} className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-white font-orbitron" />
                </div>
                <div>
                  <label className="font-rajdhani text-white/70 text-xs mb-1 block">Макс. Волна</label>
                  <input type="number" value={editingUser.stats.maxWave} onChange={e => setEditingUser({ ...editingUser, stats: { ...editingUser.stats, maxWave: parseInt(e.target.value) || 1 } })} className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-white font-orbitron" />
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <button type="button" onClick={() => setEditingUser(null)} className="flex-1 bg-white/10 hover:bg-white/20 py-2 rounded-lg text-white text-sm font-bold transition-colors">ОТМЕНА</button>
                <button type="submit" className="flex-1 neon-btn py-2 rounded-lg text-sm font-bold">СОХРАНИТЬ</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
