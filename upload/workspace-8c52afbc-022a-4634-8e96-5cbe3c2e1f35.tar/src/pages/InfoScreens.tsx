'use client';

/**
 * @fileoverview InfoScreens — экраны настроек и справки.
 *
 * Экспортирует два компонента:
 * - SettingsScreen — настройка громкости SFX и музыки (ползунки)
 * - HelpScreen — справка: управление, цель игры, все 12 типов врагов с превью
 *
 * EnemyPreviewCanvas — компонент отрисовки превью врага (масштабируется под размер canvas).
 * Важно для босса: его render extent (radius × 3.2) ужимается до размеров превью.
 *
 * @see enemies.ts → drawShape — функция отрисовки фигур врагов
 * @see Index.tsx — где вызываются эти экраны
 */

import React, { useEffect, useRef } from 'react';
import { ENEMY_TYPES, drawShape } from '@/game/enemies';
import type { EnemyType } from '@/game/enemies';

import { GameSettings } from '@/types/game';
import { audio } from '@/game/audioManager';

function EnemyPreviewCanvas({ enemy }: { enemy: EnemyType }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameId: number;
    let rotation = 0;
    const W = canvas.width;
    const H = canvas.height;
    
    // Draw loop
    const render = () => {
      ctx.clearRect(0, 0, W, H);
      rotation += 0.02; 
      
      const drawRadius = enemy.radius;
      drawShape(ctx, enemy.shape, W / 2, H / 2, drawRadius, enemy.color, enemy.glowColor, rotation, 0, enemy.maxHp, enemy.maxHp);
      frameId = requestAnimationFrame(render);
    };

    frameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(frameId);
  }, [enemy]);

  return (
    <div className="shrink-0 flex items-center justify-center w-[50px] h-[50px]">
      <canvas ref={canvasRef} width={80} height={80} className="w-[80px] h-[80px]" style={{ transform: 'scale(1)', transformOrigin: 'center' }} />
    </div>
  );
}

interface SettingsScreenProps {
  settings: GameSettings;
  onSettingsChange: (s: GameSettings) => void;
  onBack: () => void;
}

export function SettingsScreen({
  settings,
  onSettingsChange,
  onBack,
}: SettingsScreenProps) {
  const handleSfxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    onSettingsChange({ ...settings, sfxVolume: val });
    audio.setVolumes(val, settings.musicVolume);
    audio.playClick();
  };

  const handleMusicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    onSettingsChange({ ...settings, musicVolume: val });
  };
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center px-4 animate-fade-in"
      style={{ background: 'linear-gradient(135deg, #070a0f 0%, #0a0520 100%)' }}>
      <div className="w-full max-w-md">
        <div className="font-orbitron text-3xl font-black neon-purple text-center mb-2 tracking-wider">⚙ НАСТРОЙКИ</div>
        <div className="font-rajdhani text-white/30 text-center text-sm tracking-widest mb-8">ПАРАМЕТРЫ ИГРЫ</div>

        <div className="flex flex-col gap-4">
          {/* Sound */}
          <div className="flex flex-col gap-4 px-4 py-4 rounded border border-white/10"
            style={{ background: 'rgba(255,255,255,0.02)' }}>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <div className="font-orbitron text-sm font-bold text-white/80 tracking-wider">ЗВУКИ (SFX)</div>
                <div className="font-rajdhani text-white/40 text-xs">{Math.round(settings.sfxVolume * 100)}%</div>
              </div>
              <input 
                type="range" min="0" max="1" step="0.05" 
                value={settings.sfxVolume} 
                onChange={handleSfxChange}
                className="w-full accent-cyan-400"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <div className="font-orbitron text-sm font-bold text-white/80 tracking-wider">МУЗЫКА</div>
                <div className="font-rajdhani text-white/40 text-xs">{Math.round(settings.musicVolume * 100)}%</div>
              </div>
              <input 
                type="range" min="0" max="1" step="0.05" 
                value={settings.musicVolume} 
                onChange={handleMusicChange}
                className="w-full accent-purple-400"
              />
            </div>
          </div>
        </div>

        <button className="neon-btn py-3 px-6 rounded text-sm font-bold mt-8 w-full" onClick={() => { audio.playClick(); onBack(); }}>← НАЗАД</button>
      </div>
    </div>
  );
}

interface HelpScreenProps {
  onBack: () => void;
}

export function HelpScreen({ onBack }: HelpScreenProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center pt-8 px-4 animate-fade-in overflow-auto"
      style={{ background: 'linear-gradient(135deg, #070a0f 0%, #0a0520 100%)', paddingBottom: '2rem' }}>
      <div className="w-full max-w-lg">
        <div className="font-orbitron text-3xl font-black neon-green text-center mb-2 tracking-wider">? СПРАВКА</div>
        <div className="font-rajdhani text-white/30 text-center text-sm tracking-widest mb-6">ПРАВИЛА И ОПИСАНИЕ ВРАГОВ</div>

        <div className="mb-5 px-4 py-4 rounded border border-white/10"
          style={{ background: 'rgba(255,255,255,0.02)' }}>
          <div className="font-orbitron text-sm font-bold text-white/70 tracking-wider mb-3">🎮 УПРАВЛЕНИЕ</div>
          <div className="flex flex-col gap-2 font-rajdhani text-sm">
            <div className="flex justify-between">
              <span className="text-white/50">Мышь</span>
              <span className="text-white/80">Направление лука (прицел)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/50">Клик мыши / Пробел</span>
              <span className="text-white/80">Выстрел стрелой</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/50">Esc</span>
              <span className="text-white/80">Пауза / Меню</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/50">Стрелы = 0</span>
              <span className="text-white/80">Авто-перезарядка 2 сек</span>
            </div>
          </div>
        </div>

        <div className="mb-5 px-4 py-4 rounded border border-white/10"
          style={{ background: 'rgba(255,255,255,0.02)' }}>
          <div className="font-orbitron text-sm font-bold text-white/70 tracking-wider mb-3">🎯 ЦЕЛЬ</div>
          <div className="font-rajdhani text-sm text-white/60 leading-relaxed">
            Лук стоит в центре и не двигается. Уничтожай волны врагов — фигур, которые летят к тебе.
            Если враг касается лука — теряешь HP. При 0 HP — конец. Очки = очки врага × номер волны.
          </div>
        </div>

        <div className="mb-5">
          <div className="font-orbitron text-sm font-bold text-white/70 tracking-wider mb-3 px-1">👾 ТИПЫ ВРАГОВ</div>
          <div className="flex flex-col gap-2">
            {ENEMY_TYPES.map(e => (
              <div key={e.id} className="flex items-center gap-3 px-3 py-3 rounded border"
                style={{ borderColor: e.color + '33', background: e.color + '08' }}>
                <EnemyPreviewCanvas enemy={e} />
                <div className="flex-1 min-w-0 py-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-orbitron text-xs font-bold" style={{ color: e.color }}>{e.name}</span>
                    <span className="font-rajdhani text-xs text-white/40">
                      HP: {e.maxHp} | Урон: {e.damage} | Скор: {e.speed.toFixed(1)} | {e.points} оч.
                    </span>
                    {e.special && (
                      <span className="font-rajdhani text-xs px-1.5 py-0.5 rounded"
                        style={{ background: e.color + '22', color: e.color }}>
                        {e.special}
                      </span>
                    )}
                  </div>
                  <div className="font-rajdhani text-xs text-white/50">{e.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button className="neon-btn py-3 px-6 rounded text-sm font-bold w-full" onClick={() => { audio.playClick(); onBack(); }}>← НАЗАД</button>
      </div>
    </div>
  );
}
