'use client';

/**
 * @fileoverview MenuScreen — главное меню и экран выбора режима/конца игры.
 *
 * Отображается в трёх режимах (prop screen):
 * - 'menu' — главное меню (логотип, кнопки: играть, прокачка, рекорды, настройки, справка)
 * - 'mode_selection' — выбор режима (обычный / битва с боссом)
 * - 'gameover' — экран конца игры (счёт, волна, полученные ядра, сохранение рекорда)
 *
 * Также содержит анимированный фон (canvas с частицами) и профиль пользователя (верхний левый угол).
 *
 * @see Index.tsx — где управляется навигация
 */

import { useEffect, useRef } from 'react';
import { audio } from '@/game/audioManager';
import { SpaceCoreIcon } from '@/components/SpaceCoreIcon';
import { useAuth } from '@/contexts/AuthContext';

type Screen = 'menu' | 'mode_selection' | 'game' | 'gameover' | 'leaderboard' | 'settings' | 'help' | 'auth' | 'admin' | 'profile';

interface MenuScreenProps {
  screen: 'menu' | 'gameover' | 'mode_selection';
  lastScore: number;
  lastWave: number;
  lastEarnedCores: number;
  showNameInput: boolean;
  nameInput: string;
  onNameInputChange: (value: string) => void;
  onSaveScore: () => void;
  onShowNameInput: () => void;
  onNavigate: (screen: Screen) => void;
  onStartGame?: (mode: 'classic' | 'boss') => void;
}

export default function MenuScreen({
  screen,
  lastScore,
  lastWave,
  lastEarnedCores,
  showNameInput,
  nameInput,
  onNameInputChange,
  onSaveScore,
  onShowNameInput,
  onNavigate,
  onStartGame,
}: MenuScreenProps) {
  const { user, isAdmin } = useAuth();
  const menuAnimRef = useRef<number>(0);
  const menuCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = menuCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let f = 0;

    const particles: { x: number; y: number; vx: number; vy: number; r: number; color: string }[] = [];
    for (let i = 0; i < 40; i++) {
      particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        r: Math.random() * 2 + 0.5,
        color: ['#00ffff', '#bf00ff', '#00ff41', '#ff006e', '#ffff00'][Math.floor(Math.random() * 5)],
      });
    }

    const loop = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const W = canvas.width, H = canvas.height;
      f++;

      ctx.fillStyle = '#070a0f';
      ctx.fillRect(0, 0, W, H);

      ctx.strokeStyle = 'rgba(0,255,255,0.03)';
      ctx.lineWidth = 1;
      for (let gx = 0; gx < W; gx += 50) {
        ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
      }
      for (let gy = 0; gy < H; gy += 50) {
        ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
      }

      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 10; ctx.shadowColor = p.color;
        ctx.fill(); ctx.shadowBlur = 0;
      });

      const cx = W / 2, cy = H * 0.36;
      const t = f * 0.025;

      for (let ring = 0; ring < 3; ring++) {
        const r = 50 + ring * 30 + Math.sin(t + ring) * 6;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(0,255,255,${0.04 + 0.02 * Math.sin(t)})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      ctx.save();
      ctx.translate(cx, cy);
      const bowAngle = Math.sin(t * 0.5) * 0.3;
      ctx.rotate(bowAngle);

      ctx.beginPath();
      ctx.arc(0, 0, 32, -Math.PI * 0.6, Math.PI * 0.6);
      ctx.strokeStyle = `rgba(0,255,255,${0.7 + 0.3 * Math.sin(t * 2)})`;
      ctx.lineWidth = 3;
      ctx.shadowBlur = 25; ctx.shadowColor = '#00ffff';
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(Math.cos(-Math.PI * 0.6) * 32, Math.sin(-Math.PI * 0.6) * 32);
      ctx.lineTo(44, 0);
      ctx.lineTo(Math.cos(Math.PI * 0.6) * 32, Math.sin(Math.PI * 0.6) * 32);
      ctx.strokeStyle = 'rgba(0,255,255,0.5)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.restore();

      menuAnimRef.current = requestAnimationFrame(loop);
    };

    menuAnimRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(menuAnimRef.current);
  }, []);

  return (
    <div className="absolute inset-0">
      <canvas ref={menuCanvasRef} className="absolute inset-0 w-full h-full" />

      <div className="absolute inset-0 flex flex-col items-center justify-center gap-0 animate-fade-in">
        {user && (screen === 'menu' || screen === 'gameover' || screen === 'mode_selection') && (
          <div className="absolute top-4 left-4 z-50 animate-fade-in">
            <div 
              className="flex items-center justify-between bg-black/40 border border-white/10 rounded-xl p-3 glass-panel hover:border-cyan-500/50 hover:bg-cyan-500/10 transition-all cursor-pointer group"
              onClick={() => { audio.playClick(); onNavigate('profile'); }}
            >
              <div className="flex items-center gap-3 overflow-hidden pr-4">
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-300 font-orbitron font-bold text-sm shrink-0 shadow-[0_0_10px_rgba(0,255,255,0.2)] group-hover:shadow-[0_0_15px_rgba(0,255,255,0.4)] transition-shadow">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-full h-full rounded-full object-cover" />
                  ) : (
                    user.displayName?.charAt(0) || user.email?.charAt(0) || 'P'
                  )}
                </div>
                <div className="flex flex-col truncate max-w-[150px]">
                  <span className="font-orbitron text-sm text-white truncate group-hover:text-cyan-300 transition-colors">{user.displayName || 'Пилот'}</span>
                  <span className="font-rajdhani text-xs text-white/50 truncate">ПРОФИЛЬ</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {screen === 'gameover' && (
          <div className="mb-8 text-center animate-scale-in">
            <div className="font-orbitron font-black neon-pink animate-flicker mb-2"
              style={{ fontSize: 'clamp(2rem, 6vw, 3.5rem)' }}>
              ИГРА ОКОНЧЕНА
            </div>
            <div className="font-rajdhani text-xl text-white/60 tracking-widest mb-2">
              СЧЁТ: <span className="neon-cyan font-bold">{lastScore.toLocaleString()}</span>
              &nbsp;·&nbsp; ВОЛНА: <span className="neon-purple font-bold">{lastWave}</span>
            </div>
            <div className="font-orbitron text-sm text-white/80 tracking-widest flex items-center justify-center gap-2">
              ПОЛУЧЕНО: <span className="neon-purple font-bold flex items-center gap-1.5">+{lastEarnedCores} <SpaceCoreIcon className="w-5 h-5" /> КОСМ. ЯДЕР</span>
            </div>
          </div>
        )}

        {screen === 'menu' && (
          <div className="relative mb-10 group flex flex-col items-center">
            {/* Background glow behind the title */}
            <div className="absolute inset-0 bg-cyan-500/20 blur-[80px] rounded-full scale-150 pointer-events-none transition-all duration-1000 group-hover:bg-cyan-500/30"></div>

            <div className="relative font-orbitron font-black tracking-[0.2em] animate-flicker"
              style={{ 
                fontSize: 'clamp(3rem, 10vw, 7rem)', 
                lineHeight: '1.1',
                textShadow: '0 0 10px rgba(0,255,255,0.8), 0 0 20px rgba(0,255,255,0.5), 0 0 40px rgba(0,255,255,0.3)',
                background: 'linear-gradient(to bottom, #ffffff 10%, #00ffff 90%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>
              SPACE
            </div>
            
            <div className="relative font-orbitron font-black tracking-[0.3em] animate-pulse"
              style={{ 
                fontSize: 'clamp(2.5rem, 8vw, 5.5rem)',
                lineHeight: '1',
                marginTop: '-0.1em',
                textShadow: '0 0 10px rgba(191,0,255,0.8), 0 0 20px rgba(191,0,255,0.5), 0 0 40px rgba(191,0,255,0.3)',
                background: 'linear-gradient(to bottom, #ffffff 0%, #bf00ff 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                animationDuration: '3s'
              }}>
              ARCHER
            </div>

            <div className="relative font-rajdhani text-sm tracking-[0.4em] text-cyan-200/50 mt-4 uppercase animate-fade-in" style={{ animationDelay: '0.3s' }}>
              Космическая аркада
            </div>
          </div>
        )}

        <div className="flex flex-col gap-4 w-72 glass-panel p-6 rounded-2xl animate-scale-in">
          {screen === 'mode_selection' ? (
            <>
              <div className="font-orbitron text-center text-cyan-400 font-bold mb-2">ВЫБЕРИТЕ РЕЖИМ</div>
              <button className="neon-btn-rainbow volumetric-btn py-4 px-6 rounded-xl font-bold text-sm animate-scale-in flex flex-col items-center"
                style={{ animationDelay: '0.05s' }}
                onClick={() => { audio.playClick(); onStartGame?.('classic'); }}>
                <span>🌌 Обычный режим</span>
                <span className="text-[10px] text-white/50 font-normal mt-1 leading-none">Стандартные волны врагов</span>
              </button>
              <button className="neon-btn neon-btn-purple volumetric-btn py-4 px-6 rounded-xl font-bold text-sm animate-scale-in flex flex-col items-center"
                style={{ animationDelay: '0.1s', borderColor: 'rgba(255,0,0,0.5)', textShadow: '0 0 5px #ff0000' }}
                onClick={() => { audio.playClick(); onStartGame?.('boss'); }}>
                <span>🔥 Битва с боссом</span>
                <span className="text-[10px] text-white/50 font-normal mt-1 leading-none">Эпичное долгое сражение</span>
              </button>
              <button className="neon-btn volumetric-btn py-2 px-6 mt-2 rounded-xl text-sm opacity-80 animate-scale-in"
                style={{ animationDelay: '0.15s' }}
                onClick={() => { audio.playClick(); onNavigate('menu'); }}>
                НАЗАД
              </button>
            </>
          ) : (
            <>
              {screen === 'gameover' && !showNameInput && (
                <button className="neon-btn volumetric-btn py-3 px-6 rounded-xl font-bold text-sm"
                  onClick={() => { audio.playClick(); onShowNameInput(); }}>
                  💾 СОХРАНИТЬ РЕКОРД
                </button>
              )}
              {screen === 'gameover' && showNameInput && (
                <div className="flex gap-2 animate-scale-in">
                  <input
                    className="flex-1 bg-black/40 border border-cyan-500/30 rounded-xl px-4 py-2 text-cyan-300 font-orbitron text-sm outline-none focus:border-cyan-400/60 transition-all"
                    placeholder="ТВОЁ ИМЯ..."
                    maxLength={10}
                    value={nameInput}
                    onChange={e => onNameInputChange(e.target.value.toUpperCase())}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        audio.playClick();
                        onSaveScore();
                      }
                    }}
                    autoFocus
                  />
                  <button className="neon-btn volumetric-btn py-2 px-4 rounded-xl text-sm" 
                    onClick={() => { audio.playClick(); onSaveScore(); }}>
                    OK
                  </button>
                </div>
              )}

              <button className="neon-btn-rainbow volumetric-btn py-4 px-6 rounded-xl font-bold text-sm animate-scale-in"
                style={{ animationDelay: '0.05s' }}
                onClick={() => { audio.playClick(); onNavigate('mode_selection'); }}>
                {screen === 'gameover' ? '↺ ИГРАТЬ СНОВА' : '▶ НАЧАТЬ ИГРУ'}
              </button>
              <button className="neon-btn-upgrades py-3 px-6 rounded-xl font-bold text-sm animate-scale-in"
                style={{ animationDelay: '0.08s' }}
                onClick={() => { audio.playClick(); onNavigate('upgrades'); }}>
                <span className="relative z-10">⚡ ПРОКАЧКА</span>
              </button>
              <button className="neon-btn neon-btn-purple volumetric-btn py-3 px-6 rounded-xl font-bold text-sm animate-scale-in"
                style={{ animationDelay: '0.1s' }}
                onClick={() => { audio.playClick(); onNavigate('leaderboard'); }}>
                🏆 РЕКОРДЫ
              </button>
              <button className="neon-btn volumetric-btn py-3 px-6 rounded-xl font-bold text-sm animate-scale-in"
                style={{ animationDelay: '0.15s' }}
                onClick={() => { audio.playClick(); onNavigate('settings'); }}>
                ⚙ НАСТРОЙКИ
              </button>
              <button className="neon-btn neon-btn-green volumetric-btn py-3 px-6 rounded-xl font-bold text-sm animate-scale-in"
                style={{ animationDelay: '0.2s' }}
                onClick={() => { audio.playClick(); onNavigate('help'); }}>
                ? СПРАВКА
              </button>
              {isAdmin && (
                <button className="neon-btn volumetric-btn py-3 px-6 rounded-xl font-bold text-sm animate-scale-in border-red-500/50 text-red-400 hover:text-red-300"
                  style={{ animationDelay: '0.25s' }}
                  onClick={() => { audio.playClick(); onNavigate('admin'); }}>
                  🛡️ АДМИН ПАНЕЛЬ
                </button>
              )}
            </>
          )}
        </div>

        {screen === 'menu' && (
          <div className="mt-8 font-rajdhani text-white/25 text-xs tracking-widest text-center">
            КЛИК — ВЫСТРЕЛ · МЫШЬ — ПРИЦЕЛ
          </div>
        )}
      </div>
    </div>
  );
}
