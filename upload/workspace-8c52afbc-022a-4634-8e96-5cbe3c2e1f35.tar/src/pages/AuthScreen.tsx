'use client';

/**
 * @fileoverview AuthScreen — экран авторизации (вход/регистрация).
 *
 * Два режима:
 * - «ВХОД» — email + пароль → POST /api/auth/login
 * - «РЕГИСТРАЦИЯ» — имя + email + пароль → POST /api/auth/register
 *
 * После успеха вызывает onAuthSuccess() (который вызывает refreshAuth из AuthContext).
 * Email natalya.atamankina1@yandex.ru автоматически получает роль admin.
 *
 * @see contexts/AuthContext → refreshAuth — вызывается после успешного входа
 * @see app/api/auth/register, app/api/auth/login — API маршруты
 */

import React, { useState, useEffect, useRef } from 'react';
import { audio } from '@/game/audioManager';

interface AuthScreenProps {
  onBack: () => void;
  hideClose?: boolean;
  onAuthSuccess: () => Promise<void> | void;
}

export function AuthScreen({ onBack, hideClose, onAuthSuccess }: AuthScreenProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let f = 0;

    const particles: { x: number; y: number; vx: number; vy: number; r: number; color: string }[] = [];
    for (let i = 0; i < 40; i++) {
      particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        r: Math.random() * 2 + 1,
        color: ['#00ffff', '#bf00ff', '#ff006e'][Math.floor(Math.random() * 3)],
      });
    }

    const loop = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const W = canvas.width, H = canvas.height;
      f++;

      ctx.fillStyle = '#070a0f';
      ctx.fillRect(0, 0, W, H);

      ctx.strokeStyle = 'rgba(0,255,255,0.03)';
      ctx.lineWidth = 1;
      for (let gx = 0; gx < W; gx += 50) {
        ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
      }
      for (let gy = 0; gy < H; gy += 50) {
        ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
      }

      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 15; ctx.shadowColor = p.color;
        ctx.fill(); ctx.shadowBlur = 0;
      });

      const cx = W / 2, cy = H / 2;
      const radius = Math.min(W, H) * 0.35;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(191, 0, 255, ${0.03 + Math.sin(f * 0.02) * 0.02})`;
      ctx.lineWidth = 2;
      ctx.stroke();

      animRef.current = requestAnimationFrame(loop);
    };

    animRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    audio.playClick();

    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const payload: Record<string, string> = { email, password };
      if (mode === 'register') payload.displayName = displayName;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Ошибка');
        setLoading(false);
        return;
      }

      // Success — notify parent to refresh auth state, then wait for it
      // so the loading spinner stays until the app transitions to the game.
      await onAuthSuccess();
      // setLoading(false) intentionally omitted on success — AuthScreen unmounts
      // when the parent updates the user state.
    } catch {
      setError('Ошибка сети. Попробуйте ещё раз.');
      setLoading(false);
    }
  };

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center pt-8 px-4 animate-fade-in z-50">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full -z-10" />

      <div className="w-full max-w-md glass-panel p-8 rounded-2xl border border-white/10 relative overflow-hidden animate-scale-in shadow-[0_0_50px_rgba(0,255,255,0.1)]">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 animate-pulse" />

        <h2 className="font-orbitron text-3xl font-black text-center mb-2 neon-cyan tracking-wider">
          {mode === 'register' ? 'РЕГИСТРАЦИЯ' : 'АВТОРИЗАЦИЯ'}
        </h2>
        <p className="font-rajdhani text-white/50 text-center mb-6 text-sm tracking-widest uppercase">
          {mode === 'register' ? 'СОЗДАЙТЕ АККАУНТ ДЛЯ СОХРАНЕНИЯ ПРОГРЕССА' : 'ВОЙДИТЕ В АККАУНТ'}
        </p>

        {/* Mode toggle */}
        <div className="flex gap-2 mb-6">
          <button
            type="button"
            onClick={() => { audio.playClick(); setMode('login'); setError(''); }}
            className={`flex-1 py-2 rounded-lg font-orbitron text-xs font-bold tracking-wider transition-all ${mode === 'login' ? 'neon-cyan border border-cyan-500/50 bg-cyan-500/10' : 'text-white/40 border border-white/10 hover:text-white/70'}`}
          >
            ВХОД
          </button>
          <button
            type="button"
            onClick={() => { audio.playClick(); setMode('register'); setError(''); }}
            className={`flex-1 py-2 rounded-lg font-orbitron text-xs font-bold tracking-wider transition-all ${mode === 'register' ? 'neon-purple border border-purple-500/50 bg-purple-500/10' : 'text-white/40 border border-white/10 hover:text-white/70'}`}
          >
            РЕГИСТРАЦИЯ
          </button>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-400 p-3 rounded-lg mb-4 font-rajdhani text-sm text-center animate-fade-in">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {mode === 'register' && (
            <div>
              <label className="font-rajdhani text-white/50 text-xs tracking-widest uppercase mb-1 block">Имя пилота</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => { setDisplayName(e.target.value); setError(''); }}
                placeholder="ВАШЕ ИМЯ..."
                maxLength={30}
                className="w-full bg-black/40 border border-cyan-500/30 rounded-xl px-4 py-3 text-cyan-300 font-orbitron text-sm outline-none focus:border-cyan-400/60 transition-all"
              />
            </div>
          )}
          <div>
            <label className="font-rajdhani text-white/50 text-xs tracking-widest uppercase mb-1 block">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(''); }}
              placeholder="pilot@example.com"
              required
              className="w-full bg-black/40 border border-cyan-500/30 rounded-xl px-4 py-3 text-cyan-300 font-orbitron text-sm outline-none focus:border-cyan-400/60 transition-all"
            />
          </div>
          <div>
            <label className="font-rajdhani text-white/50 text-xs tracking-widest uppercase mb-1 block">Пароль</label>
            <input
              type="password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(''); }}
              placeholder="••••••••"
              required
              minLength={4}
              className="w-full bg-black/40 border border-cyan-500/30 rounded-xl px-4 py-3 text-cyan-300 font-orbitron text-sm outline-none focus:border-cyan-400/60 transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full neon-btn py-4 px-6 rounded-xl text-md font-bold disabled:opacity-50"
          >
            {loading ? 'ЗАГРУЗКА...' : (mode === 'register' ? '▶ СОЗДАТЬ АККАУНТ' : '▶ ВОЙТИ')}
          </button>
        </form>

        <p className="font-rajdhani text-white/30 text-center text-xs mt-6 tracking-wider">
          {mode === 'register'
            ? 'Используйте email natalya.atamankina1@yandex.ru для доступа к админ-панели'
            : 'Нет аккаунта? Переключитесь на регистрацию'}
        </p>

        {!hideClose && (
          <button
            type="button"
            onClick={() => { audio.playClick(); onBack(); }}
            className="absolute top-4 right-4 text-white/30 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-lg"
          >
            ✕
          </button>
        )}
      </div>
    </div>
  );
}
