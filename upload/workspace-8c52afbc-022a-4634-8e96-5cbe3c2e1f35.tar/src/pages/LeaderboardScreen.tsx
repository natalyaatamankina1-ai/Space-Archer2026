'use client';

/**
 * @fileoverview LeaderboardScreen — таблица лидеров.
 *
 * Загружает топ-10 рекордов через fetchLeaderboardAPI() (GET /api/leaderboard).
 * Показывает имя, дату, очки и волну. Скролл при переполнении.
 *
 * @see lib/api.ts → fetchLeaderboardAPI — клиентская обёртка
 * @see app/api/leaderboard — API маршрут
 */

import { useState, useEffect } from 'react';
import { audio } from '@/game/audioManager';
import { fetchLeaderboardAPI } from '@/lib/api';

interface LeaderEntry {
  id: string;
  name: string;
  score: number;
  wave: number;
  date: string;
}

interface LeaderboardScreenProps {
  onBack: () => void;
}

export default function LeaderboardScreen({ onBack }: LeaderboardScreenProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(async () => {
      const entries = await fetchLeaderboardAPI();
      setLeaderboard(entries);
      setLoading(false);
    }, 400);
    return () => clearTimeout(t);
  }, []);

  const formatDate = (dateStr: string): string => {
    try {
      return new Date(dateStr).toLocaleDateString('ru-RU');
    } catch {
      return 'Неизвестно';
    }
  };

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center px-4 animate-fade-in z-50"
      style={{ background: 'linear-gradient(135deg, #070a0f 0%, #0a0520 100%)' }}>
      <div className="w-full max-w-md">
        <div className="font-orbitron text-3xl font-black neon-cyan text-center mb-2 tracking-wider">ГЛОБАЛЬНЫЙ РЕЙТИНГ</div>
        <div className="font-rajdhani text-white/30 text-center text-sm tracking-widest mb-8">ЛУЧШИЕ СТРЕЛКИ В МИРЕ</div>

        <div className="glass-panel p-6 rounded-2xl mb-8 border border-white/10 shadow-[0_0_30px_rgba(0,255,255,0.05)]">
          {loading ? (
            <div className="text-center font-rajdhani text-cyan-400 py-8 animate-pulse">
              ЗАГРУЗКА БАЗЫ ДАННЫХ...
            </div>
          ) : leaderboard.length === 0 ? (
            <div className="text-center font-rajdhani text-white/50 py-8">
              Пока нет рекордов. Стань первым!
            </div>
          ) : (
            <div className="flex flex-col gap-3 max-h-96 overflow-y-auto custom-scrollbar">
              {leaderboard.map((entry, i) => (
                <div key={entry.id} className="flex items-center justify-between p-3 rounded border border-white/5 hover:border-cyan-500/20 bg-white/5 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="font-orbitron text-xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-white/20 w-6 text-center">{i + 1}</div>
                    <div>
                      <div className="font-orbitron text-sm font-bold text-white/90">{entry.name}</div>
                      <div className="font-rajdhani text-xs text-cyan-400/50">{formatDate(entry.date)}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-orbitron text-lg font-black neon-cyan">{entry.score.toLocaleString()}</div>
                    <div className="font-rajdhani text-xs text-white/50">Волна {entry.wave}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex gap-4">
          <button className="neon-btn py-3 px-6 rounded-xl text-sm font-bold w-full" onClick={() => { audio.playClick(); onBack(); }}>
            ВЕРНУТЬСЯ НА БАЗУ
          </button>
        </div>
      </div>
    </div>
  );
}
