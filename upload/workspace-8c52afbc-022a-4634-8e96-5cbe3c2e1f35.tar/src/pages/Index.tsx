'use client';

/**
 * @fileoverview Index — главный оркестратор экранов игры.
 *
 * Управляет навигацией между всеми экранами:
 * menu → mode_selection → game → gameover → leaderboard
 *                ↓                         ↑
 *           upgrades ←→ menu          (сохранение рекорда)
 *           settings ←→ menu
 *           help ←→ menu
 *           profile ←→ menu
 *           admin ←→ menu (только для админов)
 *
 * Также управляет:
 * - Загрузкой/сохранением прогресса через API (updateProgressAPI)
 * - Музыкой меню (запуск при не-игровом экране, стоп при game)
 * - Настройками (звук, музыка) — localStorage
 * - Обработкой конца игры (handleGameOver) — расчёт ядер, синхронизация с БД
 * - Покупкой улучшений (handleUpgrade) — валидация, списание ядер, синхронизация
 *
 * @see AuthContext — провайдер аутентификации (user, loading, progress)
 * @see GameScreen — игровой экран
 * @see UpgradesScreen — дерево прокачки
 */

import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { GameProgress, GameSettings } from '@/types/game';
import { GAME_CONFIG } from '@/game/config';
import { updateProgressAPI, saveScoreAPI } from '@/lib/api';
import { audio } from '@/game/audioManager';
import MenuScreen from './MenuScreen';
import GameScreen from './GameScreen';
import LeaderboardScreen from './LeaderboardScreen';
import { SettingsScreen, HelpScreen } from './InfoScreens';
import { UpgradesScreen } from './UpgradesScreen';
import { AuthScreen } from './AuthScreen';
import { AdminScreen } from './AdminScreen';
import { ProfileScreen } from './ProfileScreen';

type Screen = 'menu' | 'mode_selection' | 'game' | 'gameover' | 'leaderboard' | 'settings' | 'help' | 'upgrades' | 'auth' | 'admin' | 'profile';

export type GameMode = 'classic' | 'boss';

interface GameHudState {
  hp: number;
  maxHp: number;
  score: number;
  wave: number;
  arrows: number;
  maxArrows: number;
  reloading: boolean;
  reloadProgress: number;
  paused: boolean;
  enemiesKilled: number;
}

function defaultProgress(): GameProgress {
  return {
    cores: 0,
    upgrades: {
      baseNode: 0, damage: 0, maxArrows: 0, reloadSpeed: 0, maxHp: 0,
      regenSpeed: 0, coreBonus: 0, piercing: 0, projectileSpeed: 0,
      critChance: 0, critDamage: 0, defense: 0, magnetArrow: 0, shockwave: 0, doubleCores: 0,
    },
  };
}

export default function Index() {
  const { user, loading: authLoading, progress: authProgress, refreshAuth } = useAuth();
  const [screen, setScreen] = useState<Screen>('menu');
  const [gameMode, setGameMode] = useState<GameMode>('classic');
  const [settings, setSettings] = useState<GameSettings>(() => {
    if (typeof window === 'undefined') return { sfxVolume: 0.5, musicVolume: 0.3 };
    const saved = localStorage.getItem('neon_archer_settings');
    if (saved) {
      try { return { sfxVolume: 0.5, musicVolume: 0.3, ...JSON.parse(saved) }; } catch { /* ignore */ }
    }
    return { sfxVolume: 0.5, musicVolume: 0.3 };
  });
  const [progress, setProgress] = useState<GameProgress>(defaultProgress());
  const [hudState, setHudState] = useState<GameHudState>({
    hp: 100, maxHp: 100,
    score: 0, wave: 1,
    arrows: 8, maxArrows: 8, reloading: false, reloadProgress: 0, paused: false,
    enemiesKilled: 0,
  });
  const [lastScore, setLastScore] = useState(0);
  const [lastWave, setLastWave] = useState(1);
  const [lastEarnedCores, setLastEarnedCores] = useState(0);
  const [playerName, setPlayerName] = useState<string>(() => {
    if (typeof window === 'undefined') return 'ARCHER';
    return localStorage.getItem('neon_archer_name') || 'ARCHER';
  });
  const [nameInput, setNameInput] = useState('');
  const [showNameInput, setShowNameInput] = useState(false);

  useEffect(() => {
    localStorage.setItem('neon_archer_settings', JSON.stringify(settings));
    audio.setVolumes(settings.sfxVolume, settings.musicVolume);
  }, [settings]);

  // Menu music: play when user is logged in and not in a game, stop when game starts
  useEffect(() => {
    if (!user || authLoading) return;
    if (screen === 'game') {
      audio.stopMenuMusic();
    } else {
      audio.startMenuMusic();
    }
  }, [user, authLoading, screen]);

  // Sync progress from DB (via AuthContext) when user logs in or data changes.
  const lastAuthProgressRef = useRef<string>('');
  useEffect(() => {
    if (authProgress) {
      const defaults = defaultProgress();
      const mergedProgress: GameProgress = {
        cores: authProgress.cores,
        upgrades: { ...defaults.upgrades, ...authProgress.upgrades },
        stats: authProgress.stats,
      };
      const serialized = JSON.stringify(mergedProgress);
      lastAuthProgressRef.current = serialized;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setProgress(mergedProgress);
    } else if (!user && !authLoading && lastAuthProgressRef.current !== 'default') {
      lastAuthProgressRef.current = 'default';
      setProgress(defaultProgress());
    }
  }, [authProgress, user, authLoading]);

  const updateProgressInStore = (newProgress: GameProgress) => {
    setProgress(newProgress);
    // Sync to DB asynchronously
    updateProgressAPI(newProgress);
  };

  const handleGameOver = (score: number, enemiesKilled: number, finalWave: number, doubleCoresTriggered: number = 0) => {
    setLastScore(score);
    setLastWave(finalWave);

    setProgress(prev => {
      // Each enemy gives 1 base core; doubleCoresTriggered enemies give +1 extra (×2)
      const baseCores = Math.floor(score / 50) + enemiesKilled + (doubleCoresTriggered || 0);
      const earned = Math.floor(baseCores * (1 + prev.upgrades.coreBonus * 0.05));
      setLastEarnedCores(earned);

      const currentStats = prev.stats || { highScore: 0, maxWave: 0, gamesPlayed: 0, totalEnemiesKilled: 0 };

      const newProgress: GameProgress = {
        ...prev,
        cores: prev.cores + earned,
        stats: {
          highScore: Math.max(currentStats.highScore, score),
          maxWave: Math.max(currentStats.maxWave, finalWave),
          gamesPlayed: currentStats.gamesPlayed + 1,
          totalEnemiesKilled: currentStats.totalEnemiesKilled + enemiesKilled,
        },
      };

      // Sync to DB
      updateProgressAPI(newProgress);

      return newProgress;
    });

    setShowNameInput(false);
    setNameInput('');
    setScreen('gameover');
  };

  const handleUpgrade = (key: keyof GameProgress['upgrades'], cost: number) => {
    const maxLevel = GAME_CONFIG.maxLevels[key] ?? 5;
    const currentLevel = progress.upgrades[key] || 0;
    // Validate: must be able to afford, not at max, and cost is a positive number
    if (typeof cost !== 'number' || cost < 0 || currentLevel >= maxLevel) return;
    if (progress.cores < cost) return;
    const newProgress: GameProgress = {
      ...progress,
      cores: progress.cores - cost,
      upgrades: { ...progress.upgrades, [key]: currentLevel + 1 },
    };
    updateProgressInStore(newProgress);
  };

  const saveScore = () => {
    const name = (nameInput.trim() || user?.displayName || playerName).toUpperCase().slice(0, 10);

    localStorage.setItem('neon_archer_name', name);
    setPlayerName(name);
    setShowNameInput(false);
    setScreen('leaderboard');

    if (user) {
      // Save to leaderboard via API (also updates user stats server-side)
      saveScoreAPI(name, lastScore, lastWave);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden" style={{ background: '#070a0f' }}>

      {authLoading ? (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="font-orbitron text-2xl neon-cyan animate-pulse tracking-widest">ЗАГРУЗКА СИСТЕМЫ...</div>
        </div>
      ) : !user ? (
        <AuthScreen hideClose={true} onBack={() => {}} onAuthSuccess={refreshAuth} />
      ) : (
        <>
          {user && (screen === 'upgrades' || screen === 'menu') && (
            <div className="absolute top-16 right-4 z-[100] flex flex-col gap-2 pointer-events-auto">
              <button
                className="bg-purple-600/50 hover:bg-purple-500 text-white px-3 py-1 rounded text-xs font-orbitron border border-purple-500/50 transition-colors backdrop-blur-sm shadow-[0_0_10px_rgba(191,0,255,0.3)]"
                onClick={() => {
                  setProgress(p => {
                    const np = { ...p, cores: p.cores + 10000 };
                    updateProgressAPI(np);
                    return np;
                  });
                }}
              >
                +10000 CORES [TEST]
              </button>
              <button
                className="bg-red-600/50 hover:bg-red-500 text-white px-3 py-1 rounded text-xs font-orbitron border border-red-500/50 transition-colors backdrop-blur-sm shadow-[0_0_10px_rgba(255,0,0,0.3)]"
                onClick={() => {
                  setProgress(p => {
                    const np = { ...p, cores: 0 };
                    updateProgressAPI(np);
                    return np;
                  });
                }}
              >
                0 CORES [TEST]
              </button>
            </div>
          )}
          {(screen === 'menu' || screen === 'gameover' || screen === 'mode_selection') && (
            <MenuScreen
              screen={screen}
              lastScore={lastScore}
              lastWave={lastWave}
              lastEarnedCores={lastEarnedCores}
              showNameInput={showNameInput}
              nameInput={nameInput}
              onNameInputChange={setNameInput}
              onSaveScore={saveScore}
              onShowNameInput={() => setShowNameInput(true)}
              onNavigate={setScreen}
              onStartGame={(mode) => {
                setGameMode(mode);
                setScreen('game');
              }}
            />
          )}

          {screen === 'game' && (
            <GameScreen
              mode={gameMode}
              hudState={hudState}
              upgrades={progress.upgrades}
              onGameOver={handleGameOver}
              onStateChange={setHudState}
              onMenu={() => setScreen('menu')}
            />
          )}

          {screen === 'upgrades' && (
            <UpgradesScreen
              progress={progress}
              onUpgrade={handleUpgrade}
              onBack={() => setScreen('menu')}
            />
          )}

          {screen === 'leaderboard' && (
            <LeaderboardScreen
              onBack={() => setScreen('menu')}
            />
          )}

          {screen === 'settings' && (
            <SettingsScreen
              settings={settings}
              onSettingsChange={setSettings}
              onBack={() => setScreen('menu')}
            />
          )}

          {screen === 'help' && (
            <HelpScreen onBack={() => setScreen('menu')} />
          )}

          {screen === 'admin' && (
            <AdminScreen onBack={() => setScreen('menu')} />
          )}

          {screen === 'profile' && (
            <ProfileScreen progress={progress} onBack={() => setScreen('menu')} />
          )}
        </>
      )}

    </div>
  );
}
