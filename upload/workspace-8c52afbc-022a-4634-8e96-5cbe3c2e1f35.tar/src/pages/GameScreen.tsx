'use client';

/**
 * @fileoverview GameScreen — игровой экран (HUD + GameCanvas).
 *
 * Отвечает за:
 * - Запуск/остановку музыки (обычный режим → дрон-музыка, босс → celestial-voyage.mp3)
 * - Отрисовку HUD: HP, Score, Cores, Wave, Ammunition, перезарядка
 * - Меню паузы (Escape): продолжить / завершить бой
 * - Передачу улучшений в GameCanvas для расчёта статов
 *
 * @see GameCanvas — игровой холст (canvas + game loop)
 * @see audioManager → startMusic/startBossMusic — управление музыкой
 */

import { useEffect, useRef } from 'react';
import GameCanvas from '@/game/GameCanvas';
import { audio } from '@/game/audioManager';

interface GameHudState {
  hp: number;
  maxHp: number;
  score: number;
  wave: number;
  arrows: number;
  maxArrows: number;
  reloading: boolean;
  reloadProgress: number;
  paused: boolean;
  enemiesKilled: number;
}

import { GameProgress } from '@/types/game';
import type { GameMode } from './Index';

interface GameScreenProps {
  mode: GameMode;
  hudState: GameHudState;
  upgrades: GameProgress['upgrades'];
  onGameOver: (score: number, enemiesKilled: number, wave: number, doubleCoresTriggered: number) => void;
  onStateChange: (state: GameHudState) => void;
  onMenu: () => void;
}

export default function GameScreen({
  mode,
  hudState,
  upgrades,
  onGameOver,
  onStateChange,
  onMenu,
}: GameScreenProps) {
  useEffect(() => {
    if (mode === 'boss') {
      audio.startBossMusic();
      return () => audio.stopBossMusic();
    } else {
      audio.startMusic();
      return () => audio.stopMusic();
    }
  }, [mode]);

  const hpPercent = hudState.maxHp > 0 ? (hudState.hp / hudState.maxHp) * 100 : 0;
  const hpColor = hpPercent > 60 ? '#00ff41' : hpPercent > 30 ? '#ffff00' : '#ff0000';

  const baseCores = Math.floor(hudState.score / 50) + (hudState.enemiesKilled || 0);
  const earnedCores = Math.floor(baseCores * (1 + (upgrades?.coreBonus || 0) * 0.05));

  return (
    <>
      <GameCanvas
        mode={mode}
        upgrades={upgrades}
        onGameOver={onGameOver}
        onStateChange={onStateChange}
      />

      {/* HUD top */}
      <div className="absolute top-4 left-4 right-4 flex items-start justify-between pointer-events-none animate-fade-in">
        <div className="flex gap-4">
          {/* HP Panel */}
          <div className="glass-panel p-4 rounded-2xl flex flex-col gap-2 min-w-[180px]">
            <div className="flex items-center justify-between">
              <span className="font-orbitron text-[10px] text-white/40 tracking-[0.2em] uppercase">Vitality</span>
              <span className="font-orbitron text-lg font-black neon-text-glow" style={{ color: hpColor }}>
                {Math.ceil(hudState.hp)}%
              </span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-white/5 p-0.5 border border-white/5">
              <div className="h-full rounded-full transition-all duration-300 relative overflow-hidden"
                style={{ width: `${hpPercent}%`, background: hpColor, boxShadow: `0 0 15px ${hpColor}` }}>
                <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent animate-pulse" />
              </div>
            </div>
          </div>

          {/* Score Panel */}
          <div className="glass-panel p-4 rounded-2xl flex flex-col items-center justify-center min-w-[140px]">
            <div className="font-orbitron text-[10px] text-white/40 tracking-[0.2em] uppercase mb-1">Score</div>
            <div className="font-orbitron text-2xl font-black neon-cyan neon-text-glow">{hudState.score.toLocaleString()}</div>
          </div>

          {/* Cores Earned Panel */}
          <div className="glass-panel p-4 rounded-2xl flex flex-col items-center justify-center min-w-[100px]">
            <div className="font-orbitron text-[10px] text-purple-400/60 tracking-[0.2em] uppercase mb-1">Cores</div>
            <div className="font-orbitron text-xl font-bold text-purple-300 neon-text-glow drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">+{earnedCores}</div>
          </div>
        </div>

        <div className="flex gap-4">
          {/* Wave Panel */}
          <div className="glass-panel p-4 rounded-2xl flex flex-col items-center justify-center min-w-[100px]">
            <div className="font-orbitron text-[10px] text-white/40 tracking-[0.2em] uppercase mb-1">Wave</div>
            <div className="font-orbitron text-2xl font-black neon-purple neon-text-glow">{hudState.wave}</div>
          </div>

          {/* Ammo Panel */}
          <div className="glass-panel p-4 rounded-2xl flex flex-col items-end gap-2 min-w-[140px]">
            <div className="font-orbitron text-[10px] text-white/40 tracking-[0.2em] uppercase">
              {hudState.reloading ? 'Reloading...' : 'Ammunition'}
            </div>
            <div className="flex gap-1.5 flex-wrap justify-end">
              {Array.from({ length: hudState.maxArrows }).map((_, i) => (
                <div key={i} className="w-2.5 h-5 rounded-sm transition-all duration-300"
                  style={{
                    background: i < hudState.arrows ? '#00ffff' : 'rgba(255,255,255,0.05)',
                    boxShadow: i < hudState.arrows ? '0 0 10px #00ffff' : 'none',
                    transform: i < hudState.arrows ? 'scale(1)' : 'scale(0.8)',
                    opacity: i < hudState.arrows ? 1 : 0.3,
                  }} />
              ))}
            </div>
            {hudState.reloading && (
              <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden mt-1 border border-white/5">
                <div className="h-full rounded-full transition-all"
                  style={{ width: `${hudState.reloadProgress * 100}%`, background: '#00ffff', boxShadow: '0 0 10px #00ffff' }} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <button className="absolute bottom-3 right-3 font-orbitron text-xs text-white/30 hover:text-white/60 tracking-widest transition-colors"
        onClick={() => {
          if (!hudState.paused) {
            window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Escape' }));
          }
        }}>
        [ESC] ПАУЗА
      </button>

      {/* Pause Menu Overlay */}
      {hudState.paused && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 animate-fade-in pointer-events-auto">
          <div className="glass-panel p-8 rounded-2xl flex flex-col items-center gap-6 min-w-[300px]">
            <div className="font-orbitron text-3xl font-black neon-cyan tracking-widest mb-4">ПАУЗА</div>
            
            <button 
              className="neon-btn volumetric-btn py-3 px-8 rounded-xl font-bold text-sm w-full"
              onClick={() => {
                audio.playClick();
                // We need to unpause. We can do this by triggering an Escape key event, 
                // or we can pass a resume function. Since state is in useGameLoop, 
                // dispatching a keyboard event is the easiest way to toggle it back without refactoring.
                window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Escape' }));
              }}
            >
              ПРОДОЛЖИТЬ
            </button>
            
            <button 
              className="neon-btn neon-btn-purple volumetric-btn py-3 px-8 rounded-xl font-bold text-sm w-full"
              onClick={() => {
                audio.playClick();
                onGameOver(hudState.score, hudState.enemiesKilled || 0, hudState.wave, 0);
              }}
            >
              ЗАВЕРШИТЬ БОЙ И ВЫЙТИ
            </button>
          </div>
        </div>
      )}
    </>
  );
}
