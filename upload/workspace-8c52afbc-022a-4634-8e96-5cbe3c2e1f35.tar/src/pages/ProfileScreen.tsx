'use client';

/**
 * @fileoverview ProfileScreen — профиль пилота (статистика + достижения).
 *
 * Содержит:
 * - Hero-карточку с аватаром, уровнем, кольцом прогресса достижений
 * - 3 ключевые метрики: Боевая мощь, Ядра, Достижения (X/25)
 * - Полосы прогресса прокачки и достижений
 * - Бейджи уровней редкости (Бронза/Серебро/Золото/Алмаз)
 * - 4 карточки статистики (рекорд, волна, игры, враги)
 * - 5 категорий достижений (25 шт.): Боевые, Выживание, Прогресс, Богатство, Мастерство
 * - Кнопку выхода из аккаунта (signOutAPI)
 *
 * @see lib/api.ts → signOutAPI — выход из аккаунта
 * @see config.ts → GAME_CONFIG.maxLevels — для расчёта % прокачки
 */

import { useAuth } from '@/contexts/AuthContext';
import { GameProgress } from '@/types/game';
import { audio } from '@/game/audioManager';
import { SpaceCoreIcon } from '@/components/SpaceCoreIcon';
import { signOutAPI } from '@/lib/api';
import { GAME_CONFIG } from '@/game/config';

interface ProfileScreenProps {
  onBack: () => void;
  progress: GameProgress;
}

interface Achievement {
  id: string;
  name: string;
  desc: string;
  icon: string;
  done: boolean;
  progress?: { current: number; target: number }; // for progress bar on incomplete achievements
  tier: 'bronze' | 'silver' | 'gold' | 'diamond';
}

interface AchievementCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
  achievements: Achievement[];
}

const TIER_COLORS: Record<Achievement['tier'], { border: string; bg: string; text: string; glow: string; label: string }> = {
  bronze:  { border: '#cd7f32', bg: 'rgba(205,127,50,0.08)', text: '#ffaa66', glow: 'rgba(205,127,50,0.4)',  label: 'БРОНЗА' },
  silver:  { border: '#c0c0c0', bg: 'rgba(192,192,192,0.08)', text: '#e8e8e8', glow: 'rgba(192,192,192,0.4)', label: 'СЕРЕБРО' },
  gold:    { border: '#ffd700', bg: 'rgba(255,215,0,0.08)', text: '#ffe066', glow: 'rgba(255,215,0,0.5)',   label: 'ЗОЛОТО' },
  diamond: { border: '#b9f2ff', bg: 'rgba(185,242,255,0.1)', text: '#d6f5ff', glow: 'rgba(185,242,255,0.6)', label: 'АЛМАЗ' },
};

export function ProfileScreen({ onBack, progress }: ProfileScreenProps) {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-[#070a0f]">
        <div className="text-white">Пожалуйста, войдите в систему</div>
        <button onClick={onBack} className="mt-4 neon-btn">НАЗАД</button>
      </div>
    );
  }

  const stats = progress.stats || {
    highScore: 0,
    maxWave: 0,
    gamesPlayed: 0,
    totalEnemiesKilled: 0
  };

  const u = (k: keyof GameProgress['upgrades']) => progress.upgrades[k] || 0;
  const totalUpgrades = Object.values(progress.upgrades).reduce((s, v) => s + (v || 0), 0);
  const maxUpgrades = Object.values(GAME_CONFIG.maxLevels).reduce((s, v) => s + v, 0);
  const upgradePct = maxUpgrades > 0 ? (totalUpgrades / maxUpgrades) * 100 : 0;
  const playerLevel = Math.floor(stats.gamesPlayed / 5) + 1;

  // Combat power — same formula as the stats tab
  const combatPower = Math.round(
    (100 + u('maxHp') * 5) * (1 + u('damage') * 0.15) * (1 + u('critChance') * 0.03) * (1 + u('critDamage') * 0.075)
    * (1 + u('maxArrows') * 0.08) * (1 + u('projectileSpeed') * 0.05) * (1 + u('piercing') * 0.15)
    * (1 + u('defense') * 0.03) * (1 + u('reloadSpeed') * 0.05) * (1 + u('regenSpeed') * 0.04)
  );

  const achievementCategories: AchievementCategory[] = [
    {
      id: 'combat',
      name: 'БОЕВЫЕ',
      icon: '⚔️',
      color: '#ff006e',
      achievements: [
        { id: 'first_blood', name: 'Первая кровь', desc: 'Убить первого врага', icon: '🎯', tier: 'bronze',
          done: stats.totalEnemiesKilled > 0, progress: { current: Math.min(stats.totalEnemiesKilled, 1), target: 1 } },
        { id: 'hunter', name: 'Охотник', desc: 'Убить 100 врагов', icon: '🏹', tier: 'silver',
          done: stats.totalEnemiesKilled >= 100, progress: { current: Math.min(stats.totalEnemiesKilled, 100), target: 100 } },
        { id: 'exterminator', name: 'Каратель', desc: 'Убить 1000 врагов', icon: '💀', tier: 'gold',
          done: stats.totalEnemiesKilled >= 1000, progress: { current: Math.min(stats.totalEnemiesKilled, 1000), target: 1000 } },
        { id: 'sharpshooter', name: 'Снайпер', desc: 'Набрать 5,000 очков за игру', icon: '🎯', tier: 'silver',
          done: stats.highScore >= 5000, progress: { current: Math.min(stats.highScore, 5000), target: 5000 } },
        { id: 'master', name: 'Мастер', desc: 'Набрать 10,000 очков за игру', icon: '👑', tier: 'gold',
          done: stats.highScore >= 10000, progress: { current: Math.min(stats.highScore, 10000), target: 10000 } },
        { id: 'legend', name: 'Легенда', desc: 'Набрать 50,000 очков за игру', icon: '🌟', tier: 'diamond',
          done: stats.highScore >= 50000, progress: { current: Math.min(stats.highScore, 50000), target: 50000 } },
      ],
    },
    {
      id: 'survival',
      name: 'ВЫЖИВАНИЕ',
      icon: '🛡️',
      color: '#00ff41',
      achievements: [
        { id: 'survivor', name: 'Выживший', desc: 'Достичь 5 волны', icon: '🛡️', tier: 'bronze',
          done: stats.maxWave >= 5, progress: { current: Math.min(stats.maxWave, 5), target: 5 } },
        { id: 'endurance', name: 'Стойкость', desc: 'Достичь 10 волны', icon: '🔋', tier: 'silver',
          done: stats.maxWave >= 10, progress: { current: Math.min(stats.maxWave, 10), target: 10 } },
        { id: 'unbreakable', name: 'Несокрушимый', desc: 'Достигнуть 20 волны', icon: '💪', tier: 'gold',
          done: stats.maxWave >= 20, progress: { current: Math.min(stats.maxWave, 20), target: 20 } },
        { id: 'boss_slayer', name: 'Убийца боссов', desc: 'Победить босса Омега', icon: '👹', tier: 'diamond',
          done: stats.maxWave >= 999, progress: { current: 0, target: 1 } },
      ],
    },
    {
      id: 'progression',
      name: 'ПРОГРЕСС',
      icon: '🎮',
      color: '#00ffff',
      achievements: [
        { id: 'rookie', name: 'Новобранец', desc: 'Сыграть первую игру', icon: '🎮', tier: 'bronze',
          done: stats.gamesPlayed >= 1, progress: { current: Math.min(stats.gamesPlayed, 1), target: 1 } },
        { id: 'veteran', name: 'Ветеран', desc: 'Сыграть 10 игр', icon: '🎖️', tier: 'silver',
          done: stats.gamesPlayed >= 10, progress: { current: Math.min(stats.gamesPlayed, 10), target: 10 } },
        { id: 'addict', name: 'Завсегдатай', desc: 'Сыграть 50 игр', icon: '🏅', tier: 'gold',
          done: stats.gamesPlayed >= 50, progress: { current: Math.min(stats.gamesPlayed, 50), target: 50 } },
        { id: 'level10', name: 'Опытный пилот', desc: 'Достичь 10 уровня (50 игр)', icon: '⭐', tier: 'gold',
          done: playerLevel >= 10, progress: { current: Math.min(stats.gamesPlayed, 50), target: 50 } },
      ],
    },
    {
      id: 'wealth',
      name: 'БОГАТСТВО',
      icon: '💎',
      color: '#bf00ff',
      achievements: [
        { id: 'collector', name: 'Собиратель', desc: 'Накопить 500 ядер', icon: '💫', tier: 'bronze',
          done: progress.cores >= 500, progress: { current: Math.min(progress.cores, 500), target: 500 } },
        { id: 'rich', name: 'Богач', desc: 'Накопить 1000 ядер', icon: '💎', tier: 'silver',
          done: progress.cores >= 1000, progress: { current: Math.min(progress.cores, 1000), target: 1000 } },
        { id: 'tycoon', name: 'Магнат', desc: 'Накопить 5000 ядер', icon: '💰', tier: 'gold',
          done: progress.cores >= 5000, progress: { current: Math.min(progress.cores, 5000), target: 5000 } },
      ],
    },
    {
      id: 'mastery',
      name: 'МАСТЕРСТВО',
      icon: '🔧',
      color: '#ffaa00',
      achievements: [
        { id: 'first_upgrade', name: 'Модернизация', desc: 'Купить первое улучшение', icon: '🔧', tier: 'bronze',
          done: totalUpgrades >= 1, progress: { current: Math.min(totalUpgrades, 1), target: 1 } },
        { id: 'half_max', name: 'На полпути', desc: 'Прокачать 50% улучшений', icon: '📊', tier: 'silver',
          done: upgradePct >= 50, progress: { current: Math.min(totalUpgrades, Math.floor(maxUpgrades / 2)), target: Math.floor(maxUpgrades / 2) } },
        { id: 'maxed_out', name: 'Перфекционист', desc: 'Прокачать все улучшения до максимума', icon: '🏆', tier: 'diamond',
          done: upgradePct >= 100, progress: { current: totalUpgrades, target: maxUpgrades } },
        { id: 'magnet_master', name: 'Магнитист', desc: 'Купить улучшение «Мини магнит»', icon: '🧲', tier: 'gold',
          done: u('magnetArrow') > 0, progress: { current: Math.min(u('magnetArrow'), 1), target: 1 } },
        { id: 'shockwave_master', name: 'Волнолом', desc: 'Купить улучшение «Ударная волна»', icon: '💥', tier: 'diamond',
          done: u('shockwave') > 0, progress: { current: Math.min(u('shockwave'), 1), target: 1 } },
        { id: 'double_cores', name: 'Жадина', desc: 'Купить улучшение «Двойные ядра»', icon: '✨', tier: 'gold',
          done: u('doubleCores') > 0, progress: { current: Math.min(u('doubleCores'), 1), target: 1 } },
      ],
    },
  ];

  const allAchievements = achievementCategories.flatMap(c => c.achievements);
  const unlockedCount = allAchievements.filter(a => a.done).length;
  const totalCount = allAchievements.length;
  const overallPct = (unlockedCount / totalCount) * 100;

  // Tier counts
  const tierCounts = allAchievements.reduce((acc, a) => {
    if (a.done) acc[a.tier]++;
    return acc;
  }, { bronze: 0, silver: 0, gold: 0, diamond: 0 } as Record<Achievement['tier'], number>);

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-start bg-[#070a0f] overflow-y-auto overflow-x-hidden pt-12 pb-12 custom-scrollbar">
      {/* Background ambient glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-3xl px-6 animate-fade-in relative z-10">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-orbitron font-black text-3xl md:text-4xl tracking-wider neon-cyan">ПРОФИЛЬ ПИЛОТА</h1>
          <button
            className="neon-btn volumetric-btn py-2 px-6 rounded-xl font-bold text-sm"
            onClick={() => { audio.playClick(); onBack(); }}
          >
            НАЗАД
          </button>
        </div>

        {/* ===== Hero Card ===== */}
        <div className="glass-panel rounded-2xl p-6 md:p-8 mb-8 relative overflow-hidden border border-cyan-500/20">
          <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl -ml-20 -mb-20 pointer-events-none" />

          <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8 relative z-10">
            {/* Avatar with level ring */}
            <div className="relative shrink-0">
              <svg className="w-36 h-36 -rotate-90" viewBox="0 0 144 144">
                <circle cx="72" cy="72" r="64" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="5" />
                <circle
                  cx="72" cy="72" r="64" fill="none" stroke="url(#avatar-grad)" strokeWidth="5" strokeLinecap="round"
                  strokeDasharray={`${Math.min(overallPct, 100) / 100 * 402.12} 402.12`}
                  style={{ filter: 'drop-shadow(0 0 6px rgba(0,255,255,0.5))', transition: 'stroke-dasharray 1s ease' }}
                />
                <defs>
                  <linearGradient id="avatar-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#00ffff" />
                    <stop offset="50%" stopColor="#bf00ff" />
                    <stop offset="100%" stopColor="#ff006e" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-3 rounded-full bg-black/60 border-2 border-cyan-500/50 flex items-center justify-center text-cyan-300 font-orbitron font-black text-5xl shadow-[0_0_30px_rgba(0,255,255,0.3)] overflow-hidden">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Avatar" className="w-full h-full rounded-full object-cover" />
                ) : (
                  user.displayName?.charAt(0) || user.email?.charAt(0) || 'P'
                )}
              </div>
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-purple-500 text-white text-[10px] font-orbitron font-bold px-2.5 py-1 rounded-full border border-purple-300 whitespace-nowrap shadow-[0_0_10px_rgba(191,0,255,0.5)]">
                LVL {playerLevel}
              </div>
            </div>

            {/* Identity + key stats */}
            <div className="flex-1 w-full text-center md:text-left">
              <h2 className="font-orbitron font-bold text-2xl md:text-3xl text-white mb-1 truncate">{user.displayName || 'Неизвестный Пилот'}</h2>
              <p className="font-rajdhani text-cyan-400/70 text-base mb-4 truncate">{user.email}</p>

              {/* Key metrics row */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <MetricChip icon="⚔️" label="БОЕВАЯ МОЩЬ" value={combatPower.toLocaleString()} color="#ff006e" />
                <MetricChip icon={<SpaceCoreIcon className="w-4 h-4" />} label="ЯДЕР" value={progress.cores.toLocaleString()} color="#bf00ff" />
                <MetricChip icon="🏆" label="ДОСТИЖЕНИЙ" value={`${unlockedCount}/${totalCount}`} color="#00ffff" />
              </div>

              {/* Upgrade progress bar */}
              <div className="mb-3">
                <div className="flex justify-between font-rajdhani text-[10px] text-white/40 tracking-widest uppercase mb-1">
                  <span>ПРОКАЧКА</span>
                  <span>{totalUpgrades}/{maxUpgrades} ({Math.round(upgradePct)}%)</span>
                </div>
                <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${upgradePct}%`, background: 'linear-gradient(90deg, #00ffff, #bf00ff, #ff006e)', boxShadow: '0 0 8px rgba(191,0,255,0.6)' }}
                  />
                </div>
              </div>

              {/* Achievement progress bar */}
              <div>
                <div className="flex justify-between font-rajdhani text-[10px] text-white/40 tracking-widest uppercase mb-1">
                  <span>ДОСТИЖЕНИЯ</span>
                  <span>{unlockedCount}/{totalCount} ({Math.round(overallPct)}%)</span>
                </div>
                <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${overallPct}%`, background: 'linear-gradient(90deg, #cd7f32, #c0c0c0, #ffd700, #b9f2ff)', boxShadow: '0 0 8px rgba(255,215,0,0.6)' }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Tier badges row */}
          <div className="relative z-10 flex justify-center gap-3 mt-6 pt-5 border-t border-white/5">
            {(['bronze', 'silver', 'gold', 'diamond'] as const).map(tier => {
              const total = allAchievements.filter(a => a.tier === tier).length;
              const got = tierCounts[tier];
              const tc = TIER_COLORS[tier];
              return (
                <div key={tier} className="flex flex-col items-center gap-1" title={tc.label}>
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center border"
                    style={{ borderColor: tc.border, background: tc.bg, boxShadow: got > 0 ? `0 0 12px ${tc.glow}` : 'none', opacity: got > 0 ? 1 : 0.3 }}
                  >
                    <span className="text-lg">{got > 0 ? tier === 'bronze' ? '🥉' : tier === 'silver' ? '🥈' : tier === 'gold' ? '🥇' : '💎' : '🔒'}</span>
                  </div>
                  <span className="font-orbitron text-[9px] font-bold" style={{ color: got > 0 ? tc.text : 'rgba(255,255,255,0.3)' }}>{got}/{total}</span>
                </div>
              );
            })}
          </div>

          {/* Sign out button */}
          <div className="relative z-10 flex justify-center mt-5">
            <button
              onClick={() => { audio.playClick(); signOutAPI().then(() => window.location.reload()); }}
              className="bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300 rounded-lg px-5 py-2 font-rajdhani font-bold transition-colors text-sm"
            >
              ВЫЙТИ ИЗ АККАУНТА
            </button>
          </div>
        </div>

        {/* ===== Statistics ===== */}
        <div className="flex items-center gap-3 mb-4">
          <span className="w-8 h-1 bg-cyan-500 rounded-full"></span>
          <h3 className="font-orbitron font-bold text-xl text-white/90">СТАТИСТИКА</h3>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
          <StatCard title="РЕКОРД" value={stats.highScore.toLocaleString()} icon="👑" color="cyan" />
          <StatCard title="МАКС. ВОЛНА" value={stats.maxWave.toString()} icon="🌊" color="purple" />
          <StatCard title="ИГР СЫГРАНО" value={stats.gamesPlayed.toString()} icon="🎮" color="green" />
          <StatCard title="ВРАГОВ УБИТО" value={stats.totalEnemiesKilled.toLocaleString()} icon="💀" color="pink" />
        </div>

        {/* ===== Achievements by category ===== */}
        <div className="flex items-center gap-3 mb-4">
          <span className="w-8 h-1 bg-purple-500 rounded-full"></span>
          <h3 className="font-orbitron font-bold text-xl text-white/90">ДОСТИЖЕНИЯ</h3>
          <span className="font-rajdhani text-sm text-white/40 ml-auto">{unlockedCount}/{totalCount} ОТКРЫТО</span>
        </div>

        <div className="space-y-8 mb-8">
          {achievementCategories.map(cat => {
            const catUnlocked = cat.achievements.filter(a => a.done).length;
            const catTotal = cat.achievements.length;
            const catPct = (catUnlocked / catTotal) * 100;
            return (
              <div key={cat.id}>
                {/* Category header */}
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-lg border shrink-0"
                    style={{ background: `${cat.color}15`, borderColor: `${cat.color}44`, textShadow: `0 0 10px ${cat.color}` }}
                  >
                    {cat.icon}
                  </div>
                  <div className="flex-1">
                    <div className="font-orbitron font-bold text-base tracking-wider" style={{ color: cat.color, textShadow: `0 0 6px ${cat.color}55` }}>
                      {cat.name}
                    </div>
                    <div className="font-rajdhani text-[10px] text-white/40 tracking-widest">
                      {catUnlocked}/{catTotal} ОТКРЫТО
                    </div>
                  </div>
                  {/* Mini progress */}
                  <div className="w-16 h-1.5 bg-black/40 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${catPct}%`, background: cat.color, boxShadow: `0 0 6px ${cat.color}` }} />
                  </div>
                </div>

                {/* Achievement cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {cat.achievements.map(a => {
                    const tc = TIER_COLORS[a.tier];
                    const pct = a.progress ? (a.progress.current / a.progress.target) * 100 : (a.done ? 100 : 0);
                    return (
                      <div
                        key={a.id}
                        className="relative overflow-hidden rounded-xl border p-4 transition-all duration-300 group"
                        style={{
                          borderColor: a.done ? tc.border : 'rgba(255,255,255,0.06)',
                          background: a.done ? tc.bg : 'rgba(0,0,0,0.3)',
                          opacity: a.done ? 1 : 0.7,
                        }}
                      >
                        {/* hover glow */}
                        <div className="absolute -inset-8 opacity-0 group-hover:opacity-10 transition-opacity duration-500 blur-2xl pointer-events-none" style={{ backgroundColor: tc.border }} />

                        <div className="relative z-10 flex items-center gap-3">
                          {/* Tier-tagged icon */}
                          <div
                            className="shrink-0 w-12 h-12 rounded-lg flex items-center justify-center text-2xl border-2"
                            style={{
                              borderColor: a.done ? tc.border : 'rgba(255,255,255,0.08)',
                              background: a.done ? tc.bg : 'rgba(255,255,255,0.03)',
                              boxShadow: a.done ? `0 0 14px ${tc.glow}` : 'none',
                              filter: a.done ? 'none' : 'grayscale(0.7) opacity(0.5)',
                            }}
                          >
                            {a.icon}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className="font-orbitron font-bold text-sm" style={{ color: a.done ? tc.text : 'rgba(255,255,255,0.5)' }}>{a.name}</span>
                              <span
                                className="font-orbitron text-[7px] font-bold px-1 py-0.5 rounded shrink-0"
                                style={{ color: tc.text, background: tc.bg, border: `1px solid ${tc.border}55` }}
                              >
                                {tc.label}
                              </span>
                            </div>
                            <div className="font-rajdhani text-xs text-white/40 leading-tight mb-2">{a.desc}</div>

                            {/* progress bar (only if not done and has progress) */}
                            {!a.done && a.progress && (
                              <div>
                                <div className="w-full h-1 bg-black/50 rounded-full overflow-hidden">
                                  <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: tc.border, boxShadow: `0 0 4px ${tc.glow}` }} />
                                </div>
                                <div className="font-rajdhani text-[9px] text-white/30 mt-0.5 text-right">
                                  {a.progress.current.toLocaleString()} / {a.progress.target.toLocaleString()}
                                </div>
                              </div>
                            )}
                            {a.done && (
                              <div className="flex items-center gap-1 font-rajdhani text-[10px]" style={{ color: tc.text }}>
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                </svg>
                                ПОЛУЧЕНО
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
}

function MetricChip({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string; color: string }) {
  return (
    <div className="rounded-lg border bg-black/40 px-2 py-1.5 flex flex-col items-center text-center" style={{ borderColor: `${color}33` }}>
      <div className="flex items-center gap-1 mb-0.5">
        <span className="text-sm" style={{ filter: `drop-shadow(0 0 4px ${color})` }}>{icon}</span>
      </div>
      <div className="font-orbitron text-xs font-black truncate w-full" style={{ color, textShadow: `0 0 6px ${color}55` }}>{value}</div>
      <div className="font-rajdhani text-[8px] text-white/40 tracking-widest uppercase">{label}</div>
    </div>
  );
}

function StatCard({ title, value, icon, color }: { title: string; value: string; icon: string; color: 'cyan' | 'purple' | 'green' | 'pink' }) {
  const colors = {
    cyan: { text: '#22d3ee', border: 'rgba(0,255,255,0.3)', bg: 'rgba(0,255,255,0.05)', glow: 'rgba(0,255,255,0.15)' },
    purple: { text: '#c084fc', border: 'rgba(191,0,255,0.3)', bg: 'rgba(191,0,255,0.05)', glow: 'rgba(191,0,255,0.15)' },
    green: { text: '#4ade80', border: 'rgba(0,255,65,0.3)', bg: 'rgba(0,255,65,0.05)', glow: 'rgba(0,255,65,0.15)' },
    pink: { text: '#f472b6', border: 'rgba(255,0,110,0.3)', bg: 'rgba(255,0,110,0.05)', glow: 'rgba(255,0,110,0.15)' },
  };
  const c = colors[color];

  return (
    <div className="relative overflow-hidden rounded-xl border p-4 flex flex-col items-center justify-center text-center group" style={{ borderColor: c.border, background: c.bg, boxShadow: `0 0 15px ${c.glow}` }}>
      <div className="absolute -inset-8 opacity-0 group-hover:opacity-10 transition-opacity duration-500 blur-2xl pointer-events-none" style={{ backgroundColor: c.text }} />
      <div className="text-2xl mb-1 relative z-10" style={{ filter: `drop-shadow(0 0 8px ${c.text})` }}>{icon}</div>
      <div className="font-orbitron font-bold text-2xl relative z-10" style={{ color: c.text, textShadow: `0 0 8px ${c.glow}` }}>{value}</div>
      <div className="font-rajdhani text-[10px] text-white/40 tracking-widest uppercase mt-1 relative z-10">{title}</div>
    </div>
  );
}
