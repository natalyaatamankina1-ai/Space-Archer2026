'use client';

/**
 * @fileoverview UpgradesScreen — дерево прокачки + характеристики.
 *
 * Две вкладки:
 * 1. «ДЕРЕВО ПРОКАЧКИ» — интерактивное дерево с узлами улучшений:
 *    - Базовый узел (🌌) в центре
 *    - 4 цветные ветки: Нападение (розовый), Крит (оранжевый), Защита (зелёный), Экономика (голубой)
 *    - Сателлитные узлы: Мини магнит (под Боезапас), Ударная волна (под Защиту), Двойные ядра (в голубой ветке)
 *    - Линии соединения с многослойными анимациями (свечение, поток энергии, орбы)
 *    - Поддержка pan/zoom (колёсико мыши + перетаскивание)
 *
 * 2. «ХАРАКТЕРИСТИКИ» — детальные карточки статов с базовым→финальным значением
 *
 * Структура улучшений:
 * - BRANCHES: основные ветки (4 шт.)
 * - SATELLITE_NODES: ответвления (могут требовать requiresAll — все узлы ветки на MAX)
 * - ALL_UPGRADE_ITEMS: плоский массив всех улучшений для поиска
 *
 * @see config.ts → GAME_CONFIG.maxLevels — максимальные уровни
 * @see Index.tsx → handleUpgrade — обработка покупки
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameProgress } from '@/types/game';
import { audio } from '@/game/audioManager';
import { SpaceCoreIcon } from '@/components/SpaceCoreIcon';

interface UpgradesScreenProps {
  progress: GameProgress;
  onUpgrade: (key: keyof GameProgress['upgrades'], cost: number) => void;
  onBack: () => void;
}

type UpgradeKey = keyof GameProgress['upgrades'];

interface UpgradeItem {
  key: UpgradeKey;
  name: string;
  desc: React.ReactNode;
  requires: UpgradeKey | null;
  icon: string;
  maxLevel: number;
  costs: number[];
  requiresMax?: boolean; // if true, the requirement must be at MAX level (not just 1)
  requiresAll?: UpgradeKey[]; // if present, ALL listed keys must be at MAX level
}

const BASE_NODE: UpgradeItem & { color: string } = {
  key: 'baseNode',
  name: 'Ядро Синхронизации',
  desc: 'Открывает доступ к веткам прокачки',
  requires: null,
  icon: '🌌',
  maxLevel: 1,
  costs: [20],
  color: '#eab308' // Yellow/Gold
};

const BRANCHES: { color: string; items: UpgradeItem[] }[] = [
  {
    color: '#ff006e',
    items: [
      { key: 'damage', name: 'Урон', desc: '+15% урона за уровень', requires: 'baseNode', icon: '⚔️', maxLevel: 5, costs: [50, 150, 300, 600, 1200] },
      { key: 'maxArrows', name: 'Боезапас', desc: '+1 стрела в колчане', requires: 'damage', icon: '🏹', maxLevel: 5, costs: [40, 100, 200, 400, 800] },
      { key: 'reloadSpeed', name: 'Перезарядка', desc: '-5% время перезарядки', requires: 'maxArrows', icon: '⚡', maxLevel: 5, costs: [60, 120, 250, 500, 1000] },
      { key: 'projectileSpeed', name: 'Скорость стрел', desc: '+5% скорость полета', requires: 'reloadSpeed', icon: '☄️', maxLevel: 5, costs: [50, 100, 200, 400, 800] },
      { key: 'piercing', name: 'Пробивание', desc: '+1 враг на вылет', requires: 'projectileSpeed', icon: '🌪️', maxLevel: 3, costs: [300, 800, 2000] },
    ]
  },
  {
    color: '#ffaa00',
    items: [
      { key: 'critChance', name: 'Крит. Шанс', desc: '+3% шанс крита', requires: 'baseNode', icon: '🎯', maxLevel: 5, costs: [80, 160, 320, 600, 1200] },
      { key: 'critDamage', name: 'Крит. Урон', desc: '+15% крит. урона', requires: 'critChance', icon: '💥', maxLevel: 5, costs: [100, 250, 500, 1000, 2000] },
    ]
  },
  {
    color: '#00ff41',
    items: [
      { key: 'maxHp', name: 'Прочность', desc: '+5 макс. HP за уровень', requires: 'baseNode', icon: '🛡️', maxLevel: 5, costs: [30, 80, 150, 300, 600] },
      { key: 'regenSpeed', name: 'Регенерация', desc: '+5% скорость регенерации', requires: 'maxHp', icon: '💖', maxLevel: 5, costs: [50, 120, 250, 500, 1000] },
      { key: 'defense', name: 'Броня', desc: '-3% получаемого урона', requires: 'regenSpeed', icon: '🦾', maxLevel: 5, costs: [80, 200, 400, 800, 1600] },
    ]
  },
  {
    color: '#00ffff',
    items: [
      { key: 'coreBonus', name: 'Сборщик', desc: <>+5% добыча <SpaceCoreIcon className="w-3.5 h-3.5 inline-block align-text-bottom mx-0.5" /> косм. ядер</>, requires: 'baseNode', icon: '💎', maxLevel: 5, costs: [40, 100, 250, 500, 1000] },
      { key: 'doubleCores', name: 'Двойные ядра', desc: <>Шанс получить ×2 <SpaceCoreIcon className="w-3.5 h-3.5 inline-block align-text-bottom mx-0.5" /> косм. ядер с врага (кроме босса)</>, requires: 'coreBonus', icon: '✨', maxLevel: 5, costs: [120, 300, 600, 1200, 2500] },
    ]
  }
];

// Satellite nodes branch off a parent node at a perpendicular offset.
// They use the parent's branch color and are positioned relative to the parent.
// `linkFrom` specifies which nodes draw connection lines to this satellite
// (defaults to [item.requires]); used when a node has multiple parents.
const SATELLITE_NODES: { item: UpgradeItem; parentKey: UpgradeKey; color: string; offsetX: number; offsetY: number; linkFrom?: UpgradeKey[] }[] = [
  {
    item: {
      key: 'magnetArrow',
      name: 'Мини магнит',
      desc: 'Последняя стрела в колчане слегка магнитится к врагам, увеличивая шанс попадания',
      requires: 'maxArrows',
      requiresMax: true,
      icon: '🧲',
      maxLevel: 1,
      costs: [500],
    },
    parentKey: 'maxArrows',
    color: '#ff006e',
    offsetX: 0,
    offsetY: 170, // below maxArrows
  },
  {
    item: {
      key: 'shockwave',
      name: 'Ударная волна',
      desc: 'При получении урона лук испускает ударную волну, отбрасывающую врагов во все стороны',
      requires: 'defense',
      requiresMax: true,
      requiresAll: ['maxHp', 'regenSpeed', 'defense'],
      icon: '💥',
      maxLevel: 1,
      costs: [1500],
    },
    parentKey: 'regenSpeed', // positioned below the middle green node for clean converging lines
    color: '#00ff41',
    offsetX: 0,
    offsetY: 230, // below the green line
    linkFrom: ['maxHp', 'regenSpeed', 'defense'], // lines from all 3 green nodes
  },
];

// Flatten all upgrade items (main chain + satellites) for lookups
const ALL_UPGRADE_ITEMS: (UpgradeItem & { color: string })[] = [
  { ...BASE_NODE, color: BASE_NODE.color },
  ...BRANCHES.flatMap(b => b.items.map(i => ({ ...i, color: b.color }))),
  ...SATELLITE_NODES.map(s => ({ ...s.item, color: s.color })),
];

const CONTENT_SIZE = 1800;
const CENTER = CONTENT_SIZE / 2;
const MIN_ZOOM = 0.4;
const MAX_ZOOM = 2.6;

const clampZoom = (z: number) => Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, z));

// ===== Stats tab types & helpers =====

interface StatDef {
  key: string;
  icon: string;
  name: string;
  level: number;
  maxLevel: number;
  baseLabel: string;
  finalLabel: string;
  desc: string;
}

interface StatCategoryDef {
  id: string;
  icon: string;
  name: string;
  color: string;
  stats: StatDef[];
}

function buildStatCategories(up: GameProgress['upgrades']): StatCategoryDef[] {
  const u = (k: keyof GameProgress['upgrades']) => up[k] || 0;
  return [
    {
      id: 'attack',
      icon: '⚔️',
      name: 'НАПАДЕНИЕ',
      color: '#ff006e',
      stats: [
        { key: 'damage', icon: '⚔️', name: 'Множитель урона', level: u('damage'), maxLevel: 5,
          baseLabel: '×1.00', finalLabel: `×${(1 + u('damage') * 0.15).toFixed(2)}`, desc: '+15% урона за уровень' },
        { key: 'maxArrows', icon: '🏹', name: 'Боезапас', level: u('maxArrows'), maxLevel: 5,
          baseLabel: '10 стрел', finalLabel: `${10 + u('maxArrows')} стрел`, desc: '+1 стрела в колчане' },
        { key: 'reloadSpeed', icon: '⚡', name: 'Перезарядка', level: u('reloadSpeed'), maxLevel: 5,
          baseLabel: '3.0 сек', finalLabel: `${(3 * Math.max(0.1, 1 - u('reloadSpeed') * 0.05)).toFixed(1)} сек`, desc: '−5% времени перезарядки' },
        { key: 'projectileSpeed', icon: '☄️', name: 'Скорость стрел', level: u('projectileSpeed'), maxLevel: 5,
          baseLabel: '100%', finalLabel: `+${u('projectileSpeed') * 5}%`, desc: '+5% скорости полёта' },
        { key: 'piercing', icon: '🌪️', name: 'Пробивание', level: u('piercing'), maxLevel: 3,
          baseLabel: '0 врагов', finalLabel: `${u('piercing')} враг. насквозь`, desc: 'Стрелы пробивают цели' },
        { key: 'magnetArrow', icon: '🧲', name: 'Мини магнит', level: u('magnetArrow'), maxLevel: 1,
          baseLabel: 'нет', finalLabel: u('magnetArrow') > 0 ? 'последняя стрела' : 'нет', desc: 'Последняя стрела магнитится к врагам' },
      ],
    },
    {
      id: 'critical',
      icon: '🎯',
      name: 'КРИТИЧЕСКИЙ УРОН',
      color: '#ffaa00',
      stats: [
        { key: 'critChance', icon: '🎯', name: 'Шанс крита', level: u('critChance'), maxLevel: 5,
          baseLabel: '5%', finalLabel: `${(5 + u('critChance') * 3)}%`, desc: '+3% шанса крита' },
        { key: 'critDamage', icon: '💥', name: 'Крит. урон', level: u('critDamage'), maxLevel: 5,
          baseLabel: '200%', finalLabel: `${(200 + u('critDamage') * 15)}%`, desc: '+15% крит. урона' },
      ],
    },
    {
      id: 'defense',
      icon: '🛡️',
      name: 'ЗАЩИТА',
      color: '#00ff41',
      stats: [
        { key: 'maxHp', icon: '🛡️', name: 'Макс. прочность', level: u('maxHp'), maxLevel: 5,
          baseLabel: '100 HP', finalLabel: `${100 + u('maxHp') * 5} HP`, desc: '+5 макс. HP за уровень' },
        { key: 'regenSpeed', icon: '💖', name: 'Регенерация', level: u('regenSpeed'), maxLevel: 5,
          baseLabel: '3 HP/сек', finalLabel: `${(3 * (1 + u('regenSpeed') * 0.05)).toFixed(1)} HP/сек`, desc: '+5% скорости регенерации' },
        { key: 'defense', icon: '🦾', name: 'Броня', level: u('defense'), maxLevel: 5,
          baseLabel: '0%', finalLabel: `−${u('defense') * 3}% урона`, desc: '−3% получаемого урона' },
        { key: 'shockwave', icon: '💥', name: 'Ударная волна', level: u('shockwave'), maxLevel: 1,
          baseLabel: 'нет', finalLabel: u('shockwave') > 0 ? 'отбрасывание' : 'нет', desc: 'Волна при получении урона' },
      ],
    },
    {
      id: 'economy',
      icon: '💎',
      name: 'ЭКОНОМИКА',
      color: '#00ffff',
      stats: [
        { key: 'coreBonus', icon: '💎', name: 'Добыча ядер', level: u('coreBonus'), maxLevel: 5,
          baseLabel: '100%', finalLabel: `+${u('coreBonus') * 5}%`, desc: '+5% добычи косм. ядер' },
        { key: 'doubleCores', icon: '✨', name: 'Двойные ядра', level: u('doubleCores'), maxLevel: 5,
          baseLabel: '0%', finalLabel: `${u('doubleCores') * 6}% шанс ×2`, desc: 'Шанс ×2 ядер с врага (кроме босса)' },
      ],
    },
  ];
}

/** A single rich stat row with level pips and base → final breakdown. */
function StatRow({ stat, color }: { stat: StatDef; color: string }) {
  const pct = (stat.level / stat.maxLevel) * 100;
  return (
    <div
      className="relative overflow-hidden rounded-xl border bg-black/30 p-4 transition-all duration-300 hover:-translate-y-0.5 group"
      style={{ borderColor: stat.level > 0 ? `${color}44` : 'rgba(255,255,255,0.06)' }}
    >
      {/* hover glow */}
      <div
        className="absolute -inset-10 opacity-0 group-hover:opacity-[0.08] transition-opacity duration-500 blur-2xl pointer-events-none"
        style={{ backgroundColor: color }}
      />
      <div className="relative z-10 flex items-center gap-4">
        {/* Icon badge */}
        <div
          className="shrink-0 w-12 h-12 rounded-lg flex items-center justify-center text-2xl border"
          style={{
            background: stat.level > 0 ? `${color}1a` : 'rgba(255,255,255,0.03)',
            borderColor: stat.level > 0 ? `${color}55` : 'rgba(255,255,255,0.08)',
            textShadow: stat.level > 0 ? `0 0 12px ${color}` : 'none',
            filter: stat.level > 0 ? 'none' : 'grayscale(0.6) opacity(0.5)',
          }}
        >
          {stat.icon}
        </div>

        {/* Title + value */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-0.5">
            <span className="font-rajdhani text-white/60 text-xs tracking-[0.2em] uppercase truncate">{stat.name}</span>
            <span
              className="font-orbitron text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0"
              style={{
                color: stat.level > 0 ? color : 'rgba(255,255,255,0.3)',
                background: stat.level > 0 ? `${color}15` : 'rgba(255,255,255,0.04)',
                border: `1px solid ${stat.level > 0 ? color + '44' : 'rgba(255,255,255,0.08)'}`,
              }}
            >
              {stat.level}/{stat.maxLevel}
            </span>
          </div>
          <div className="flex items-baseline gap-2 flex-wrap">
            <span
              className="font-orbitron text-xl font-black"
              style={{ color: stat.level > 0 ? color : 'rgba(255,255,255,0.5)', textShadow: stat.level > 0 ? `0 0 10px ${color}66` : 'none' }}
            >
              {stat.finalLabel}
            </span>
            {stat.level > 0 && (
              <span className="font-rajdhani text-[11px] text-white/35">
                <span className="line-through opacity-60">{stat.baseLabel}</span> → {stat.finalLabel}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Level pips */}
      <div className="relative z-10 flex gap-1 mt-3">
        {Array.from({ length: stat.maxLevel }).map((_, i) => (
          <div
            key={i}
            className="flex-1 h-1 rounded-full transition-all duration-500"
            style={{
              background: i < stat.level ? color : 'rgba(255,255,255,0.06)',
              boxShadow: i < stat.level ? `0 0 6px ${color}88` : 'none',
            }}
          />
        ))}
      </div>

      {/* Progress bar + description */}
      <div className="relative z-10 font-rajdhani text-[10px] text-white/35 flex justify-between mt-2">
        <span>{stat.desc}</span>
        <span style={{ color: stat.level > 0 ? color + 'aa' : 'rgba(255,255,255,0.25)' }}>{Math.round(pct)}%</span>
      </div>
    </div>
  );
}

/** A category block with header + its stat rows. */
function StatCategoryBlock({ category }: { category: StatCategoryDef }) {
  const acquired = category.stats.filter(s => s.level > 0).length;
  const totalLevels = category.stats.reduce((sum, s) => sum + s.level, 0);
  const maxLevels = category.stats.reduce((sum, s) => sum + s.maxLevel, 0);
  const pct = maxLevels > 0 ? (totalLevels / maxLevels) * 100 : 0;

  return (
    <div className="mb-8">
      {/* Category header */}
      <div className="flex items-center gap-3 mb-4">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center text-xl border shrink-0"
          style={{
            background: `${category.color}15`,
            borderColor: `${category.color}44`,
            textShadow: `0 0 12px ${category.color}`,
          }}
        >
          {category.icon}
        </div>
        <div className="flex-1">
          <div className="font-orbitron font-black text-lg tracking-wider" style={{ color: category.color, textShadow: `0 0 8px ${category.color}66` }}>
            {category.name}
          </div>
          <div className="font-rajdhani text-[11px] text-white/40 tracking-widest">
            {acquired}/{category.stats.length} ОТКРЫТО · {totalLevels}/{maxLevels} УРОВНЕЙ
          </div>
        </div>
        {/* Mini ring progress */}
        <div className="relative w-12 h-12 shrink-0">
          <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
            <circle cx="24" cy="24" r="20" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3" />
            <circle
              cx="24" cy="24" r="20" fill="none" stroke={category.color} strokeWidth="3" strokeLinecap="round"
              strokeDasharray={`${(pct / 100) * 125.66} 125.66`}
              style={{ filter: `drop-shadow(0 0 4px ${category.color})`, transition: 'stroke-dasharray 0.8s ease' }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center font-orbitron text-[10px] font-bold" style={{ color: category.color }}>
            {Math.round(pct)}%
          </div>
        </div>
      </div>

      {/* Stat rows */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {category.stats.map(stat => (
          <StatRow key={stat.key} stat={stat} color={category.color} />
        ))}
      </div>
    </div>
  );
}

/** Full stats tab: hero summary + categorized stats. */
function StatsTab({ progress }: { progress: GameProgress }) {
  const categories = buildStatCategories(progress.upgrades);
  const allStats = categories.flatMap(c => c.stats);
  const totalLevels = allStats.reduce((s, st) => s + st.level, 0);
  const maxLevels = allStats.reduce((s, st) => s + st.maxLevel, 0);
  const overallPct = maxLevels > 0 ? (totalLevels / maxLevels) * 100 : 0;

  // Combat Power — weighted aggregate for a satisfying single number
  const u = (k: keyof GameProgress['upgrades']) => progress.upgrades[k] || 0;
  const combatPower = Math.round(
    (100 + u('maxHp') * 5) * (1 + u('damage') * 0.15) * (1 + u('critChance') * 0.03) * (1 + u('critDamage') * 0.075)
    * (1 + u('maxArrows') * 0.08) * (1 + u('projectileSpeed') * 0.05) * (1 + u('piercing') * 0.15)
    * (1 + u('defense') * 0.03) * (1 + u('reloadSpeed') * 0.05) * (1 + u('regenSpeed') * 0.04)
  );

  const baseUnlocked = u('baseNode') > 0;

  return (
    <div className="w-full max-w-4xl mx-auto mt-4 mb-16 animate-fade-in">
      {/* Hero summary panel */}
      <div className="glass-panel rounded-2xl p-6 mb-8 relative overflow-hidden border border-white/10">
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
          {/* Overall progress ring */}
          <div className="relative w-28 h-28 shrink-0">
            <svg className="w-28 h-28 -rotate-90" viewBox="0 0 112 112">
              <circle cx="56" cy="56" r="48" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
              <circle
                cx="56" cy="56" r="48" fill="none" stroke="url(#hero-grad)" strokeWidth="6" strokeLinecap="round"
                strokeDasharray={`${(overallPct / 100) * 301.59} 301.59`}
                style={{ filter: 'drop-shadow(0 0 8px rgba(0,255,255,0.6))', transition: 'stroke-dasharray 1s ease' }}
              />
              <defs>
                <linearGradient id="hero-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00ffff" />
                  <stop offset="50%" stopColor="#bf00ff" />
                  <stop offset="100%" stopColor="#ff006e" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-orbitron text-2xl font-black neon-cyan">{Math.round(overallPct)}%</span>
              <span className="font-rajdhani text-[9px] text-white/40 tracking-widest uppercase">Прокачка</span>
            </div>
          </div>

          {/* Summary stats */}
          <div className="flex-1 w-full">
            <div className="font-orbitron font-black text-xl text-white mb-1 tracking-wider">
              {baseUnlocked ? 'ПРОФИЛЬ БОЕВОЙ МОЩИ' : 'БАЗОВАЯ КОНФИГУРАЦИЯ'}
            </div>
            <div className="font-rajdhani text-white/40 text-sm mb-4 tracking-widest">
              {totalLevels} / {maxLevels} УРОВНЕЙ УЛУЧШЕНИЙ
            </div>
            <div className="grid grid-cols-3 gap-3">
              <SummaryStat label="БОЕВАЯ МОЩЬ" value={combatPower.toLocaleString()} color="#ff006e" />
              <SummaryStat label="ЯДЕР" value={progress.cores.toLocaleString()} color="#bf00ff" icon />
              <SummaryStat label="УЛУЧШЕНИЙ" value={`${totalLevels}/${maxLevels}`} color="#00ffff" />
            </div>
          </div>
        </div>
      </div>

      {/* Category sections */}
      {categories.map(cat => (
        <StatCategoryBlock key={cat.id} category={cat} />
      ))}
    </div>
  );
}

function SummaryStat({ label, value, color, icon }: { label: string, value: string, color: string, icon?: boolean }) {
  return (
    <div
      className="rounded-xl border p-3 flex flex-col items-center justify-center text-center bg-black/30"
      style={{ borderColor: `${color}33` }}
    >
      <div className="font-rajdhani text-[9px] text-white/40 tracking-widest uppercase mb-1">{label}</div>
      <div className="font-orbitron text-lg font-black flex items-center gap-1.5" style={{ color, textShadow: `0 0 8px ${color}66` }}>
        {icon && <SpaceCoreIcon className="w-4 h-4" />}
        {value}
      </div>
    </div>
  );
}

/**
 * Pan + wheel-zoom canvas for the upgrade tree.
 * Defined at module scope (NOT inside UpgradesScreen) so it keeps a stable
 * component identity across re-renders — otherwise its refs/transform would
 * reset every time the parent updates state.
 */
function UpgradeTreeCanvas({
  children,
  onZoomChange,
}: {
  children: React.ReactNode;
  onZoomChange: (zoom: number) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const transformRef = useRef({ zoom: 1, panX: 0, panY: 0 });
  // displayZoom mirrors the ref into state so we can read it during render
  // for the zoom indicator (refs must not be read during render).
  const [displayZoom, setDisplayZoom] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, panX: 0, panY: 0, moved: false });

  const applyTransform = useCallback(() => {
    const el = contentRef.current;
    if (el) {
      const { zoom, panX, panY } = transformRef.current;
      el.style.transform = `translate(${panX}px, ${panY}px) scale(${zoom})`;
    }
    onZoomChange(transformRef.current.zoom);
    setDisplayZoom(transformRef.current.zoom);
  }, [onZoomChange]);

  // Center the content on first mount
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const cw = el.clientWidth;
    const ch = el.clientHeight;
    transformRef.current = {
      zoom: 1,
      panX: cw / 2 - CENTER,
      panY: ch / 2 - CENTER,
    };
    applyTransform();
    const handleResize = () => {
      const z = transformRef.current.zoom;
      transformRef.current.panX = el.clientWidth / 2 - CENTER * z;
      transformRef.current.panY = el.clientHeight / 2 - CENTER * z;
      applyTransform();
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [applyTransform]);

  // Non-passive wheel listener so we can preventDefault page scroll
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      const { zoom: prevZoom, panX: prevPanX, panY: prevPanY } = transformRef.current;
      const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
      const newZoom = clampZoom(prevZoom * factor);
      const actualFactor = newZoom / prevZoom;
      transformRef.current.zoom = newZoom;
      transformRef.current.panX = cx - (cx - prevPanX) * actualFactor;
      transformRef.current.panY = cy - (cy - prevPanY) * actualFactor;
      applyTransform();
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [applyTransform]);

  const onMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    dragStart.current = {
      x: e.clientX,
      y: e.clientY,
      panX: transformRef.current.panX,
      panY: transformRef.current.panY,
      moved: false,
    };
    setIsDragging(true);
  };

  const onMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) dragStart.current.moved = true;
    transformRef.current.panX = dragStart.current.panX + dx;
    transformRef.current.panY = dragStart.current.panY + dy;
    applyTransform();
  };

  const zoomBy = useCallback((factor: number) => {
    const el = containerRef.current;
    if (!el) return;
    const cx = el.clientWidth / 2;
    const cy = el.clientHeight / 2;
    const { zoom: prevZoom, panX: prevPanX, panY: prevPanY } = transformRef.current;
    const newZoom = clampZoom(prevZoom * factor);
    const actualFactor = newZoom / prevZoom;
    transformRef.current.zoom = newZoom;
    transformRef.current.panX = cx - (cx - prevPanX) * actualFactor;
    transformRef.current.panY = cy - (cy - prevPanY) * actualFactor;
    applyTransform();
  }, [applyTransform]);

  const resetView = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    transformRef.current = {
      zoom: 1,
      panX: el.clientWidth / 2 - CENTER,
      panY: el.clientHeight / 2 - CENTER,
    };
    applyTransform();
  }, [applyTransform]);

  const currentZoom = displayZoom;

  return (
    <div
      className="w-full h-[65vh] min-h-[500px] overflow-hidden rounded-3xl border border-white/15 shadow-2xl relative bg-black/40 touch-none select-none"
      ref={containerRef}
      onMouseDown={onMouseDown}
      onMouseUp={() => setIsDragging(false)}
      onMouseLeave={() => setIsDragging(false)}
      onMouseMove={onMouseMove}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
    >
      <div
        ref={contentRef}
        className="absolute top-0 left-0"
        style={{
          width: CONTENT_SIZE,
          height: CONTENT_SIZE,
          transformOrigin: '0 0',
          willChange: 'transform',
        }}
      >
        <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,255,255,0.06),transparent_60%)] pointer-events-none" />
        {children}
      </div>

      {/* Zoom controls overlay */}
      <div className="absolute bottom-3 right-3 flex flex-col gap-1.5 z-40">
        <button
          onClick={() => { audio.playClick(); zoomBy(1.2); }}
          className="w-9 h-9 rounded-lg glass-panel border border-cyan-500/30 text-cyan-300 font-orbitron font-bold text-lg flex items-center justify-center hover:border-cyan-400/60 hover:bg-cyan-500/10 transition-all shadow-[0_0_10px_rgba(0,255,255,0.15)]"
          title="Приблизить"
        >
          +
        </button>
        <button
          onClick={() => { audio.playClick(); zoomBy(1 / 1.2); }}
          className="w-9 h-9 rounded-lg glass-panel border border-cyan-500/30 text-cyan-300 font-orbitron font-bold text-lg flex items-center justify-center hover:border-cyan-400/60 hover:bg-cyan-500/10 transition-all shadow-[0_0_10px_rgba(0,255,255,0.15)]"
          title="Отдалить"
        >
          −
        </button>
        <button
          onClick={() => { audio.playClick(); resetView(); }}
          className="w-9 h-9 rounded-lg glass-panel border border-cyan-500/30 text-cyan-300 font-orbitron font-bold text-[10px] flex items-center justify-center hover:border-cyan-400/60 hover:bg-cyan-500/10 transition-all shadow-[0_0_10px_rgba(0,255,255,0.15)]"
          title="Сбросить вид"
        >
          1:1
        </button>
      </div>

      {/* Zoom level indicator */}
      <div className="absolute bottom-3 left-3 z-40 glass-panel px-3 py-1.5 rounded-lg border border-white/10 font-orbitron text-xs text-cyan-300/80 tracking-widest shadow-[0_0_10px_rgba(0,0,0,0.4)]">
        {Math.round(currentZoom * 100)}%
      </div>
    </div>
  );
}

export function UpgradesScreen({ progress, onUpgrade, onBack }: UpgradesScreenProps) {
  const [activeTab, setActiveTab] = useState<'tree' | 'stats'>('tree');
  // Live tree zoom — lifted to this level so node tooltips can counter-scale
  // and stay readable at any zoom level. Pan stays inside UpgradeTreeCanvas
  // (ref) for smooth, re-render-free dragging.
  const [treeZoom, setTreeZoom] = useState(1);
  const reportZoom = useCallback((z: number) => setTreeZoom(z), []);

  const renderNode = (item: UpgradeItem, color: string, x: number, y: number, zoom: number) => {
    const level = progress.upgrades[item.key] || 0;
    const isMax = level >= item.maxLevel;
    // Guard against missing cost entry (e.g. old save with higher level than costs array)
    const cost = isMax ? 0 : (item.costs[level] ?? 0);
    const canAfford = progress.cores >= cost;

    const reqLevel = item.requires ? (progress.upgrades[item.requires] || 0) : 1;
    const reqItemDef = item.requires ? ALL_UPGRADE_ITEMS.find(i => i.key === item.requires) : null;
    const reqMaxLevel = reqItemDef ? reqItemDef.maxLevel : 1;

    // Lock logic:
    // - requiresAll → ALL listed keys must be at MAX
    // - requiresMax → single requirement must be at MAX
    // - otherwise → requirement level ≥ 1
    const isLocked = item.requiresAll
      ? item.requiresAll.some(k => {
          const def = ALL_UPGRADE_ITEMS.find(i => i.key === k);
          const max = def ? def.maxLevel : 1;
          return (progress.upgrades[k] || 0) < max;
        })
      : item.requires
        ? (item.requiresMax ? reqLevel < reqMaxLevel : reqLevel < 1)
        : false;

    const tooltipPositionClass = "top-full left-1/2 -translate-x-1/2 mt-4";

    // Build requirement description for the tooltip
    let reqName = '';
    if (item.requiresAll && item.requiresAll.length > 0) {
      reqName = item.requiresAll
        .map(k => ALL_UPGRADE_ITEMS.find(i => i.key === k)?.name || k)
        .join(', ');
    } else if (item.requires) {
      reqName = ALL_UPGRADE_ITEMS.find(i => i.key === item.requires)?.name || '';
    }

    const isBaseNode = item.key === 'baseNode';
    const ringSizeClass = isBaseNode ? "w-36 h-36" : "w-24 h-24";
    const buttonSizeClass = isBaseNode ? "w-20 h-20" : "w-16 h-16";
    // Counter-scale the tooltip so it stays readable at any zoom level
    const tooltipScale = 1 / zoom;

    return (
      <div
        key={item.key}
        className="absolute z-10"
        style={{ left: x, top: y, transform: 'translate(-50%, -50%)' }}
      >
        <div className={`relative group ${ringSizeClass} flex items-center justify-center`}>
          {/* Outermost soft aura halo */}
          {!isLocked && (
            <div
              className="absolute rounded-full pointer-events-none"
              style={{
                inset: '-30%',
                background: `radial-gradient(circle, ${color}33 0%, transparent 65%)`,
                filter: 'blur(8px)',
                animation: 'tree-socket-breathe 3s ease-in-out infinite',
              }}
            />
          )}

          {/* Outer rotating energy ring (only when unlocked / affordable) */}
          {!isLocked && (
            <div
              className={`absolute inset-0 rounded-full transition-opacity duration-500 opacity-80 group-hover:opacity-100 ${isMax ? 'animate-spin-slow-reverse' : 'animate-spin-slow'}`}
              style={{ filter: `drop-shadow(0 0 10px ${color}aa)` }}
            >
              <div
                className="absolute inset-0 rounded-full"
                style={{
                  padding: '5px',
                  backgroundImage: isBaseNode
                    ? `conic-gradient(from 0deg, #00ffff, #ff006e, #ffaa00, #00ff41, #00ffff)`
                    : `conic-gradient(from 0deg, ${color}, #ffffff, ${color}, ${color}88, ${color})`,
                  WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                  WebkitMaskComposite: 'xor',
                  maskImage: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                  maskComposite: 'exclude',
                }}
              />
            </div>
          )}

          {/* Inner counter-rotating dashed ring */}
          {!isLocked && (
            <div
              className="absolute rounded-full pointer-events-none animate-spin-slow-reverse"
              style={{
                inset: isBaseNode ? '14%' : '10%',
                border: `1px dashed ${color}66`,
                animationDuration: '14s',
              }}
            />
          )}

          {/* Locked dim ring */}
          {isLocked && (
            <div
              className="absolute inset-0 rounded-full"
              style={{
                border: '2px dashed rgba(255,255,255,0.12)',
                background: 'rgba(0,0,0,0.35)',
              }}
            />
          )}

          {/* Core button */}
          <button
            className={`relative ${buttonSizeClass} rounded-full border-2 flex flex-col items-center justify-center transition-all duration-300 z-10 ${isLocked ? 'cursor-not-allowed' : (canAfford && !isMax ? 'cursor-pointer hover:scale-110 node-can-afford' : 'cursor-default')}`}
            style={{
              borderColor: isLocked ? 'rgba(255,255,255,0.1)' : color,
              backgroundColor: isLocked ? 'rgba(0,0,0,0.6)' : (isMax ? `${color}55` : `${color}1a`),
              color: color,
              boxShadow: isLocked ? 'none' : `0 0 ${isMax ? '24px' : '12px'} ${color}77, inset 0 0 14px ${color}22`,
            }}
            onClick={() => {
              if (!isLocked && !isMax && canAfford) {
                audio.playClick();
                onUpgrade(item.key, cost);
              }
            }}
          >
            {isLocked && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-full z-20">
                <span className="text-2xl drop-shadow-md">🔒</span>
              </div>
            )}

            {isMax && (
              <div className="absolute -top-2 -right-2 bg-black border border-white/20 text-[8px] font-orbitron font-bold px-1.5 py-0.5 rounded text-white z-20" style={{ borderColor: color, color, boxShadow: `0 0 6px ${color}` }}>
                MAX
              </div>
            )}

            <span className={`${isBaseNode ? 'text-4xl' : 'text-2xl'} ${isLocked ? 'grayscale opacity-30' : 'drop-shadow-[0_0_8px_currentColor)]'}`} style={{ textShadow: isLocked ? 'none' : `0 0 10px ${color}` }}>{item.icon}</span>
            <span className={`font-orbitron font-bold mt-1 tracking-widest ${isBaseNode ? 'text-xs' : 'text-[9px]'}`} style={{ color: isLocked ? 'rgba(255,255,255,0.3)' : '#fff' }}>
              {level}/{item.maxLevel}
            </span>
          </button>

          {/* Tooltip — counter-scaled to stay readable at any zoom */}
          <div
            className={`absolute ${tooltipPositionClass} w-60 p-5 rounded-xl glass-panel opacity-0 pointer-events-none group-hover:opacity-100 transition-all duration-300 z-50 text-left border border-white/10 backdrop-blur-xl shadow-2xl`}
            style={{
              boxShadow: `0 15px 35px -5px ${color}88, inset 0 0 20px ${color}11`,
              transform: `translateX(-50%) scale(${tooltipScale})`,
              transformOrigin: 'top center',
            }}
          >
            <div className="absolute top-0 left-0 w-full h-1" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />
            <div className="font-orbitron font-bold text-base mb-1" style={{ color, textShadow: `0 0 10px ${color}88` }}>{item.name}</div>
            <div className="font-rajdhani text-sm text-white/80 mb-4 leading-relaxed">{item.desc}</div>

            <div className="flex justify-between items-center font-orbitron text-xs mb-1">
              <span className="text-white/50">УРОВЕНЬ:</span>
              <span className="text-white">{level} / {item.maxLevel}</span>
            </div>

            <div className="flex justify-between items-center font-orbitron text-xs">
              <span className="text-white/50">ЦЕНА:</span>
              <span style={{ color: isMax ? '#00ff41' : (canAfford ? '#00ffff' : '#ff0000') }}>
                {isMax ? 'МАКСИМУМ' : cost}
              </span>
            </div>

            {isLocked && (
              <div className="mt-3 pt-2 border-t border-white/10 text-[10px] text-red-400 font-rajdhani text-center">
                {item.requiresAll
                  ? <>ТРЕБУЕТСЯ MAX: {reqName}</>
                  : <>ТРЕБУЕТСЯ: {reqName} {item.requiresMax ? `MAX (${reqMaxLevel}/${reqMaxLevel})` : 'LVL 1'}</>}
              </div>
            )}
            {!isLocked && !isMax && (
              <div className="mt-3 pt-2 border-t border-white/10 text-[10px] text-center font-rajdhani" style={{ color: canAfford ? '#00ff41' : '#ff0000' }}>
                {canAfford ? 'КЛИКНИТЕ ДЛЯ ПОКУПКИ' : 'НЕДОСТАТОЧНО ЯДЕР'}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const baseUnlocked = (progress.upgrades.baseNode || 0) > 0;

  // ===== Build node positions & enhanced links =====
  const buildTree = () => {
    const CENTER_X = CENTER;
    const CENTER_Y = CENTER;
    const NODE_SPACING = 160;

    const nodePositions: Record<string, { x: number, y: number, color: string, unlocked: boolean }> = {};
    nodePositions['baseNode'] = { x: CENTER_X, y: CENTER_Y, color: BASE_NODE.color, unlocked: baseUnlocked };

    const branchAngles = [0, Math.PI / 2, Math.PI, -Math.PI / 2];

    BRANCHES.forEach((branch, bIdx) => {
      const angle = branchAngles[bIdx];
      branch.items.forEach((item, iIdx) => {
        const dist = (iIdx + 1) * NODE_SPACING;
        const zigZagOffset = (iIdx % 2 === 0) ? 35 : -35;
        const x = CENTER_X + Math.cos(angle) * dist - Math.sin(angle) * zigZagOffset;
        const y = CENTER_Y + Math.sin(angle) * dist + Math.cos(angle) * zigZagOffset;
        const unlocked = (progress.upgrades[item.key] || 0) > 0;
        nodePositions[item.key] = { x, y, color: branch.color, unlocked };
      });
    });

    // Position satellite nodes relative to their parent
    SATELLITE_NODES.forEach(sat => {
      const parent = nodePositions[sat.parentKey];
      if (parent) {
        const unlocked = (progress.upgrades[sat.item.key] || 0) > 0;
        nodePositions[sat.item.key] = {
          x: parent.x + sat.offsetX,
          y: parent.y + sat.offsetY,
          color: sat.color,
          unlocked,
        };
      }
    });

    // Helper to build a single link element from `fromKey` to `item`'s node.
    // Used for both main-chain links and satellite links (which may have
    // multiple parents via linkFrom / requiresAll).
    const buildLink = (
      linkKey: string,
      fromKey: UpgradeKey,
      item: UpgradeItem,
      nodePositions: Record<string, { x: number, y: number, color: string, unlocked: boolean }>,
    ): React.ReactElement | null => {
      const from = nodePositions[fromKey];
      const to = nodePositions[item.key];
      if (!from || !to) return null;
      const isUnlocked = from.unlocked;
      const childUnlocked = to.unlocked;

      const dx = to.x - from.x;
      const dy = to.y - from.y;
      const distance = Math.hypot(dx, dy);
      if (distance === 0) return null;

      // Lines start/end exactly on the outer ring rim.
      const fromRadius = fromKey === 'baseNode' ? 72 : 48;
      const toRadius = item.key === 'baseNode' ? 72 : 48;
      const startX = from.x + (dx / distance) * fromRadius;
      const startY = from.y + (dy / distance) * fromRadius;
      const length = Math.max(0, distance - fromRadius - toRadius);
      const angleDeg = Math.atan2(dy, dx) * 180 / Math.PI;

      return (
        <div
          key={linkKey}
          className="absolute"
          style={{
            left: startX,
            top: startY,
            width: length,
            height: 0,
            transform: `rotate(${angleDeg}deg)`,
            transformOrigin: '0 0',
            zIndex: 1,
          }}
        >
          {isUnlocked ? (
            <>
              {/* Layer 1 — wide soft outer glow */}
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: '100%', height: 16,
                  transform: 'translateY(-50%)',
                  background: `linear-gradient(90deg, transparent 0%, ${from.color}55 15%, ${to.color}55 85%, transparent 100%)`,
                  filter: 'blur(7px)',
                  opacity: childUnlocked ? 0.9 : 0.55,
                }}
              />
              {/* Layer 2 — steady two-color base gradient */}
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: '100%', height: 5,
                  transform: 'translateY(-50%)',
                  background: `linear-gradient(90deg, ${from.color}, ${to.color})`,
                  opacity: 0.75,
                  boxShadow: `0 0 8px ${from.color}88`,
                }}
              />
              {/* Layer 3 — flowing multi-pulse energy */}
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: '100%', height: 3,
                  transform: 'translateY(-50%)',
                  background: `linear-gradient(90deg,
                    transparent 0%,
                    ${from.color} 8%,
                    #ffffff 14%,
                    ${to.color} 20%,
                    transparent 33%,
                    transparent 50%,
                    ${from.color} 58%,
                    #ffffff 64%,
                    ${to.color} 70%,
                    transparent 86%,
                    transparent 100%)`,
                  backgroundSize: '250% 100%',
                  animation: 'tree-link-flow 2.4s linear infinite',
                  opacity: 0.95,
                  mixBlendMode: 'screen',
                }}
              />
              {/* Layer 4 — bright white core thread */}
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: '100%', height: 1.5,
                  transform: 'translateY(-50%)',
                  background: 'linear-gradient(90deg, rgba(255,255,255,0.3), rgba(255,255,255,0.95), rgba(255,255,255,0.3))',
                  boxShadow: '0 0 4px rgba(255,255,255,0.6)',
                }}
              />
              {/* Layer 5 — traveling energy orb */}
              <div
                className="absolute rounded-full pointer-events-none"
                style={{
                  top: '50%', width: 14, height: 14,
                  background: `radial-gradient(circle, #ffffff 0%, ${to.color} 40%, transparent 70%)`,
                  filter: 'blur(0.5px)',
                  animation: `tree-link-pulse-travel ${2.4 + (item.key.length % 3) * 0.4}s linear infinite`,
                  animationDelay: `${(item.key.charCodeAt(0) % 10) * 0.2}s`,
                  boxShadow: `0 0 12px ${to.color}`,
                }}
              />
              {/* Start socket */}
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: 12, height: 12,
                  transform: 'translate(-50%, -50%)',
                  background: `radial-gradient(circle, #ffffff 0%, ${from.color} 60%)`,
                  boxShadow: `0 0 10px ${from.color}, 0 0 20px ${from.color}88`,
                  animation: 'tree-socket-breathe 2.5s ease-in-out infinite',
                }}
              />
              {/* End socket */}
              <div
                className="absolute rounded-full"
                style={{
                  left: '100%', top: '50%',
                  width: childUnlocked ? 12 : 9, height: childUnlocked ? 12 : 9,
                  transform: 'translate(-50%, -50%)',
                  background: childUnlocked
                    ? `radial-gradient(circle, #ffffff 0%, ${to.color} 60%)`
                    : `radial-gradient(circle, ${to.color} 0%, ${to.color}88 60%, transparent 100%)`,
                  boxShadow: childUnlocked
                    ? `0 0 10px ${to.color}, 0 0 20px ${to.color}88`
                    : `0 0 6px ${to.color}66`,
                  border: childUnlocked ? 'none' : `1px solid ${to.color}aa`,
                  animation: 'tree-socket-breathe 2.5s ease-in-out infinite',
                }}
              />
            </>
          ) : (
            <>
              {/* Locked link — dim dashed shimmer */}
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: '100%', height: 6,
                  transform: 'translateY(-50%)',
                  background: 'repeating-linear-gradient(90deg, rgba(255,255,255,0.18) 0px, rgba(255,255,255,0.18) 8px, transparent 8px, transparent 18px)',
                  backgroundSize: '32px 100%',
                  animation: 'tree-link-locked-shimmer 2s linear infinite',
                  opacity: 0.5,
                  filter: 'blur(0.5px)',
                }}
              />
              <div
                className="absolute rounded-full"
                style={{
                  left: 0, top: '50%', width: 8, height: 8,
                  transform: 'translate(-50%, -50%)',
                  background: 'rgba(0,0,0,0.6)',
                  border: '1px solid rgba(255,255,255,0.2)',
                }}
              />
              <div
                className="absolute rounded-full"
                style={{
                  left: '100%', top: '50%', width: 8, height: 8,
                  transform: 'translate(-50%, -50%)',
                  background: 'rgba(0,0,0,0.6)',
                  border: '1px solid rgba(255,255,255,0.12)',
                }}
              />
            </>
          )}
        </div>
      );
    };

    // Build enhanced link elements for main chain + satellites
    const links: React.ReactElement[] = [];
    BRANCHES.forEach(branch => {
      branch.items.forEach(item => {
        const link = buildLink(`link-${item.key}`, item.requires!, item, nodePositions);
        if (link) links.push(link);
      });
    });
    SATELLITE_NODES.forEach(sat => {
      // Determine which nodes draw links to this satellite.
      // Defaults to [item.requires]; linkFrom overrides (e.g. multiple parents).
      const sources = sat.linkFrom || (sat.item.requires ? [sat.item.requires] : []);
      sources.forEach(srcKey => {
        const link = buildLink(`link-sat-${sat.item.key}-${srcKey}`, srcKey, sat.item, nodePositions);
        if (link) links.push(link);
      });
    });

    return { nodePositions, links };
  };

  const { nodePositions, links } = buildTree();

  return (
    <div className="absolute inset-0 flex flex-col items-center pt-8 px-4 animate-fade-in overflow-auto bg-[#070a0f]">
      {/* Dynamic Grid Background */}
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,255,255,0.05),transparent_50%)] pointer-events-none" />

      <div className="w-full max-w-5xl relative z-10">
        <div className="flex justify-between items-center mb-10">
          <div>
            <div className="flex gap-6 mb-2">
              <button
                className={`font-orbitron text-xl md:text-2xl font-black tracking-wider transition-all pb-1 ${activeTab === 'tree' ? 'neon-cyan border-b-2 border-[#00ffff]' : 'text-white/40 hover:text-white/70'}`}
                onClick={() => { audio.playClick(); setActiveTab('tree'); }}
              >
                ДЕРЕВО ПРОКАЧКИ
              </button>
              <button
                className={`font-orbitron text-xl md:text-2xl font-black tracking-wider transition-all pb-1 ${activeTab === 'stats' ? 'neon-purple border-b-2 border-[#bf00ff]' : 'text-white/40 hover:text-white/70'}`}
                onClick={() => { audio.playClick(); setActiveTab('stats'); }}
              >
                ХАРАКТЕРИСТИКИ
              </button>
            </div>
            <div className="font-rajdhani text-white/40 text-sm tracking-widest">
              {activeTab === 'tree' ? 'УЛУЧШЕНИЕ ХАРАКТЕРИСТИК' : 'ТЕКУЩИЕ ПАРАМЕТРЫ ПЕРСОНАЖА'}
            </div>
          </div>
          <div className="glass-panel px-6 py-3 rounded-xl flex flex-col items-end hidden sm:flex">
            <div className="font-rajdhani text-white/40 text-xs tracking-widest">КОСМИЧЕСКИЕ ЯДРА</div>
            <div className="font-orbitron text-2xl font-black neon-purple flex items-center gap-2">
              <SpaceCoreIcon className="w-8 h-8" />
              {progress.cores.toLocaleString()}
            </div>
          </div>
        </div>

        {activeTab === 'tree' ? (
          <div className="flex flex-col items-center relative w-full mt-4 mb-2 animate-fade-in">
            <div className="font-rajdhani text-white/30 text-xs tracking-widest mb-4 text-center uppercase">
              Колёсико мыши — масштаб · Перетаскивайте — перемещение · Наведите на узел для информации
            </div>
            <UpgradeTreeCanvas onZoomChange={reportZoom}>
              {links}
              {ALL_UPGRADE_ITEMS.map(item => {
                const pos = nodePositions[item.key];
                if (!pos) return null;
                return renderNode(item, pos.color, pos.x, pos.y, treeZoom);
              })}
            </UpgradeTreeCanvas>
          </div>
        ) : (
          <StatsTab progress={progress} />
        )}

        <button className="neon-btn py-3 px-6 rounded text-sm font-bold w-full max-w-md mx-auto block mt-8"
          onClick={() => { audio.playClick(); onBack(); }}>
          ← НАЗАД В МЕНЮ
        </button>
      </div>
    </div>
  );
}
