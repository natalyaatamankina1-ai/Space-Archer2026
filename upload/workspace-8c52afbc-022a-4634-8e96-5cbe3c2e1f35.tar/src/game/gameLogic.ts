/**
 * @fileoverview Игровая логика SPACE ARCHER.
 *
 * Этот модуль содержит всю сервер-независимую игровую логику:
 * - Состояние игры (InternalGameState)
 * - Спавн врагов (tickSpawn)
 * - Движение врагов и столкновения (tickEnemies)
 * - Движение стрел и попадания (tickProjectiles)
 * - Очистку мёртвых объектов (tickCleanup)
 * - Способности босса (гравитационные лучи, мини-чёрные дыры)
 * - Пыль в режиме босса (tickDustParticles)
 *
 * Все функции «tick*» вызываются из useGameLoop.ts каждый кадр (~60fps).
 * Функции не используют React — это чистый игровой движок.
 *
 * @see useGameLoop.ts — где вызываются эти функции
 * @see gameRenderer.ts — где результаты отрисовываются
 */

import { Enemy, Projectile, Particle, DustParticle, ENEMY_TYPES, createEnemy } from './enemies';
import { audio } from './audioManager';
import { GAME_CONFIG } from './config';

export interface InternalGameState {
  mode: 'classic' | 'boss';
  hp: number;
  maxHp: number;
  hpRegenRate: number;
  hpRegenTimer: number;
  invulnTimer: number;
  score: number;
  wave: number;
  arrows: number;
  maxArrows: number;
  reloading: boolean;
  reloadProgress: number;
  reloadTimer: number;
  reloadFrames: number;
  damageMult: number;
  piercingVal: number;
  projSpeedMult: number;
  critChance: number;
  critDamage: number;
  defenseMult: number;
  magnetArrow: number;
  shockwave: number;
  activeShockwaves: { x: number; y: number; radius: number; maxRadius: number; life: number; maxLife: number }[];
  doubleCores: number;
  doubleCoresTriggered: number;
  dustParticles: DustParticle[];
  spawnTimer: number;
  waveTimer: number;
  enemies: Enemy[];
  projectiles: Projectile[];
  particles: Particle[];
  alive: boolean;
  bowPulse: number;
  canShoot: boolean;
  shootCooldown: number;
  frame: number;
  paused: boolean;
  enemiesKilled: number;
  // Boss abilities
  bossGravityBeamTimer: number;   // countdown to next beam pulse
  bossGravityBeams: { x1: number; y1: number; x2: number; y2: number; life: number; maxLife: number; targetIdx: number }[];
  miniBlackHoles: { x: number; y: number; radius: number; absorbRadius: number; life: number; maxLife: number; angle: number }[];
  miniBlackHoleTimer: number;     // countdown to next mini BH spawn (phase 1+)
  bossPhase: number;              // 0, 1, 2
}

export function spawnParticles(s: InternalGameState, x: number, y: number, color: string, count = 8) {
  if (s.particles.length > 300) return;
  if (s.particles.length > 200) count = Math.min(count, 3);
  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5;
    const speed = 1.5 + Math.random() * 3;
    s.particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 40 + Math.random() * 20,
      maxLife: 60,
      color,
      radius: 2 + Math.random() * 3,
    });
  }
}

export function tickSpawn(
  s: InternalGameState,
  W: number,
  H: number,
) {
  if (s.mode === 'boss') {
    if (s.frame === 120) {
      // Spawn Boss Omega
      const bossType = ENEMY_TYPES.find(t => t.id === 'boss_omega')!;
      const e = createEnemy(bossType, W, H, { x: W / 2, y: -bossType.radius * 2 });
      e.vx = 0;
      e.vy = bossType.speed;
      s.enemies.push(e);
      s.bossGravityBeamTimer = 180; // first beam after 3 seconds
      s.miniBlackHoleTimer = 360;   // first mini BH after 6 seconds
    }

    // Track boss phase based on HP
    const boss = s.enemies.find(e => e.id === 'boss_omega');
    if (boss) {
      const hpRatio = boss.hp / boss.maxHp;
      s.bossPhase = hpRatio > 0.67 ? 0 : (hpRatio > 0.33 ? 1 : 2);
    }

    // Spawn add-ons: phase 2 spawns ALL enemy types; earlier phases spawn a subset.
    if (s.frame > 300) {
      s.spawnTimer++;
      const currentSpawnDelay = Math.max(30, 150 - Math.floor((s.frame - 300) / 300) * 10);
      if (s.spawnTimer > currentSpawnDelay) {
        s.spawnTimer = 0;
        if (s.enemies.length < 35) {
          let typesId: string[];
          if (s.bossPhase >= 2) {
            // Phase 2: ALL enemy types
            typesId = ['scout', 'tank', 'zigzagger', 'ghost', 'splitter', 'berserker', 'bouncer', 'spiraler', 'juggernaut', 'phantom', 'necromancer'];
          } else {
            typesId = ['scout', 'scout', 'zigzagger', 'ghost', 'splitter'];
          }
          const randomType = ENEMY_TYPES.find(t => t.id === typesId[Math.floor(Math.random() * typesId.length)])!;
          const e = createEnemy(randomType, W, H);

          // Strength multiplier based on time
          const strengthMult = 1 + Math.floor((s.frame - 300) / 600) * 0.2;

          e.maxHp = Math.ceil(e.maxHp * strengthMult);
          e.hp = e.maxHp;
          e.speed *= GAME_CONFIG.enemies.speedMult * (1 + (strengthMult - 1) * 0.5);
          e.vx = (e.vx / Math.abs(e.vx || 1)) * Math.abs(e.speed) || 0;
          e.vy = (e.vy / Math.abs(e.vy || 1)) * Math.abs(e.speed) || 0;
          e.damage = Math.ceil(e.damage * GAME_CONFIG.enemies.damageToPlayerMult * strengthMult);

          s.enemies.push(e);
        }
      }
    }

    // === Boss Ability: Gravity Beams (phase 0+) ===
    // Periodically fires purple animated beams to all enemies, pulling & orbiting them.
    if (boss) {
      s.bossGravityBeamTimer--;
      if (s.bossGravityBeamTimer <= 0) {
        // Fire beams to all non-boss enemies
        for (let i = 0; i < s.enemies.length; i++) {
          const target = s.enemies[i];
          if (!target || target.id === 'boss_omega') continue;
          s.bossGravityBeams.push({
            x1: boss.x, y1: boss.y,
            x2: target.x, y2: target.y,
            life: 30, maxLife: 30,
            targetIdx: i,
          });
        }
        audio.playHit();
        s.bossGravityBeamTimer = 240; // every 4 seconds
      }

      // Update active beams: pull enemies toward boss and add orbital motion
      for (let bi = s.bossGravityBeams.length - 1; bi >= 0; bi--) {
        const beam = s.bossGravityBeams[bi];
        beam.life--;
        // Update beam end position to follow the target
        const target = s.enemies[beam.targetIdx];
        if (target && target.id !== 'boss_omega') {
          beam.x2 = target.x;
          beam.y2 = target.y;

          // Pull enemy toward boss (stronger as beam ages)
          const pullStrength = 0.15 * (1 - beam.life / beam.maxLife);
          const dx = boss.x - target.x;
          const dy = boss.y - target.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d > 80) { // don't pull if already very close
            target.vx += (dx / d) * pullStrength;
            target.vy += (dy / d) * pullStrength;
          } else {
            // When close, add tangential velocity to orbit
            const tx = -dy / d;
            const ty = dx / d;
            target.vx += tx * 0.3;
            target.vy += ty * 0.3;
            // Cap speed
            const speed = Math.sqrt(target.vx * target.vx + target.vy * target.vy);
            if (speed > 4) {
              target.vx = (target.vx / speed) * 4;
              target.vy = (target.vy / speed) * 4;
            }
          }
        }
        if (beam.life <= 0) {
          s.bossGravityBeams.splice(bi, 1);
        }
      }
    }

    // === Boss Ability: Mini Black Holes (phase 1+) ===
    // Spawns stationary black holes at random positions that absorb nearby arrows.
    if (s.bossPhase >= 1) {
      s.miniBlackHoleTimer--;
      if (s.miniBlackHoleTimer <= 0 && s.miniBlackHoles.length < (s.bossPhase >= 2 ? 3 : 2)) {
        // Spawn at random position, not too close to the bow
        const cx = W / 2, cy = H / 2;
        let mx = 0, my = 0;
        for (let attempt = 0; attempt < 8; attempt++) {
          mx = 100 + Math.random() * (W - 200);
          my = 100 + Math.random() * (H - 200);
          if (Math.hypot(mx - cx, my - cy) > 180) break;
        }
        s.miniBlackHoles.push({
          x: mx, y: my,
          radius: 16 + Math.random() * 6,
          absorbRadius: 70,
          life: 480, // 8 seconds
          maxLife: 480,
          angle: 0,
        });
        s.miniBlackHoleTimer = s.bossPhase >= 2 ? 300 : 420; // 5s (phase 2) or 7s (phase 1)
      }

      // Update mini black holes
      for (let mi = s.miniBlackHoles.length - 1; mi >= 0; mi--) {
        const mbh = s.miniBlackHoles[mi];
        mbh.life--;
        mbh.angle += 0.03;
        // Fade out in the last second
        if (mbh.life <= 0) {
          s.miniBlackHoles.splice(mi, 1);
        }
      }
    }

    s.waveTimer++; // for boss phases
    return;
  }

  s.spawnTimer++;
  s.waveTimer++;
  if (s.waveTimer > GAME_CONFIG.waves.waveDurationFrames) {
    s.wave++;
    s.waveTimer = 0;
  }
  const currentSpawnRate = Math.max(GAME_CONFIG.waves.minSpawnRate, GAME_CONFIG.waves.baseSpawnRate - s.wave * GAME_CONFIG.waves.spawnRateDecreasePerWave);
  if (s.spawnTimer >= currentSpawnRate) {
    s.spawnTimer = 0;

    // Stronger enemies appear earlier: all 11 non-boss types are available by wave 4.
    // Wave 1: scout, tank, zigzagger (3 types)
    // Wave 2: + ghost, splitter, berserker (6 types)
    // Wave 3: + bouncer, spiraler (8 types)
    // Wave 4+: + juggernaut, phantom, necromancer (all 11)
    const allTypes = ENEMY_TYPES.filter(t => t.id !== 'boss_omega');
    let availableTypes: typeof allTypes;
    if (s.wave >= 4) {
      availableTypes = allTypes;
    } else if (s.wave === 3) {
      availableTypes = allTypes.slice(0, 8);
    } else if (s.wave === 2) {
      availableTypes = allTypes.slice(0, 6);
    } else {
      availableTypes = allTypes.slice(0, 3);
    }

    // Dynamic weights: stronger enemies get more common on higher waves.
    // Base weights stay (scout common early), but scale up for tougher types.
    const pool: (typeof allTypes[0])[] = [];
    availableTypes.forEach(t => {
      let weight = 1;
      if (t.id === 'scout') weight = Math.max(2, 6 - s.wave); // less common later
      if (t.id === 'tank') weight = 1 + Math.floor(s.wave / 3);
      if (t.id === 'zigzagger') weight = 4;
      if (t.id === 'ghost') weight = 2 + Math.floor(s.wave / 3);
      if (t.id === 'splitter') weight = 2 + Math.floor(s.wave / 4);
      if (t.id === 'berserker') weight = 1 + Math.floor(s.wave / 2);
      if (t.id === 'bouncer') weight = 2 + Math.floor(s.wave / 3);
      if (t.id === 'spiraler') weight = 1 + Math.floor(s.wave / 2);
      if (t.id === 'juggernaut') weight = Math.max(1, Math.floor(s.wave / 3));
      if (t.id === 'phantom') weight = Math.max(1, Math.floor(s.wave / 2));
      if (t.id === 'necromancer') weight = Math.max(1, Math.floor(s.wave / 4));

      for (let i = 0; i < weight; i++) {
        pool.push(t);
      }
    });

    // Fewer enemies per spawn: max 2, grows slower than before.
    const enemiesToSpawn = Math.min(2, 1 + Math.floor(s.wave / 4));
    for (let i = 0; i < enemiesToSpawn; i++) {
      const type = pool[Math.floor(Math.random() * pool.length)];
      const e = createEnemy(type, W, H);
      
      // Apply base config multipliers
      e.maxHp = Math.ceil(e.maxHp);
      e.hp = e.maxHp;
      
      e.speed *= GAME_CONFIG.enemies.speedMult;
      e.vx *= GAME_CONFIG.enemies.speedMult;
      e.vy *= GAME_CONFIG.enemies.speedMult;
      
      e.damage = Math.ceil(e.damage * GAME_CONFIG.enemies.damageToPlayerMult);
      
      s.enemies.push(e);
    }
  }
}

export function tickReload(
  s: InternalGameState,
  cx: number,
  cy: number,
  emitState: () => void,
) {
  if (!s.reloading) return;
  s.reloadTimer--;
  s.reloadProgress = 1 - s.reloadTimer / s.reloadFrames;
  if (s.reloadTimer <= 0) {
    s.reloading = false;
    s.arrows = s.maxArrows;
    s.reloadProgress = 0;
    spawnParticles(s, cx, cy, '#00ffff', 6);
  }
  emitState();
}

export function tickPlayer(s: InternalGameState, emitState: () => void) {
  // Invulnerability timer
  if (s.invulnTimer > 0) s.invulnTimer--;

  // HP regeneration
  if (s.hpRegenTimer > 0) {
    s.hpRegenTimer--;
  } else if (s.hp < s.maxHp) {
    s.hp = Math.min(s.maxHp, s.hp + s.hpRegenRate);
    emitState();
  }
}

export function tickEnemies(
  s: InternalGameState,
  W: number,
  H: number,
  cx: number,
  cy: number,
  emitState: () => void,
  onGameOver: (score: number) => void,
) {
  const deadEnemies: number[] = [];
  // Cache boss lookup ONCE (was O(n) per orbiting enemy → O(n²) total).
  const boss = s.enemies.find(b => b.id === 'boss_omega') || null;

  s.enemies.forEach((e, i) => {
    if (e.flashTimer > 0) e.flashTimer--;

    let skipPattern = false;

    if (e.orbitPhase === 'orbiting' || e.orbitPhase === 'pull') {
      if (!boss) {
        // If boss died while orbiting or pulling, release immediately
        e.orbitPhase = 'released';
        e.pattern = 'chase'; // Ensure they resume chasing
      } else {
        skipPattern = true; // wait for boss to manipulate them or orbit
        
        if (e.orbitPhase === 'orbiting') {
          e.orbitTimer = (e.orbitTimer || 0) + 1;
          e.orbitAngle = (e.orbitAngle || 0) + 0.05;
          e.x = boss.x + Math.cos(e.orbitAngle) * (e.orbitRadius || 100);
          e.y = boss.y + Math.sin(e.orbitAngle) * (e.orbitRadius || 100);
          
          if (e.orbitTimer > 300) {
            e.orbitPhase = 'released';
            e.bossBuffed = true;
            // Buff the enemy
            e.maxHp *= 2;
            e.hp = e.maxHp;
            e.speed *= 1.8;
            e.damage = Math.floor(e.damage * 1.5);
            e.color = boss.glowColor;
            e.glowColor = '#ff0000';
            e.radius *= 1.2;
            
            spawnParticles(s, e.x, e.y, e.glowColor, 20);
            
            // Re-target towards player directly as straight projectile
            e.pattern = 'straight';
            const dx = cx - e.x;
            const dy = cy - e.y;
            const d = Math.sqrt(dx * dx + dy * dy);
            e.vx = (dx / d) * e.speed;
            e.vy = (dy / d) * e.speed;
            skipPattern = false; // release this frame
          }
        }
      }
    }

    if (!skipPattern) {
      switch (e.pattern) {
      case 'straight':
      case 'split':
        e.x += e.vx;
        e.y += e.vy;
        break;
      case 'zigzag': {
        e.zigzagTimer++;
        e.x += e.vx;
        e.y += e.vy;
        if (e.zigzagTimer % 40 === 0) {
          // Вычисляем направление к игроку
          const tdx = cx - e.x; const tdy = cy - e.y;
          const td = Math.sqrt(tdx * tdx + tdy * tdy);
          const toPlayerX = tdx / td; const toPlayerY = tdy / td;
          // Перпендикуляр к направлению на игрока
          const perp = { x: -toPlayerY, y: toPlayerX };
          const flip = Math.random() > 0.5 ? 1 : -1;
          // Смешиваем: 70% к игроку + 50% зигзаг
          const nx = toPlayerX + perp.x * flip * 0.5;
          const ny = toPlayerY + perp.y * flip * 0.5;
          const nd = Math.sqrt(nx * nx + ny * ny);
          e.vx = (nx / nd) * e.speed;
          e.vy = (ny / nd) * e.speed;
        }
        break;
      }
      case 'chase': {
        const dx = cx - e.x;
        const dy = cy - e.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        e.vx = (dx / d) * e.speed;
        e.vy = (dy / d) * e.speed;
        e.x += e.vx;
        e.y += e.vy;
        break;
      }
      case 'teleport': {
        // Плавное появление fade-in
        if ((e.teleportAlpha ?? 1) < 1) {
          e.teleportAlpha = Math.min(1, (e.teleportAlpha ?? 0) + 0.06);
        }
        // Анимация кольца при появлении
        if ((e.teleportRingAnim ?? 0) > 0) {
          e.teleportRingAnim = (e.teleportRingAnim ?? 0) - 1;
        }

        if (!e.teleportFading) {
          e.x += e.vx;
          e.y += e.vy;
        }
        e.teleportTimer--;

        if (e.teleportTimer <= 0 && !e.teleportFading) {
          if ((e.teleportsLeft ?? 0) > 0) {
            // Есть ещё телепортации — уходим в fade-out
            e.teleportFading = true;
            e.teleportTimer = 18;
          }
          // Если телепортаций не осталось — просто летим прямо (chase), таймер не сбрасываем
        }

        if (e.teleportFading) {
          e.teleportAlpha = Math.max(0, (e.teleportAlpha ?? 1) - 0.09);
          if ((e.teleportAlpha ?? 0) <= 0) {
            // Появляемся в случайной точке ВНУТРИ экрана (не за краем),
            // но НЕ слишком близко к Луку (центру), чтобы дать игроку время отреагировать.
            const margin3 = 80;
            const safeRadius = 220; // min distance from the bow after teleport
            let nx = 0, ny = 0;
            for (let attempt = 0; attempt < 8; attempt++) {
              nx = margin3 + Math.random() * (W - margin3 * 2);
              ny = margin3 + Math.random() * (H - margin3 * 2);
              const distToBow = Math.hypot(nx - cx, ny - cy);
              if (distToBow >= safeRadius) break;
            }
            // If still too close after attempts, push outward along the vector from the bow
            const distFinal = Math.hypot(nx - cx, ny - cy);
            if (distFinal < safeRadius && distFinal > 0) {
              const push = (safeRadius - distFinal) + 20;
              const dirx = (nx - cx) / distFinal;
              const diry = (ny - cy) / distFinal;
              nx += dirx * push;
              ny += diry * push;
              // Clamp back inside the screen margins
              nx = Math.max(margin3, Math.min(W - margin3, nx));
              ny = Math.max(margin3, Math.min(H - margin3, ny));
            } else if (distFinal === 0) {
              // Edge case: exactly on center — nudge to the right
              nx = Math.min(W - margin3, cx + safeRadius + 20);
            }
            e.x = nx;
            e.y = ny;
            const tdx = cx - e.x; const tdy = cy - e.y;
            const td = Math.sqrt(tdx * tdx + tdy * tdy);
            e.vx = (tdx / td) * e.speed; e.vy = (tdy / td) * e.speed;
            // Эффект появления: частицы + кольцо
            spawnParticles(s, e.x, e.y, e.color, 12);
            e.teleportRingAnim = 30;
            e.teleportFading = false;
            e.teleportAlpha = 0;
            e.teleportsLeft = (e.teleportsLeft ?? 1) - 1;
            e.teleportTimer = 90 + Math.random() * 90;

            // Если телепортаций больше нет — переключаемся на chase
            if ((e.teleportsLeft ?? 0) <= 0) {
              (e as Enemy).pattern = 'chase';
              e.teleportAlpha = 1;
            }
          }
        }
        break;
      }
      case 'bounce':
        if (!e.bouncerEntered) {
          e.x += e.vx;
          e.y += e.vy;
          if (e.x > e.radius && e.x < W - e.radius && e.y > e.radius && e.y < H - e.radius) {
            e.bouncerEntered = true;
          }
        } else {
          e.x += e.vx;
          e.y += e.vy;
          if (e.x - e.radius < 0) { e.x = e.radius; e.vx = Math.abs(e.vx); spawnParticles(s, e.x, e.y, e.color, 4); }
          if (e.x + e.radius > W) { e.x = W - e.radius; e.vx = -Math.abs(e.vx); spawnParticles(s, e.x, e.y, e.color, 4); }
          if (e.y - e.radius < 0) { e.y = e.radius; e.vy = Math.abs(e.vy); spawnParticles(s, e.x, e.y, e.color, 4); }
          if (e.y + e.radius > H) { e.y = H - e.radius; e.vy = -Math.abs(e.vy); spawnParticles(s, e.x, e.y, e.color, 4); }
        }
        break;
      case 'spiral': {
        const dx = cx - e.x;
        const dy = cy - e.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        
        // Tangent vector for orbiting
        const tx = -dy / d;
        const ty = dx / d;
        
        // Combine forward movement (0.3) and orbital movement (1.2)
        e.vx = (dx / d) * e.speed * 0.3 + tx * e.speed * 1.2;
        e.vy = (dy / d) * e.speed * 0.3 + ty * e.speed * 1.2;
        
        e.x += e.vx;
        e.y += e.vy;
        e.angle += 0.15; // Fast visual spin
        break;
      }
      case 'stealth': {
        const dx = cx - e.x;
        const dy = cy - e.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        e.vx = (dx / d) * e.speed;
        e.vy = (dy / d) * e.speed;
        e.x += e.vx;
        e.y += e.vy;
        
        // Become visible if close to player or recently hit
        if (d < 220 || e.flashTimer > 0) {
          e.teleportAlpha = Math.min(1, (e.teleportAlpha ?? 0) + 0.08);
        } else {
          e.teleportAlpha = Math.max(0.15, (e.teleportAlpha ?? 1) - 0.03);
        }
        break;
      }
      case 'summoner': {
        const dx = cx - e.x;
        const dy = cy - e.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        
        // Keep distance from player (around 250-300px)
        const targetDist = 280;
        let speedMult = 1;
        if (d < targetDist - 20) {
          speedMult = -1; // Move away
        } else if (d > targetDist + 20) {
          speedMult = 1; // Move closer
        } else {
          speedMult = 0.1; // Orbit slowly
        }
        
        const tx = -dy / d;
        const ty = dx / d;
        
        e.vx = (dx / d) * e.speed * speedMult + tx * e.speed * 0.5;
        e.vy = (dy / d) * e.speed * speedMult + ty * e.speed * 0.5;
        
        e.x += e.vx;
        e.y += e.vy;
        
        // Summon logic
        e.summonTimer = (e.summonTimer ?? 0) + 1;
        if (e.summonTimer >= 180) { // Summon every 3 seconds
          e.summonTimer = 0;
          const scoutType = ENEMY_TYPES.find(t => t.id === 'scout')!;
          const scout = createEnemy(scoutType, W, H, {
            x: e.x + (Math.random() - 0.5) * 40,
            y: e.y + (Math.random() - 0.5) * 40,
          });
          
          // Apply base config multipliers
          scout.maxHp = Math.ceil(scout.maxHp);
          scout.hp = scout.maxHp;
          
          scout.speed *= GAME_CONFIG.enemies.speedMult;
          scout.vx *= GAME_CONFIG.enemies.speedMult;
          scout.vy *= GAME_CONFIG.enemies.speedMult;
          
          scout.damage = Math.ceil(scout.damage * GAME_CONFIG.enemies.damageToPlayerMult);
          
          s.enemies.push(scout);
          spawnParticles(s, e.x, e.y, e.color, 15);
        }
        break;
      }
      case 'boss_omega': {
        e.summonTimer = (e.summonTimer ?? 0) + 1;
        const phase = Math.min(2, Math.floor((e.maxHp - e.hp) / (e.maxHp / 3))); // 0, 1, 2
        const dx = cx - e.x;
        const dy = cy - e.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        
        // Base distance that fluctuates unpredictably using sine waves
        const baseTargetDist = 380 + Math.sin(e.summonTimer * 0.015) * 120 + Math.cos(e.summonTimer * 0.027) * 80;
        // Ensure it doesn't get too close to the player (minimum 250px away)
        const targetDist = Math.max(250, baseTargetDist - phase * 30);
        
        let radialSpeedMult = 1;
        if (d < targetDist - 10) radialSpeedMult = -1.5; // push away strongly if too close
        else if (d > targetDist + 10) radialSpeedMult = 1.0;
        else radialSpeedMult = 0.1;
        
        // Tangential (orbital) direction
        // Occasionally switch orbit direction or speed up wildly based on phase
        const orbitDir = Math.sign(Math.sin(e.summonTimer * 0.005)) || 1;
        const orbitVary = Math.sin(e.summonTimer * 0.03) * 0.8;
        const orbitSpeedMult = (1.5 + orbitVary + phase * 0.5) * orbitDir;
        
        const tx = -dy / d;
        const ty = dx / d;
        
        e.vx = (dx / d) * e.speed * radialSpeedMult + tx * e.speed * orbitSpeedMult;
        e.vy = (dy / d) * e.speed * radialSpeedMult + ty * e.speed * orbitSpeedMult;
        
        e.x += e.vx;
        e.y += e.vy;
        
        // Constrain boss to screen boundaries
        e.x = Math.max(e.radius, Math.min(W - e.radius, e.x));
        e.y = Math.max(e.radius, Math.min(H - e.radius, e.y));
        
        // Attract and pull enemies into orbit instead of spawning
        for (let j = 0; j < s.enemies.length; j++) {
          const other = s.enemies[j];
          if (!other || other.id === 'boss_omega' || other.bossBuffed || other.orbitPhase === 'orbiting' || other.orbitPhase === 'released') continue;
          
          const ox = e.x - other.x;
          const oy = e.y - other.y;
          const od = Math.sqrt(ox * ox + oy * oy);
          
          // Pull aura
          if (od < e.radius * 4) {
            // Strong pull
            if (other.orbitPhase !== 'pull') {
               spawnParticles(s, other.x, other.y, e.glowColor, 3);
            }
            other.orbitPhase = 'pull';
            other.x += (ox / od) * other.speed * 2.5; 
            other.y += (oy / od) * other.speed * 2.5;
            
            // If very close, catch them into orbit
            if (od < e.radius * 1.5) {
              other.orbitPhase = 'orbiting';
              other.orbitTimer = 0;
              other.orbitRadius = e.radius * 1.5 + Math.random() * 40;
              other.orbitAngle = Math.atan2(-oy, -ox); // angle relative to boss
              spawnParticles(s, other.x, other.y, e.glowColor, 8);
            }
          }
        }
        
        e.angle += 0.05 + phase * 0.02; // Visual spin
        break;
      }
    }
    }

    // Update trail
    if (!e.trail) e.trail = [];
    e.trail.push({ x: e.x, y: e.y });
    // Keep trail length depending on speed
    if (e.trail.length > 8) {
      e.trail.shift();
    }

    // Pulse effect
    if (e.pulseGrowing) {
      e.pulseRadius += 0.15;
      if (e.pulseRadius > e.radius + 4) e.pulseGrowing = false;
    } else {
      e.pulseRadius -= 0.15;
      if (e.pulseRadius < e.radius) e.pulseGrowing = true;
    }

    // HP bar rotation
    e.angle += 0.01;

    // Check collision with bow
    const dx = e.x - cx;
    const dy = e.y - cy;
    const distSq = dx * dx + dy * dy;
    const radSum = e.radius + 20;
    if (distSq < radSum * radSum) {
      if (s.invulnTimer <= 0) {
        const totalDamage = Math.max(1, Math.round(e.damage * s.defenseMult));

        s.hp = Math.max(0, s.hp - totalDamage);
        spawnParticles(s, cx, cy, '#ff0000', 8);
        audio.playPlayerHit();

        s.hpRegenTimer = GAME_CONFIG.player.hpRegenDelayFrames; // delay
        s.invulnTimer = GAME_CONFIG.player.invulnFramesAfterHit; // invulnerability
        s.bowPulse = 20;

        // Shockwave upgrade: emit a wave that pushes enemies away from the bow
        if (s.shockwave > 0) {
          const cfg = GAME_CONFIG.shockwave;
          s.activeShockwaves.push({
            x: cx, y: cy,
            radius: 25,
            maxRadius: cfg.waveMaxRadius,
            life: cfg.waveLife,
            maxLife: cfg.waveLife,
          });
          // Push all alive enemies away from the bow.
          // Use a Set for O(1) dead-enemy lookups (only built when shockwave fires).
          const deadSet = new Set(deadEnemies);
          s.enemies.forEach((other, oi) => {
            if (oi === i) return; // skip the one that hit
            if (deadSet.has(oi)) return;
            const odx = other.x - cx;
            const ody = other.y - cy;
            const od = Math.sqrt(odx * odx + ody * ody);
            if (od > 0 && od < cfg.radius) {
              const force = (1 - od / cfg.radius) * cfg.pushForce;
              other.x += (odx / od) * force;
              other.y += (ody / od) * force;
              spawnParticles(s, other.x, other.y, other.color, 3);
            }
          });
          audio.playExplosion();
        }

        emitState();
        if (s.hp <= 0) {
          s.alive = false;
          audio.playGameOver();
          onGameOver(s.score);
        }
      }
      deadEnemies.push(i);
    }

    // Out of bounds
    if (e.pattern !== 'bounce') {
      const margin = 200;
      if (e.x < -margin || e.x > W + margin || e.y < -margin || e.y > H + margin) {
        deadEnemies.push(i);
      }
    }
  });

  return deadEnemies;
}

export function tickProjectiles(
  s: InternalGameState,
  W: number,
  H: number,
  deadEnemies: number[],
  emitState: () => void,
  onBossDefeated: () => void = () => {},
) {
  for (let pi = s.projectiles.length - 1; pi >= 0; pi--) {
    const p = s.projectiles[pi];
    let hitSomething = false;

    for (let ei = 0; ei < s.enemies.length; ei++) {
      if (p.hitEnemies.includes(ei)) continue; // prevent multihits
      if (deadEnemies.includes(ei)) continue;

      const e = s.enemies[ei];
      const dx = p.x - e.x;
      const dy = p.y - e.y;
      const distSq = dx * dx + dy * dy;
      const radSum = p.radius + e.radius;

      if (distSq < radSum * radSum) {
        e.hp -= p.damage;
        e.flashTimer = 8;
        spawnParticles(s, e.x, e.y, p.isCrit ? '#ffaa00' : (e.id === 'boss_omega' ? e.glowColor : e.color), p.isCrit ? 10 : 5);
        audio.playHit();

        p.hitEnemies.push(ei);
        hitSomething = true;

        if (e.hp <= 0) {
          s.score += e.points * s.wave;
          s.enemiesKilled++;
          // Double Cores upgrade: chance to trigger x2 cores per non-boss enemy kill
          if (s.doubleCores > 0 && e.id !== 'boss_omega') {
            const chance = s.doubleCores * GAME_CONFIG.doubleCores.chancePerLevel;
            if (Math.random() < chance) {
              s.doubleCoresTriggered++;
              spawnParticles(s, e.x, e.y, '#00ffff', 12);
            }
          }
          spawnParticles(s, e.x, e.y, e.id === 'boss_omega' ? e.glowColor : e.color, 15);
          audio.playExplosion();

          if (e.id === 'splitter' && !e.splitDone) {
            e.splitDone = true;
            const scout = ENEMY_TYPES.find(t => t.id === 'scout')!;
            for (let k = 0; k < 2; k++) {
              const sp = createEnemy(scout, W, H, {
                x: e.x + (Math.random() - 0.5) * 40,
                y: e.y + (Math.random() - 0.5) * 40,
              });
              
              sp.maxHp = Math.ceil(sp.maxHp);
              sp.hp = sp.maxHp;
              sp.speed *= GAME_CONFIG.enemies.speedMult;
              sp.vx *= GAME_CONFIG.enemies.speedMult;
              sp.vy *= GAME_CONFIG.enemies.speedMult;
              sp.damage = Math.ceil(sp.damage * GAME_CONFIG.enemies.damageToPlayerMult);
              
              s.enemies.push(sp);
            }
          }

          if (!deadEnemies.includes(ei)) deadEnemies.push(ei);
          emitState();

          // End game if Boss Omega dies
          if (e.id === 'boss_omega') {
            s.alive = false;
            onBossDefeated();
          }
        }

        // Arrows never pierce through the boss — they are destroyed on impact.
        // For all other enemies, piercing works normally.
        if (e.id === 'boss_omega') {
          s.projectiles.splice(pi, 1);
          break;
        }

        if (p.pierceLeft > 0) {
          p.pierceLeft--;
        } else {
          s.projectiles.splice(pi, 1);
          break; // Stop checking this projectile
        }
      }
    }
  }
}

export function tickCleanup(s: InternalGameState, W: number, H: number, deadEnemies: number[]) {
  const uniqueDead = [...new Set(deadEnemies)].sort((a, b) => b - a);
  uniqueDead.forEach(i => s.enemies.splice(i, 1));

  s.projectiles = s.projectiles.filter(p => {
    if (!p.trail) p.trail = [];
    p.trail.push({ x: p.x, y: p.y });
    if (p.trail.length > 10) p.trail.shift();

    // Magnet arrow: gently steer toward the nearest alive enemy within range.
    // Skip enemies already hit (hitEnemies) so the arrow keeps flying toward
    // a NEW target after piercing, instead of getting stuck on the one it hit.
    if (p.isMagnet) {
      let nearest: Enemy | null = null;
      let nearestDist = GAME_CONFIG.magnet.range;
      for (let i = 0; i < s.enemies.length; i++) {
        if (uniqueDead.includes(i)) continue;
        if (p.hitEnemies.includes(i)) continue; // skip already-hit enemies
        const e = s.enemies[i];
        const ddx = e.x - p.x;
        const ddy = e.y - p.y;
        const d = Math.sqrt(ddx * ddx + ddy * ddy);
        if (d < nearestDist) {
          nearestDist = d;
          nearest = e;
        }
      }
      if (nearest) {
        const tdx = nearest.x - p.x;
        const tdy = nearest.y - p.y;
        const td = Math.sqrt(tdx * tdx + tdy * tdy);
        if (td > 0) {
          const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
          const targetVx = (tdx / td) * speed;
          const targetVy = (tdy / td) * speed;
          const steer = GAME_CONFIG.magnet.steerStrength;
          p.vx = p.vx * (1 - steer) + targetVx * steer;
          p.vy = p.vy * (1 - steer) + targetVy * steer;
        }
      }
    }

    // Mini black holes absorb nearby arrows
    for (let mi = 0; mi < s.miniBlackHoles.length; mi++) {
      const mbh = s.miniBlackHoles[mi];
      const dx = mbh.x - p.x;
      const dy = mbh.y - p.y;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d < mbh.radius) {
        // Arrow is inside the black hole — destroy it
        spawnParticles(s, p.x, p.y, '#bf00ff', 6);
        return false;
      }
      if (d < mbh.absorbRadius) {
        // Pull arrow toward the black hole
        const pull = 0.5 * (1 - d / mbh.absorbRadius);
        p.vx += (dx / d) * pull;
        p.vy += (dy / d) * pull;
      }
    }

    p.x += p.vx;
    p.y += p.vy;
    return p.x > -50 && p.x < W + 50 && p.y > -50 && p.y < H + 50;
  });

  s.particles = s.particles.filter(p => {
    p.x += p.vx;
    p.y += p.vy;
    p.vx *= 0.95;
    p.vy *= 0.95;
    p.life--;
    return p.life > 0;
  });

  // Update active shockwaves (expand ring, decrease life)
  s.activeShockwaves = s.activeShockwaves.filter(sw => {
    sw.life--;
    const t = 1 - sw.life / sw.maxLife;
    sw.radius = 25 + (sw.maxRadius - 25) * t;
    return sw.life > 0;
  });
}

// ===== Boss-mode ambient dust particles =====
// Dust drifts slowly across the screen. When the boss is present, each dust particle
// is gravitationally pulled toward it — the closer it gets, the stronger the pull.
// Near the boss, particles spiral around it (orbit) before being absorbed completely.

const DUST_COUNT = 90;            // target dust population
const DUST_ABSORB_RADIUS = 40;    // absorbed when within this of boss center
const DUST_SPIRAL_RADIUS = 140;   // start spiraling when within this
const DUST_GRAVITY_RANGE = 600;   // only attracted if within this distance
const DUST_DRIFT_SPEED = 0.25;    // baseline drift speed

export function initDustParticles(s: InternalGameState, W: number, H: number) {
  s.dustParticles = [];
  for (let i = 0; i < DUST_COUNT; i++) {
    s.dustParticles.push(createDust(W, H));
  }
}

function createDust(W: number, H: number): DustParticle {
  const baseAlpha = 0.15 + Math.random() * 0.25; // very faint
  return {
    x: Math.random() * W,
    y: Math.random() * H,
    vx: (Math.random() - 0.5) * DUST_DRIFT_SPEED,
    vy: (Math.random() - 0.5) * DUST_DRIFT_SPEED,
    radius: 0.6 + Math.random() * 1.4,
    baseAlpha,
    alpha: baseAlpha,
    orbitAngle: Math.random() * Math.PI * 2,
    absorbed: false,
    absorbProgress: 0,
  };
}

export function tickDustParticles(s: InternalGameState, W: number, H: number) {
  // Find the boss (only one exists in boss mode)
  const boss = s.enemies.find(e => e.id === 'boss_omega');
  const bx = boss ? boss.x : -9999;
  const by = boss ? boss.y : -9999;
  const bossR = boss ? boss.radius : 0;

  for (let i = 0; i < s.dustParticles.length; i++) {
    const d = s.dustParticles[i];

    if (d.absorbed) {
      // Continue the absorb animation: spiral tighter & fade, then respawn elsewhere
      d.absorbProgress += 0.06;
      d.alpha = d.baseAlpha * (1 - d.absorbProgress);
      if (d.absorbProgress >= 1) {
        // Respawn at a random screen edge far from the boss
        s.dustParticles[i] = createDust(W, H);
        const nd = s.dustParticles[i];
        // spawn near an edge
        const edge = Math.floor(Math.random() * 4);
        if (edge === 0) { nd.x = Math.random() * W; nd.y = -10; }
        else if (edge === 1) { nd.x = W + 10; nd.y = Math.random() * H; }
        else if (edge === 2) { nd.x = Math.random() * W; nd.y = H + 10; }
        else { nd.x = -10; nd.y = Math.random() * H; }
      }
      continue;
    }

    if (boss) {
      const dx = bx - d.x;
      const dy = by - d.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < DUST_ABSORB_RADIUS + bossR * 0.5) {
        // Close enough → start absorption
        d.absorbed = true;
        d.absorbProgress = 0;
        d.orbitAngle = Math.atan2(dy, dx);
        continue;
      }

      if (dist < DUST_GRAVITY_RANGE) {
        // Gravitational pull — strength increases as distance decreases (1/dist falloff).
        // Normalized so pull is gentle far away and strong up close.
        const proximity = 1 - dist / DUST_GRAVITY_RANGE; // 0 (far) → 1 (close)
        const pullStrength = 0.04 + proximity * proximity * 1.4; // quadratic ramp

        // Direction toward boss
        const ndx = dx / dist;
        const ndy = dy / dist;

        // Within spiral radius, add tangential velocity for orbiting swirl
        if (dist < DUST_SPIRAL_RADIUS) {
          d.orbitAngle += 0.12 * (1 - dist / DUST_SPIRAL_RADIUS); // spin faster when closer
          const swirlStrength = (1 - dist / DUST_SPIRAL_RADIUS) * 1.2;
          // tangential vector (perpendicular to radial, counterclockwise)
          const tx = -ndy;
          const ty = ndx;
          d.vx += ndx * pullStrength + tx * swirlStrength;
          d.vy += ndy * pullStrength + ty * swirlStrength;
          // brighten slightly as it swirls
          d.alpha = Math.min(0.7, d.baseAlpha + proximity * 0.4);
        } else {
          // Pure attraction outside spiral radius
          d.vx += ndx * pullStrength;
          d.vy += ndy * pullStrength;
          d.alpha = d.baseAlpha + proximity * 0.15;
        }

        // Damp excess velocity to keep movement smooth (cap speed)
        const speed = Math.sqrt(d.vx * d.vx + d.vy * d.vy);
        const maxSpeed = 4 + proximity * 6;
        if (speed > maxSpeed) {
          d.vx = (d.vx / speed) * maxSpeed;
          d.vy = (d.vy / speed) * maxSpeed;
        }
      } else {
        // Far from boss: gentle ambient drift, no attraction
        d.vx += (Math.random() - 0.5) * 0.01;
        d.vy += (Math.random() - 0.5) * 0.01;
        d.alpha = d.baseAlpha;
      }
    } else {
      // No boss present: gentle ambient drift
      d.vx += (Math.random() - 0.5) * 0.01;
      d.vy += (Math.random() - 0.5) * 0.01;
      d.alpha = d.baseAlpha;
    }

    // Apply velocity
    d.x += d.vx;
    d.y += d.vy;

    // Mild damping for smooth motion
    d.vx *= 0.97;
    d.vy *= 0.97;

    // Wrap around screen edges (only when not being attracted — keeps dust on-screen)
    if (!boss || Math.hypot(bx - d.x, by - d.y) > DUST_GRAVITY_RANGE) {
      if (d.x < -20) d.x = W + 20;
      if (d.x > W + 20) d.x = -20;
      if (d.y < -20) d.y = H + 20;
      if (d.y > H + 20) d.y = -20;
    }
  }

  // Keep population topped up
  while (s.dustParticles.length < DUST_COUNT) {
    s.dustParticles.push(createDust(W, H));
  }
}

export function shootProjectile(
  s: InternalGameState,
  cx: number,
  cy: number,
  mouseX: number,
  mouseY: number,
  emitState: () => void,
) {
  if (!s.alive || s.reloading || s.arrows <= 0 || s.shootCooldown > 0) return;
  const dx = mouseX - cx;
  const dy = mouseY - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist === 0) return;
  const speed = GAME_CONFIG.player.projectileSpeed * s.projSpeedMult;
  const isCrit = Math.random() < s.critChance;
  const damage = s.damageMult * (isCrit ? s.critDamage : 1);
  // The last arrow in the quiver becomes a magnet arrow if the upgrade is purchased
  const isMagnet = s.magnetArrow > 0 && s.arrows === 1;
  s.projectiles.push({
    x: cx, y: cy,
    vx: (dx / dist) * speed,
    vy: (dy / dist) * speed,
    radius: GAME_CONFIG.player.projectileRadius,
    trail: [],
    pierceLeft: s.piercingVal,
    hitEnemies: [],
    damage,
    isCrit,
    isMagnet,
  });
  audio.playShoot();
  s.arrows--;
  s.shootCooldown = GAME_CONFIG.player.shootCooldownFrames;
  s.bowPulse = 15;
  if (s.arrows <= 0) {
    s.reloading = true;
    s.reloadTimer = s.reloadFrames;
    s.reloadProgress = 0;
  }
  emitState();
}