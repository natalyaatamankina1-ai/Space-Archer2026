'use client';

/**
 * @fileoverview GameCanvas — React-компонент игрового холста.
 *
 * Создаёт <canvas> элемент и инициализирует всё игровое состояние:
 * - Читает улучшения из props и вычисляет производные статы (HP, урон, скорость, и т.д.)
 * - Создаёт InternalGameState (ref, не state — чтобы не триггерить ре-рендеры)
 * - Передаёт всё в useGameLoop, который запускает игровой цикл
 *
 * Важно: gameStateRef хранится в useRef, а не useState, потому что
 * игровое состояние обновляется 60 раз в секунду и не должно
 * вызывать React-ре-рендеры (это убило бы производительность).
 *
 * @see useGameLoop.ts — игровой цикл
 * @see gameLogic.ts → InternalGameState — структура состояния
 */

import { useRef } from 'react';
import { InternalGameState } from './gameLogic';
import { useGameLoop } from './useGameLoop';
import { GameProgress } from '@/types/game';
import { GAME_CONFIG } from './config';

interface GameState {
  hp: number;
  maxHp: number;
  score: number;
  wave: number;
  arrows: number;
  maxArrows: number;
  reloading: boolean;
  reloadProgress: number;
  paused: boolean;
}

interface GameCanvasProps {
  mode: 'classic' | 'boss';
  upgrades: GameProgress['upgrades'];
  onGameOver: (score: number, enemiesKilled: number, wave: number, doubleCoresTriggered: number) => void;
  onStateChange: (state: GameState) => void;
}

export default function GameCanvas({ mode, upgrades, onGameOver, onStateChange }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const mousePos = useRef({ x: 0, y: 0 });
  
  const maxHp = GAME_CONFIG.player.baseMaxHp + (upgrades.maxHp || 0) * GAME_CONFIG.upgrades.maxHpBonusPerLevel;
  const maxArrows = GAME_CONFIG.player.baseMaxArrows + (upgrades.maxArrows || 0) * GAME_CONFIG.upgrades.maxArrowsBonusPerLevel;
  const reloadFrames = Math.floor(GAME_CONFIG.player.baseReloadFrames * Math.max(0.1, 1 - (upgrades.reloadSpeed || 0) * GAME_CONFIG.upgrades.reloadSpeedReductionPerLevel));
  const damageMult = GAME_CONFIG.player.baseDamageMult * (1 + (upgrades.damage || 0) * GAME_CONFIG.upgrades.damageBonusPerLevel);
  const hpRegenRate = GAME_CONFIG.player.baseHpRegenRate * (1 + (upgrades.regenSpeed || 0) * GAME_CONFIG.upgrades.regenSpeedBonusPerLevel);
  const piercingVal = (upgrades.piercing || 0) * GAME_CONFIG.upgrades.piercingBonusPerLevel;
  const projSpeedMult = 1 + (upgrades.projectileSpeed || 0) * GAME_CONFIG.upgrades.projectileSpeedBonusPerLevel;
  const critChance = 0.05 + (upgrades.critChance || 0) * GAME_CONFIG.upgrades.critChanceBonusPerLevel;
  const critDamage = 2.0 + (upgrades.critDamage || 0) * GAME_CONFIG.upgrades.critDamageBonusPerLevel;
  const defenseMult = 1 - (upgrades.defense || 0) * GAME_CONFIG.upgrades.defenseBonusPerLevel;
  const magnetArrow = upgrades.magnetArrow || 0;
  const shockwave = upgrades.shockwave || 0;
  const doubleCores = upgrades.doubleCores || 0;

  const gameStateRef = useRef<InternalGameState>({
    mode,
    hp: maxHp,
    maxHp,
    hpRegenRate,
    hpRegenTimer: 0,
    invulnTimer: 0,
    score: 0,
    wave: 1,
    arrows: maxArrows,
    maxArrows,
    reloading: false,
    reloadProgress: 0,
    reloadTimer: 0,
    reloadFrames,
    damageMult,
    piercingVal,
    projSpeedMult,
    critChance,
    critDamage,
    defenseMult,
    magnetArrow,
    shockwave,
    doubleCores,
    spawnTimer: 0,
    waveTimer: 0,
    enemies: [],
    projectiles: [],
    particles: [],
    activeShockwaves: [],
    doubleCoresTriggered: 0,
    dustParticles: [],
    bossGravityBeamTimer: 0,
    bossGravityBeams: [],
    miniBlackHoles: [],
    miniBlackHoleTimer: 0,
    bossPhase: 0,
    alive: true,
    bowPulse: 0,
    canShoot: true,
    shootCooldown: 0,
    frame: 0,
    paused: false,
    enemiesKilled: 0,
  });

  useGameLoop({
    canvasRef,
    mousePos,
    animRef,
    gameStateRef,
    onGameOver,
    onStateChange,
  });

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ cursor: 'none' }}
    />
  );
}
