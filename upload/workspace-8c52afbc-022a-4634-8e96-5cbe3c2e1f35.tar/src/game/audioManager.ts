/**
 * @fileoverview AudioManager — система звука SPACE ARCHER.
 *
 * Два подхода к звуку:
 * 1. SFX (звуковые эффекты) — через Web Audio API (AudioContext + OscillatorNode).
 *    Быстро, без загрузки файлов. Методы: playShoot, playHit, playExplosion, и т.д.
 *
 * 2. Музыка — через HTMLAudioElement (<audio>):
 *    - startMenuMusic/stopMenuMusic — музыка главного меню (looped, /menu-music.mp3)
 *    - startBossMusic/stopBossMusic — музыка боя с боссом (looped, /celestial-voyage.mp3)
 *    - startMusic/stopMusic — дрон-музыка обычного режима (через OscillatorNode)
 *
 * Громкость управляется через setVolumes(sfx, music).
 * AudioContext инициализируется при первом вызове init() (требует user gesture).
 *
 * @see Index.tsx — где вызывается startMenuMusic/stopMenuMusic
 * @see GameScreen.tsx — где вызывается startMusic/startBossMusic
 */
class AudioManager {
  ctx: AudioContext | null = null;
  sfxVolume = 0.5;
  musicVolume = 0.3;
  musicOsc: OscillatorNode | null = null;
  musicGain: GainNode | null = null;
  lfo: OscillatorNode | null = null;

  bossAudio: HTMLAudioElement | null = null;
  menuAudio: HTMLAudioElement | null = null;

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setVolumes(sfx: number, music: number) {
    this.sfxVolume = sfx;
    this.musicVolume = music;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(music * 0.15, this.ctx.currentTime, 0.1);
    }
    if (this.bossAudio) {
      this.bossAudio.volume = music;
    }
    if (this.menuAudio) {
      this.menuAudio.volume = music * 0.6;
    }
  }

  playTone(freq: number, type: OscillatorType, duration: number, volMult = 1, slideFreq?: number) {
    if (!this.ctx || this.sfxVolume <= 0) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    const now = this.ctx.currentTime;
    osc.frequency.setValueAtTime(freq, now);
    if (slideFreq) {
      osc.frequency.exponentialRampToValueAtTime(slideFreq, now + duration);
    }

    gain.gain.setValueAtTime(this.sfxVolume * volMult, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + duration);

    osc.start(now);
    osc.stop(now + duration);
  }

  playNoise(duration: number, volMult = 1) {
    if (!this.ctx || this.sfxVolume <= 0) return;
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const gain = this.ctx.createGain();
    
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 1000;

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    const now = this.ctx.currentTime;
    gain.gain.setValueAtTime(this.sfxVolume * volMult, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + duration);

    noise.start(now);
  }

  playShoot() { this.init(); this.playTone(800, 'square', 0.15, 0.15, 200); }
  playHit() { this.init(); this.playTone(300, 'sawtooth', 0.1, 0.2, 100); }
  playExplosion() { this.init(); this.playNoise(0.4, 0.4); }
  playPlayerHit() { this.init(); this.playTone(150, 'sawtooth', 0.4, 0.5, 50); this.playNoise(0.3, 0.5); }
  playClick() {
    this.init();
    this.playTone(1200, 'sine', 0.05, 0.1);
    // If menu music was blocked by autoplay, retry on this user interaction
    if (this.menuAudio && this.menuAudio.paused) {
      this.menuAudio.play().catch(() => {});
    }
  }
  playGameOver() { this.init(); this.playTone(200, 'sawtooth', 1.5, 0.4, 50); }

  startMusic() {
    this.init();
    if (!this.ctx || this.musicOsc) return;
    this.musicOsc = this.ctx.createOscillator();
    this.musicGain = this.ctx.createGain();
    
    this.musicOsc.type = 'sine';
    this.musicOsc.frequency.setValueAtTime(55, this.ctx.currentTime); // Low drone
    
    this.lfo = this.ctx.createOscillator();
    this.lfo.type = 'sine';
    this.lfo.frequency.value = 0.1; // Slow modulation
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 5;
    this.lfo.connect(lfoGain);
    lfoGain.connect(this.musicOsc.frequency);
    this.lfo.start();

    this.musicGain.gain.setValueAtTime(0, this.ctx.currentTime);
    this.musicGain.gain.linearRampToValueAtTime(this.musicVolume * 0.15, this.ctx.currentTime + 2);
    
    this.musicOsc.connect(this.musicGain);
    this.musicGain.connect(this.ctx.destination);
    this.musicOsc.start();
  }

  startBossMusic() {
    if (this.musicVolume <= 0) return;
    if (!this.bossAudio) {
      this.bossAudio = new Audio('/celestial-voyage.mp3');
      this.bossAudio.loop = true;
    }
    this.bossAudio.volume = this.musicVolume;
    this.bossAudio.play().catch(e => console.warn("Audio play failed:", e));
  }

  stopBossMusic() {
    if (this.bossAudio) {
      this.bossAudio.pause();
      this.bossAudio.currentTime = 0;
    }
  }

  startMenuMusic() {
    this.init();
    if (this.musicVolume <= 0) return;
    if (!this.menuAudio) {
      this.menuAudio = new Audio('/menu-music.mp3');
      this.menuAudio.loop = true;
    }
    this.menuAudio.volume = this.musicVolume * 0.6;
    // play() returns a promise; if blocked by autoplay policy, it will retry
    // on the next user interaction (the init() call above resumes AudioContext).
    this.menuAudio.play().catch(() => {
      // Autoplay blocked — will be retried on next startMenuMusic call
      // (triggered by user interaction via button clicks which call audio.init()).
    });
  }

  stopMenuMusic() {
    if (this.menuAudio) {
      this.menuAudio.pause();
    }
  }

  stopMusic() {
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.5);
      setTimeout(() => {
        if (this.musicOsc) {
          this.musicOsc.stop();
          this.musicOsc.disconnect();
          this.musicOsc = null;
        }
        if (this.lfo) {
          this.lfo.stop();
          this.lfo.disconnect();
          this.lfo = null;
        }
        if (this.musicGain) {
          this.musicGain.disconnect();
          this.musicGain = null;
        }
      }, 1000);
    }
  }
}

export const audio = new AudioManager();
