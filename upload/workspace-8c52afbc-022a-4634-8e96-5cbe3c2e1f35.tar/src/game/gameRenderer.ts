/**
 * @fileoverview Рендеринг игры на Canvas 2D.
 *
 * Все функции отрисовки вынесены сюда из игрового цикла для чистоты:
 * - renderBackground: космический фон (звёзды, туманности, сетка, кольца)
 * - renderParticles: частицы (взрывы, попадания)
 * - renderShockwaves: ударные волны (синие, от улучшения)
 * - renderDustParticles: пыль в режиме босса
 * - renderGravityBeams: фиолетовые лучи босса к врагам
 * - renderMiniBlackHoles: мини-чёрные дыры (поглощают стрелы)
 * - renderProjectiles: стрелы (обычные, крит, магнитные)
 * - renderEnemies: враги + их HP-бары + босс
 * - renderBow: лук игрока + прицел + стрелу на тетиве
 * - renderReload: индикатор перезарядки
 *
 * Вызываются из useGameLoop.ts в секции «Draw» каждый кадр.
 *
 * @see useGameLoop.ts — где вызываются эти функции
 * @see enemies.ts → drawShape — универсальная отрисовка фигур врагов
 */

import { Enemy, Particle, Projectile, drawShape } from './enemies';
import { InternalGameState } from './gameLogic';

export function renderBackground(ctx: CanvasRenderingContext2D, W: number, H: number, frame: number, cx: number, cy: number) {
  ctx.clearRect(0, 0, W, H);

  // Deep space gradient
  const bgGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H));
  bgGrad.addColorStop(0, '#0a0520');
  bgGrad.addColorStop(1, '#020108');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // Nebulae (Gas clouds)
  ctx.globalCompositeOperation = 'screen';
  const t = frame * 0.002;
  const drawNebula = (nx: number, ny: number, r: number, color: string) => {
    const nGrad = ctx.createRadialGradient(nx, ny, 0, nx, ny, r);
    nGrad.addColorStop(0, color);
    nGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = nGrad;
    ctx.beginPath();
    ctx.arc(nx, ny, r, 0, Math.PI * 2);
    ctx.fill();
  };
  drawNebula(W * 0.2 + Math.sin(t) * 150, H * 0.3 + Math.cos(t * 0.8) * 150, Math.max(W, H) * 0.5, 'rgba(100, 0, 255, 0.07)');
  drawNebula(W * 0.8 + Math.cos(t * 1.2) * 150, H * 0.7 + Math.sin(t * 1.1) * 150, Math.max(W, H) * 0.4, 'rgba(0, 200, 255, 0.06)');
  drawNebula(W * 0.5 + Math.sin(t * 0.5) * 200, H * 0.9 + Math.cos(t * 0.7) * 100, Math.max(W, H) * 0.4, 'rgba(255, 0, 100, 0.04)');
  ctx.globalCompositeOperation = 'source-over';

  // Parallax Stars
  for (let i = 0; i < 150; i++) {
    const origX = (Math.sin(i * 123.45) * 0.5 + 0.5) * W;
    const origY = (Math.cos(i * 678.90) * 0.5 + 0.5) * H;
    
    const layer = i % 3; // 0: far, 1: mid, 2: close
    const speed = (layer + 1) * 0.15;
    const size = (layer === 2 ? 1.5 : 0.8) * (Math.sin(frame * 0.03 + i) * 0.4 + 0.6);
    
    const x = (origX - frame * speed) % W;
    const y = (origY + frame * speed * 0.3) % H;
    
    // Handle negative modulo for smooth wrapping
    const wrapX = x < 0 ? x + W : x;
    const wrapY = y < 0 ? y + H : y;

    ctx.fillStyle = layer === 2 ? 'rgba(255, 255, 255, 0.9)' : (layer === 1 ? 'rgba(150, 200, 255, 0.6)' : 'rgba(100, 100, 150, 0.3)');
    ctx.beginPath();
    ctx.arc(wrapX, wrapY, size, 0, Math.PI * 2);
    ctx.fill();
    
    // Add a slight glow to close stars
    if (layer === 2 && Math.sin(frame * 0.05 + i) > 0.8) {
      ctx.beginPath();
      ctx.arc(wrapX, wrapY, size * 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.fill();
    }
  }

  // Grid with perspective-like pulse (keep it subtle for the neon arcade feel)
  ctx.strokeStyle = 'rgba(0,255,255,0.03)';
  ctx.lineWidth = 1;
  const gridSize = 80;
  const offsetX = (frame * 0.2) % gridSize;
  const offsetY = (frame * 0.2) % gridSize;

  ctx.beginPath();
  for (let gx = offsetX; gx < W; gx += gridSize) {
    ctx.moveTo(gx, 0); ctx.lineTo(gx, H);
  }
  for (let gy = offsetY; gy < H; gy += gridSize) {
    ctx.moveTo(0, gy); ctx.lineTo(W, gy);
  }
  ctx.stroke();

  // Center rings with glow
  for (let r = 80; r < Math.max(W, H); r += 150) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    const alpha = 0.02 + 0.02 * Math.sin(frame * 0.015 + r * 0.001);
    ctx.strokeStyle = `rgba(0,255,255,${alpha})`;
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}

export function renderParticles(ctx: CanvasRenderingContext2D, particles: Particle[]) {
  const TAU = Math.PI * 2;
  // Precompute alpha hex strings (0-255 → "00".."ff") to avoid per-particle
  // string concatenation + Math.floor + toString in the hot loop.
  const alphaHex: string[] = new Array(256);
  for (let a = 0; a < 256; a++) {
    alphaHex[a] = a.toString(16).padStart(2, '0');
  }

  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    const alpha = p.life / p.maxLife;
    const r = p.radius * alpha;

    // Fake glow
    const glowAlphaByte = Math.min(255, Math.floor(alpha * 0.3 * 255));
    ctx.beginPath();
    ctx.arc(p.x, p.y, r * 2.5, 0, TAU);
    ctx.fillStyle = p.color + alphaHex[glowAlphaByte];
    ctx.fill();

    // Core
    const coreAlphaByte = Math.min(255, Math.floor(alpha * 255));
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, TAU);
    ctx.fillStyle = p.color + alphaHex[coreAlphaByte];
    ctx.fill();
  }
}

export function renderShockwaves(ctx: CanvasRenderingContext2D, shockwaves: { x: number; y: number; radius: number; life: number; maxLife: number }[]) {
  shockwaves.forEach(sw => {
    const alpha = sw.life / sw.maxLife;
    const t = 1 - alpha; // 0 at start, 1 at end

    // Outer glow ring (wide, soft) — blue
    ctx.beginPath();
    ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(0, 170, 255, ${alpha * 0.25})`;
    ctx.lineWidth = 18;
    ctx.stroke();

    // Mid ring (main wave color) — blue
    ctx.beginPath();
    ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(0, 170, 255, ${alpha * 0.85})`;
    ctx.lineWidth = 5;
    ctx.stroke();

    // Bright inner edge
    ctx.beginPath();
    ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha * 0.6})`;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Trailing inner ring (slightly smaller, fading) — blue
    if (t > 0.1) {
      ctx.beginPath();
      ctx.arc(sw.x, sw.y, sw.radius * 0.82, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(0, 170, 255, ${alpha * 0.4})`;
      ctx.lineWidth = 3;
      ctx.stroke();
    }
  });
}

export function renderDustParticles(ctx: CanvasRenderingContext2D, dust: { x: number; y: number; radius: number; alpha: number; absorbed: boolean; absorbProgress: number }[]) {
  // Very faint ambient dust — use 'lighter' for a subtle glow blend.
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < dust.length; i++) {
    const d = dust[i];
    if (d.alpha <= 0.01) continue;
    const r = d.radius * (d.absorbed ? (1 - d.absorbProgress * 0.5) : 1);
    // soft glow
    ctx.beginPath();
    ctx.arc(d.x, d.y, r * 2.2, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(180, 200, 255, ${d.alpha * 0.3})`;
    ctx.fill();
    // bright core
    ctx.beginPath();
    ctx.arc(d.x, d.y, r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(220, 230, 255, ${d.alpha})`;
    ctx.fill();
  }
  ctx.restore();
}

export function renderGravityBeams(ctx: CanvasRenderingContext2D, beams: { x1: number; y1: number; x2: number; y2: number; life: number; maxLife: number }[]) {
  // Purple animated energy beams from the boss to enemies.
  // Multiple layers for a volumetric look.
  const TAU = Math.PI * 2;
  const time = Date.now();

  ctx.save();
  ctx.globalCompositeOperation = 'lighter';

  for (let i = 0; i < beams.length; i++) {
    const beam = beams[i];
    const alpha = beam.life / beam.maxLife;
    const dx = beam.x2 - beam.x1;
    const dy = beam.y2 - beam.y1;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len < 1) continue;
    const angle = Math.atan2(dy, dx);

    ctx.save();
    ctx.translate(beam.x1, beam.y1);
    ctx.rotate(angle);

    // Layer 1: Wide outer glow
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(len, 0);
    ctx.strokeStyle = `rgba(191, 0, 255, ${alpha * 0.15})`;
    ctx.lineWidth = 16;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Layer 2: Mid beam
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(len, 0);
    ctx.strokeStyle = `rgba(191, 0, 255, ${alpha * 0.4})`;
    ctx.lineWidth = 6;
    ctx.stroke();

    // Layer 3: Animated energy pulses traveling along the beam
    const pulseCount = Math.max(2, Math.floor(len / 40));
    for (let p = 0; p < pulseCount; p++) {
      const phase = ((time / 200) + p / pulseCount) % 1;
      const px = phase * len;
      const pulseR = 4 + Math.sin(time / 100 + p) * 2;
      // glow
      ctx.beginPath();
      ctx.arc(px, 0, pulseR * 2, 0, TAU);
      ctx.fillStyle = `rgba(191, 0, 255, ${alpha * 0.3})`;
      ctx.fill();
      // core
      ctx.beginPath();
      ctx.arc(px, 0, pulseR, 0, TAU);
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha * 0.8})`;
      ctx.fill();
    }

    // Layer 4: Bright core line
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(len, 0);
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha * 0.6})`;
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.restore();
  }

  ctx.restore();
}

export function renderMiniBlackHoles(ctx: CanvasRenderingContext2D, blackHoles: { x: number; y: number; radius: number; absorbRadius: number; life: number; maxLife: number; angle: number }[]) {
  // Redesigned mini black holes — detailed black-white-purple cosmic voids.
  // No rotating rings (unlike the boss) — instead: swirling particle streams,
  // pulsing event horizon, energy tendrils, and a shimmering accretion disk.
  const TAU = Math.PI * 2;
  const time = Date.now();

  for (let i = 0; i < blackHoles.length; i++) {
    const bh = blackHoles[i];
    const r = bh.radius;

    // Fade in/out
    let alpha = 1;
    if (bh.life < 60) alpha = bh.life / 60;
    if (bh.life > bh.maxLife - 30) alpha = (bh.maxLife - bh.life) / 30;

    // Pulsing factor — subtle breathing
    const pulse = 1 + Math.sin(time / 300 + i) * 0.06;

    ctx.save();
    ctx.translate(bh.x, bh.y);

    // === Layer 0: Outer absorb field — swirling distortion ===
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const fieldR = bh.absorbRadius * pulse;
    const fieldGrad = ctx.createRadialGradient(0, 0, r * 0.8, 0, 0, fieldR);
    fieldGrad.addColorStop(0, `rgba(120, 40, 180, ${alpha * 0.18})`);
    fieldGrad.addColorStop(0.4, `rgba(80, 20, 120, ${alpha * 0.08})`);
    fieldGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    ctx.arc(0, 0, fieldR, 0, TAU);
    ctx.fillStyle = fieldGrad;
    ctx.fill();
    ctx.restore();

    // === Layer 1: Swirling particle stream — dots spiraling inward ===
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.rotate(bh.angle * 0.5);
    const particleCount = 14;
    for (let p = 0; p < particleCount; p++) {
      const spiralAngle = bh.angle * 2 + (TAU / particleCount) * p;
      const spiralT = (p / particleCount + Math.sin(time / 400 + p) * 0.05) % 1;
      const spiralR = r * 1.0 + (bh.absorbRadius - r) * (1 - spiralT);
      const sx = Math.cos(spiralAngle) * spiralR;
      const sy = Math.sin(spiralAngle) * spiralR;
      const pAlpha = alpha * spiralT * 0.6;
      const pSize = 1 + spiralT * 2;
      // glow
      ctx.beginPath();
      ctx.arc(sx, sy, pSize * 2, 0, TAU);
      ctx.fillStyle = `rgba(180, 120, 255, ${pAlpha * 0.3})`;
      ctx.fill();
      // core
      ctx.beginPath();
      ctx.arc(sx, sy, pSize, 0, TAU);
      ctx.fillStyle = `rgba(220, 200, 255, ${pAlpha})`;
      ctx.fill();
    }
    ctx.restore();

    // === Layer 2: Energy tendrils — short jagged arcs around the void ===
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.rotate(-bh.angle * 1.5);
    const tendrilCount = 5;
    for (let t = 0; t < tendrilCount; t++) {
      const baseAngle = (TAU / tendrilCount) * t + Math.sin(time / 250 + t) * 0.2;
      const tendrilLen = 0.6 + Math.sin(time / 180 + t * 1.5) * 0.15;
      ctx.beginPath();
      ctx.arc(0, 0, r * 1.3, baseAngle, baseAngle + tendrilLen);
      ctx.strokeStyle = `rgba(160, 100, 220, ${alpha * 0.45})`;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.stroke();
      // bright inner edge
      ctx.beginPath();
      ctx.arc(0, 0, r * 1.3, baseAngle, baseAngle + tendrilLen * 0.6);
      ctx.strokeStyle = `rgba(255, 240, 255, ${alpha * 0.3})`;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();

    // === Layer 3: Accretion disk — flat elliptical band with gradient ===
    ctx.save();
    ctx.rotate(bh.angle * 0.8);
    ctx.scale(1, 0.25);
    ctx.beginPath();
    ctx.arc(0, 0, r * 2.0 * pulse, 0, TAU);
    const diskGrad = ctx.createRadialGradient(0, 0, r * 0.8, 0, 0, r * 2.0);
    diskGrad.addColorStop(0, `rgba(255, 255, 255, ${alpha * 0.0})`);
    diskGrad.addColorStop(0.3, `rgba(200, 150, 255, ${alpha * 0.4})`);
    diskGrad.addColorStop(0.6, `rgba(120, 60, 180, ${alpha * 0.3})`);
    diskGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.strokeStyle = diskGrad;
    ctx.lineWidth = 6;
    ctx.stroke();
    ctx.restore();

    // === Layer 4: Event horizon — dark void with layered gradient ===
    ctx.beginPath();
    ctx.arc(0, 0, r * pulse, 0, TAU);
    const voidGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, r * pulse);
    voidGrad.addColorStop(0, '#000000');
    voidGrad.addColorStop(0.5, '#000000');
    voidGrad.addColorStop(0.75, `rgba(30, 0, 40, ${alpha})`);
    voidGrad.addColorStop(0.9, `rgba(80, 20, 100, ${alpha})`);
    voidGrad.addColorStop(0.97, `rgba(180, 100, 220, ${alpha * 0.6})`);
    voidGrad.addColorStop(1, `rgba(200, 150, 255, ${alpha * 0.2})`);
    ctx.fillStyle = voidGrad;
    ctx.fill();

    // === Layer 5: Photon ring — thin bright ring at the edge of the void ===
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.95 * pulse, 0, TAU);
    ctx.strokeStyle = `rgba(255, 240, 255, ${alpha * 0.5})`;
    ctx.lineWidth = 1;
    ctx.stroke();

    // === Layer 6: Pulsing inner core — small bright dot that flickers ===
    const coreFlicker = 0.6 + Math.sin(time / 80 + i * 2) * 0.3;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.3 * pulse, 0, TAU);
    const coreGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, r * 0.3);
    coreGrad.addColorStop(0, `rgba(255, 255, 255, ${alpha * coreFlicker})`);
    coreGrad.addColorStop(0.5, `rgba(200, 150, 255, ${alpha * coreFlicker * 0.5})`);
    coreGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = coreGrad;
    ctx.fill();
    ctx.restore();

    // === Layer 7: Inner pure black singularity ===
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.25 * pulse, 0, TAU);
    ctx.fillStyle = '#000000';
    ctx.fill();

    // === Layer 8: Spawn/despawn flash ===
    if (bh.life > bh.maxLife - 20) {
      const flashAlpha = (bh.maxLife - bh.life) / 20;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.beginPath();
      ctx.arc(0, 0, r * 2.5 * (1 - flashAlpha), 0, TAU);
      ctx.strokeStyle = `rgba(200, 150, 255, ${flashAlpha * 0.6})`;
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }
}

export function renderProjectiles(ctx: CanvasRenderingContext2D, projectiles: Projectile[]) {
  projectiles.forEach(p => {
    // Magnet arrows use a magenta/purple palette, crit arrows use orange, regular use cyan
    const isMagnet = p.isMagnet;
    const baseR = isMagnet ? 255 : (p.isCrit ? 255 : 0);
    const baseG = isMagnet ? 0 : (p.isCrit ? 170 : 255);
    const baseB = isMagnet ? 255 : (p.isCrit ? 0 : 255);

    // Draw trail
    if (p.trail) {
      p.trail.forEach((t, ti) => {
        const alpha = (ti / p.trail.length) * 0.6;
        const r = p.radius * (ti / p.trail.length) * (isMagnet ? 1.1 : 0.8);
        ctx.beginPath();
        ctx.arc(t.x, t.y, r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${baseR}, ${baseG}, ${baseB}, ${alpha})`;
        ctx.fill();
        // Magnet trail gets an extra white-hot core
        if (isMagnet) {
          ctx.beginPath();
          ctx.arc(t.x, t.y, r * 0.4, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${alpha * 0.7})`;
          ctx.fill();
        }
      });
    }

    // Magnet aura — pulsing magnetic field rings around the arrow (un-rotated)
    if (isMagnet) {
      const pulseT = Date.now() / 120;
      for (let ring = 0; ring < 3; ring++) {
        const phase = (pulseT + ring * 1.2) % 3;
        const ringR = 8 + phase * 10;
        const ringAlpha = Math.max(0, 0.5 - phase / 6);
        ctx.beginPath();
        ctx.arc(p.x, p.y, ringR, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 0, 255, ${ringAlpha})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      // Soft outer halo
      const haloGrad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 22);
      haloGrad.addColorStop(0, 'rgba(255, 0, 255, 0.35)');
      haloGrad.addColorStop(0.5, 'rgba(191, 0, 255, 0.15)');
      haloGrad.addColorStop(1, 'rgba(191, 0, 255, 0)');
      ctx.beginPath();
      ctx.arc(p.x, p.y, 22, 0, Math.PI * 2);
      ctx.fillStyle = haloGrad;
      ctx.fill();
    }

    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(Math.atan2(p.vy, p.vx));

    const arrowLen = 30;

    const glowColor = `rgba(${baseR}, ${baseG}, ${baseB}, ${isMagnet ? 0.7 : 0.5})`;
    const shadowColor = isMagnet ? '#ff00ff' : (p.isCrit ? '#ffaa00' : '#00ffff');
    const fillHeadEnd = isMagnet ? '#660066' : (p.isCrit ? '#aa5500' : '#005555');
    const fletchColor = `rgba(${baseR}, ${baseG}, ${baseB}, 0.9)`;

    // Arrow shaft glow (thicker for magnet)
    ctx.beginPath();
    ctx.moveTo(-25, 0);
    ctx.lineTo(arrowLen, 0);
    ctx.strokeStyle = `rgba(${baseR}, ${baseG}, ${baseB}, ${isMagnet ? 0.3 : 0.2})`;
    ctx.lineWidth = isMagnet ? 16 : 12;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-25, 0);
    ctx.lineTo(arrowLen, 0);
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = isMagnet ? 5 : 4;
    ctx.stroke();

    // Arrow shaft core
    ctx.beginPath();
    ctx.moveTo(-25, 0);
    ctx.lineTo(arrowLen, 0);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // High-tech Arrow head
    ctx.beginPath();
    ctx.moveTo(arrowLen + 8, 0);
    ctx.lineTo(arrowLen - 6, -6);
    ctx.lineTo(arrowLen - 2, 0);
    ctx.lineTo(arrowLen - 6, 6);
    ctx.closePath();
    const headGrad = ctx.createLinearGradient(arrowLen - 6, -6, arrowLen + 8, 8);
    headGrad.addColorStop(0, '#ffffff');
    headGrad.addColorStop(0.4, shadowColor);
    headGrad.addColorStop(1, fillHeadEnd);
    ctx.fillStyle = headGrad;
    ctx.fill();

    // Arrow fletching (Energy fins)
    ctx.beginPath();
    ctx.moveTo(-25, 0);
    ctx.lineTo(-33, -6);
    ctx.lineTo(-28, 0);
    ctx.lineTo(-33, 6);
    ctx.closePath();
    ctx.fillStyle = fletchColor;
    ctx.fill();

    // Extra energy rings around the arrow
    ctx.beginPath();
    ctx.ellipse(0, 0, 3, 9, 0, 0, Math.PI * 2);
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = isMagnet ? 2 : 1.5;
    ctx.stroke();

    // Magnet arrows get an extra small magnet icon glow at the tip
    if (isMagnet) {
      ctx.beginPath();
      ctx.arc(arrowLen + 4, 0, 5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(arrowLen + 4, 0, 8, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 0, 255, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    ctx.restore();
  });
}

export function renderEnemies(ctx: CanvasRenderingContext2D, enemies: Enemy[]) {
  enemies.forEach(e => {
    const isGhost = e.id === 'ghost';
    const isPhantom = e.id === 'phantom';
    const hasAlpha = isGhost || isPhantom;
    const alpha = hasAlpha ? (e.teleportAlpha ?? 1) : 1;
    const ringAnim = e.teleportRingAnim ?? 0;

    // Анимация появления после телепортации: расширяющееся кольцо (рисуем до globalAlpha)
    if (isGhost && ringAnim > 0) {
      const ringProgress = 1 - ringAnim / 30;
      const ringRadius = e.radius + ringProgress * e.radius * 2.5;
      const ringAlpha = ringAnim / 30;
      ctx.globalAlpha = ringAlpha;
      // Внешнее кольцо
      ctx.beginPath();
      ctx.arc(e.x, e.y, ringRadius, 0, Math.PI * 2);
      ctx.strokeStyle = e.color + '44';
      ctx.lineWidth = 15 * ringAlpha;
      ctx.stroke();
      ctx.strokeStyle = e.color;
      ctx.lineWidth = 3 * ringAlpha;
      ctx.stroke();
      // Второе кольцо чуть меньше
      ctx.beginPath();
      ctx.arc(e.x, e.y, ringRadius * 0.65, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.4)';
      ctx.lineWidth = 8 * ringAlpha;
      ctx.stroke();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5 * ringAlpha;
      ctx.stroke();
    }

    ctx.globalAlpha = alpha;

    // Draw Enemy Trail
    if (e.trail && e.trail.length > 1) {
      ctx.save();
      for (let i = 0; i < e.trail.length - 1; i++) {
        const p1 = e.trail[i];
        const p2 = e.trail[i+1];
        const progress = (i + 1) / e.trail.length; // 0 to 1
        
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        
        ctx.strokeStyle = e.color;
        ctx.globalAlpha = alpha * progress * 0.15;
        ctx.lineWidth = e.radius * 1.5 * progress;
        ctx.lineCap = 'round';
        ctx.stroke();
        
        ctx.globalAlpha = alpha * progress * 0.4;
        ctx.lineWidth = e.radius * 0.8 * progress;
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.strokeStyle = '#ffffff';
        ctx.globalAlpha = alpha * progress * 0.2;
        ctx.lineWidth = e.radius * 0.2 * progress;
        ctx.lineCap = 'round';
        ctx.stroke();
      }
      
      // Connection to current enemy position
      const lastP = e.trail[e.trail.length - 1];
      ctx.beginPath();
      ctx.moveTo(lastP.x, lastP.y);
      ctx.lineTo(e.x, e.y);
      ctx.strokeStyle = e.color;
      ctx.globalAlpha = alpha * 0.5;
      ctx.lineWidth = e.radius * 0.8;
      ctx.lineCap = 'round';
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(lastP.x, lastP.y);
      ctx.lineTo(e.x, e.y);
      ctx.strokeStyle = '#ffffff';
      ctx.globalAlpha = alpha * 0.3;
      ctx.lineWidth = e.radius * 0.2;
      ctx.lineCap = 'round';
      ctx.stroke();
      
      ctx.restore();
      ctx.globalAlpha = alpha; // restore
    }

    // Pulse glow ring
    ctx.save();
    ctx.translate(e.x, e.y);
    // Add dynamic rotation to the pulse ring
    ctx.rotate((Date.now() / 1000) * (e.id === 'tank' ? 0.5 : 1.5));
    ctx.beginPath();
    ctx.arc(0, 0, e.pulseRadius + Math.sin(Date.now() / 150) * 2 + 4, 0, Math.PI * 2);
    ctx.strokeStyle = e.color + 'aa';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([10, 15, 3, 15]);
    ctx.stroke();
    // fake pulse glow
    ctx.strokeStyle = e.color + '44';
    ctx.lineWidth = 6;
    ctx.stroke();
    
    // Additional inner dashed ring
    ctx.beginPath();
    ctx.rotate(-Date.now() / 500);
    ctx.arc(0, 0, e.radius + 6, 0, Math.PI * 2);
    ctx.strokeStyle = e.color + '66';
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 6]);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // Fade-in ring (пока появляется после телепорта)
    if (isGhost && alpha < 1 && !e.teleportFading) {
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius * (1.5 + (1 - alpha)), 0, Math.PI * 2);
      ctx.strokeStyle = e.color + '66';
      ctx.lineWidth = 10;
      ctx.stroke();
      ctx.strokeStyle = e.color;
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Индикатор оставшихся телепортаций (маленькие точки над врагом)
    if (isGhost && (e.teleportsLeft ?? 0) > 0 && alpha >= 1) {
      ctx.globalAlpha = 0.8;
      const dots = e.teleportsLeft ?? 0;
      for (let d = 0; d < dots; d++) {
        const dotX = e.x - (dots - 1) * 5 + d * 10;
        const dotY = e.y - e.radius - 22;
        ctx.beginPath();
        ctx.arc(dotX, dotY, 3, 0, Math.PI * 2);
        ctx.fillStyle = e.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = e.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      ctx.globalAlpha = alpha;
    }

    drawShape(ctx, e.shape, e.x, e.y, e.radius, e.color, e.glowColor, e.angle, e.flashTimer, e.hp, e.maxHp);

    // HP bar -> Curved Arc HP Bar
    if (e.maxHp > 1 && e.hp < e.maxHp) {
      const radius = e.radius + 12; // place it just outside the enemy
      const startAngle = -Math.PI; // Top left
      const endAngle = 0; // Top right
      const hpPercentage = Math.max(0, e.hp / e.maxHp);
      
      // Calculate the angle for the current HP
      const currentAngle = startAngle + (endAngle - startAngle) * hpPercentage;

      ctx.save();
      ctx.translate(e.x, e.y);
      
      // Background track
      ctx.beginPath();
      ctx.arc(0, 0, radius, startAngle, endAngle);
      ctx.strokeStyle = 'rgba(0,0,0,0.5)';
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.stroke();

      // HP value
      ctx.beginPath();
      ctx.arc(0, 0, radius, startAngle, currentAngle);
      ctx.strokeStyle = e.color + '66';
      ctx.lineWidth = 9;
      ctx.lineCap = 'round';
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, radius, startAngle, currentAngle);
      ctx.strokeStyle = e.color;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.stroke();
      
      ctx.restore();
    }
    
    // Epic Huge Boss HP
    if (e.id === 'boss_omega') {
      const W = ctx.canvas.width;
      const bw = W * 0.6;
      const bh = 22;
      const bx = (W - bw) / 2;
      const by = 40;

      ctx.save();
      const hpPercentage = Math.max(0, e.hp / e.maxHp);
      // Phase: 0 (full) → 2 (near death)
      const bossPhase = Math.min(2, Math.floor((1 - hpPercentage) * 3));
      const barColor = bossPhase >= 2 ? '#ff0044' : (bossPhase >= 1 ? '#ff00aa' : e.glowColor);

      // Outer frame glow
      ctx.shadowBlur = 18;
      ctx.shadowColor = barColor;
      ctx.strokeStyle = barColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(bx - 2, by - 2, bw + 4, bh + 4);

      // bg track
      ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(0,0,0,0.85)';
      ctx.fillRect(bx, by, bw, bh);

      // inner border
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.lineWidth = 1;
      ctx.strokeRect(bx, by, bw, bh);

      // HP fill — gradient
      const fillGrad = ctx.createLinearGradient(bx, by, bx, by + bh);
      fillGrad.addColorStop(0, '#ffffff');
      fillGrad.addColorStop(0.3, barColor);
      fillGrad.addColorStop(1, bossPhase >= 2 ? '#660022' : '#330055');
      ctx.fillStyle = fillGrad;
      ctx.shadowBlur = 12;
      ctx.shadowColor = barColor;
      ctx.fillRect(bx, by, bw * hpPercentage, bh);

      // Sheen overlay on the filled portion
      if (hpPercentage > 0) {
        ctx.shadowBlur = 0;
        const sheenGrad = ctx.createLinearGradient(bx, by, bx, by + bh);
        sheenGrad.addColorStop(0, 'rgba(255,255,255,0.4)');
        sheenGrad.addColorStop(0.5, 'rgba(255,255,255,0.1)');
        sheenGrad.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = sheenGrad;
        ctx.fillRect(bx, by, bw * hpPercentage, bh);
      }

      // Phase tick marks (33% and 66%)
      ctx.shadowBlur = 0;
      ctx.strokeStyle = 'rgba(255,255,255,0.3)';
      ctx.lineWidth = 1;
      [0.33, 0.66].forEach(t => {
        const tx = bx + bw * t;
        ctx.beginPath();
        ctx.moveTo(tx, by);
        ctx.lineTo(tx, by + bh);
        ctx.stroke();
      });

      // Title with glow
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 18px Orbitron';
      ctx.shadowBlur = 8;
      ctx.shadowColor = barColor;
      ctx.textAlign = 'center';
      ctx.fillText(e.name.toUpperCase() + (bossPhase >= 2 ? ' — ОПАСНОСТЬ!' : ''), W / 2, by - 12);

      // HP percentage text
      ctx.font = 'bold 11px Orbitron';
      ctx.shadowBlur = 4;
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.fillText(`${Math.round(hpPercentage * 100)}%`, W / 2, by + bh / 2 + 4);

      ctx.restore();
    }

    ctx.globalAlpha = 1;
  });
}

export function renderBow(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  mx: number,
  my: number,
  s: InternalGameState,
) {
  const bowAngle = Math.atan2(my - cy, mx - cx);
  const pulse = s.bowPulse > 0 ? 1 + s.bowPulse * 0.04 : 1;

  // Invulnerability flicker
  if (s.invulnTimer > 0 && Math.floor(Date.now() / 50) % 2 === 0) return;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(bowAngle);

  // Bow outer glow ring (multiple layers for volume)
  ctx.beginPath();
  ctx.arc(0, 0, 24 * pulse, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(0,255,255,0.15)';
  ctx.lineWidth = 14;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(0, 0, 22 * pulse, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(0,255,255,0.2)';
  ctx.lineWidth = 14;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(0, 0, 22 * pulse, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(0,255,255,0.6)';
  ctx.lineWidth = 4;
  ctx.stroke();

  // 3D Core Base
  ctx.beginPath();
  ctx.arc(0, 0, 18 * pulse, 0, Math.PI * 2);
  const coreGrad = ctx.createRadialGradient(-5, -5, 0, 0, 0, 18 * pulse);
  coreGrad.addColorStop(0, '#ffffff');
  coreGrad.addColorStop(0.3, '#00ffff');
  coreGrad.addColorStop(0.8, '#005555');
  coreGrad.addColorStop(1, '#000000');
  ctx.fillStyle = coreGrad;
  ctx.fill();

  // Bow body with 3D gradient
  const bowGrad = ctx.createLinearGradient(0, -22, 0, 22);
  bowGrad.addColorStop(0, '#00ffff');
  bowGrad.addColorStop(0.2, '#ffffff');
  bowGrad.addColorStop(0.5, '#00aaff');
  bowGrad.addColorStop(0.8, '#ffffff');
  bowGrad.addColorStop(1, '#00ffff');

  // Mechanical Bow Limbs
  ctx.beginPath();
  // Top limb
  ctx.moveTo(-12 * pulse, -38 * pulse);
  ctx.lineTo(8 * pulse, -25 * pulse);
  ctx.lineTo(0, -15 * pulse);
  // Bottom limb
  ctx.moveTo(-12 * pulse, 38 * pulse);
  ctx.lineTo(8 * pulse, 25 * pulse);
  ctx.lineTo(0, 15 * pulse);
  
  ctx.strokeStyle = bowGrad;
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.stroke();
  
  // Inner mechanical details
  ctx.beginPath();
  ctx.moveTo(-8 * pulse, -35 * pulse);
  ctx.lineTo(5 * pulse, -25 * pulse);
  ctx.moveTo(-8 * pulse, 35 * pulse);
  ctx.lineTo(5 * pulse, 25 * pulse);
  ctx.strokeStyle = 'rgba(255,255,255,0.8)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Floating stabilizers
  const time = Date.now() * 0.005;
  const stabOffset = Math.sin(time) * 4;
  ctx.beginPath();
  ctx.moveTo(-18 * pulse, -45 * pulse + stabOffset);
  ctx.lineTo(-8 * pulse, -45 * pulse + stabOffset);
  ctx.moveTo(-18 * pulse, 45 * pulse - stabOffset);
  ctx.lineTo(-8 * pulse, 45 * pulse - stabOffset);
  ctx.strokeStyle = '#00ffff';
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Specular highlight on the core
  ctx.beginPath();
  ctx.ellipse(-6 * pulse, -6 * pulse, 8 * pulse, 4 * pulse, Math.PI / 4, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,0.7)';
  ctx.fill();

  // Bow string (Energy tethers)
  ctx.beginPath();
  ctx.moveTo(-12 * pulse, -38 * pulse);
  ctx.lineTo(15 * pulse, 0);
  ctx.lineTo(-12 * pulse, 38 * pulse);
  ctx.strokeStyle = 'rgba(0,255,255,0.6)';
  ctx.lineWidth = 2;
  ctx.stroke();
  
  ctx.beginPath();
  ctx.moveTo(-12 * pulse, -38 * pulse);
  ctx.lineTo(26 * pulse, 0);
  ctx.lineTo(-12 * pulse, 38 * pulse);
  ctx.strokeStyle = 'rgba(255,255,255,0.9)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Arrow ready with better detail and volume
  // The last arrow is a magnet arrow (magenta/purple) if the upgrade is purchased
  if (!s.reloading && s.arrows > 0) {
    const isLastMagnet = s.magnetArrow > 0 && s.arrows === 1;
    const aR = isLastMagnet ? 255 : 0;
    const aG = isLastMagnet ? 0 : 255;
    const aB = isLastMagnet ? 255 : 255;
    const arrowLen = 42 * pulse;

    // Magnet aura around the nocked arrow
    if (isLastMagnet) {
      const pulseT = Date.now() / 150;
      for (let ring = 0; ring < 2; ring++) {
        const phase = (pulseT + ring * 1.3) % 2.6;
        const ringR = 14 + phase * 12;
        const ringAlpha = Math.max(0, 0.45 - phase / 5.5);
        ctx.beginPath();
        ctx.arc(arrowLen * 0.4, 0, ringR, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 0, 255, ${ringAlpha})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }

    // Arrow shaft glow
    ctx.beginPath();
    ctx.moveTo(-15, 0);
    ctx.lineTo(arrowLen, 0);
    ctx.strokeStyle = `rgba(${aR}, ${aG}, ${aB}, ${isLastMagnet ? 0.3 : 0.2})`;
    ctx.lineWidth = isLastMagnet ? 14 : 12;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-15, 0);
    ctx.lineTo(arrowLen, 0);
    ctx.strokeStyle = `rgba(${aR}, ${aG}, ${aB}, ${isLastMagnet ? 0.75 : 0.6})`;
    ctx.lineWidth = isLastMagnet ? 5 : 4;
    ctx.stroke();

    // Arrow shaft core
    ctx.beginPath();
    ctx.moveTo(-15, 0);
    ctx.lineTo(arrowLen, 0);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 0;
    ctx.stroke();

    // High-tech Arrow head (3D)
    ctx.beginPath();
    ctx.moveTo(arrowLen + 8, 0);
    ctx.lineTo(arrowLen - 6, -8);
    ctx.lineTo(arrowLen - 2, 0);
    ctx.lineTo(arrowLen - 6, 8);
    ctx.closePath();
    const headGrad = ctx.createLinearGradient(arrowLen - 6, -8, arrowLen + 8, 8);
    headGrad.addColorStop(0, '#ffffff');
    headGrad.addColorStop(0.4, isLastMagnet ? '#ff00ff' : '#00ffff');
    headGrad.addColorStop(1, isLastMagnet ? '#660066' : '#005555');
    ctx.fillStyle = headGrad;
    ctx.fill();

    // Arrow fletching (Energy fins)
    ctx.beginPath();
    ctx.moveTo(-15, 0);
    ctx.lineTo(-25, -8);
    ctx.lineTo(-18, 0);
    ctx.lineTo(-25, 8);
    ctx.closePath();
    ctx.fillStyle = `rgba(${aR}, ${aG}, ${aB}, 0.9)`;
    ctx.fill();

    // Extra energy rings around the arrow
    ctx.beginPath();
    ctx.ellipse(0, 0, 4, 12, 0, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(${aR}, ${aG}, ${aB}, ${isLastMagnet ? 0.9 : 0.8})`;
    ctx.lineWidth = isLastMagnet ? 2 : 1.5;
    ctx.stroke();
  }

  ctx.restore();
}

export function renderAim(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  mx: number,
  my: number,
) {
  // Aim line
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(mx, my);
  ctx.strokeStyle = 'rgba(0,255,255,0.12)';
  ctx.lineWidth = 1;
  ctx.setLineDash([6, 8]);
  ctx.stroke();
  ctx.setLineDash([]);

  // Crosshair
  const chSize = 10;
  ctx.strokeStyle = 'rgba(0,255,255,0.3)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(mx - chSize, my); ctx.lineTo(mx + chSize, my);
  ctx.moveTo(mx, my - chSize); ctx.lineTo(mx, my + chSize);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(mx, my, 5, 0, Math.PI * 2);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(0,255,255,0.8)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(mx - chSize, my); ctx.lineTo(mx + chSize, my);
  ctx.moveTo(mx, my - chSize); ctx.lineTo(mx, my + chSize);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(mx, my, 5, 0, Math.PI * 2);
  ctx.stroke();
}

export function renderReload(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  reloadProgress: number,
) {
  ctx.beginPath();
  ctx.arc(cx, cy, 35, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * reloadProgress);
  ctx.strokeStyle = 'rgba(0,255,255,0.3)';
  ctx.lineWidth = 8;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(cx, cy, 35, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * reloadProgress);
  ctx.strokeStyle = '#00ffff';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = 'rgba(0,255,255,0.9)';
  ctx.font = 'bold 11px Orbitron, monospace';
  ctx.textAlign = 'center';
  ctx.fillText('RELOAD', cx, cy + 55);
}