/**
 * @fileoverview Определения врагов и отрисовка фигур (drawShape).
 *
 * Содержит:
 * - Типы: EnemyType, Enemy, Projectile, Particle, DustParticle
 * - Массив ENEMY_TYPES: все 12 типов врагов (от scout до boss_omega)
 * - createEnemy(): фабрика создания врага с случайной позицией спавна
 * - drawShape(): универсальная функция отрисовки врага по форме (circle, hexagon, blackhole, и т.д.)
 *
 * Чтобы добавить нового врага:
 * 1. Добавить объект в ENEMY_TYPES
 * 2. При уникальной форме — добавить case в drawShape
 * 3. Добавить паттерн движения в tickEnemies() (gameLogic.ts)
 *
 * @see gameLogic.ts — где враги обновляются
 * @see gameRenderer.ts — где враги рендерятся (renderEnemies вызывает drawShape)
 */

export type EnemyType = {
  id: string;
  name: string;
  color: string;
  glowColor: string;
  shape: 'circle' | 'triangle' | 'square' | 'hexagon' | 'star' | 'diamond' | 'pentagon' | 'blackhole';
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  radius: number;
  points: number;
  pattern: 'straight' | 'zigzag' | 'spiral' | 'teleport' | 'chase' | 'bounce' | 'split' | 'stealth' | 'summoner' | 'boss_omega';
  special?: string;
  description: string;
};

export type Enemy = EnemyType & {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  zigzagTimer: number;
  teleportTimer: number;
  splitDone?: boolean;
  pulseRadius: number;
  pulseGrowing: boolean;
  flashTimer: number;
  bouncerEntered?: boolean;
  teleportAlpha?: number;
  teleportFading?: boolean;
  teleportsLeft?: number;
  teleportRingAnim?: number;
  summonTimer?: number;
  orbitPhase?: 'pull' | 'orbiting' | 'released';
  orbitAngle?: number;
  orbitRadius?: number;
  orbitTimer?: number;
  bossBuffed?: boolean;
};

export type Projectile = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  trail: { x: number; y: number }[];
  damage: number;
  pierceLeft: number;
  hitEnemies: number[];
  isCrit?: boolean;
  isMagnet?: boolean;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  radius: number;
};

// Ambient dust particles for boss mode — gently drift, get attracted & absorbed by the boss.
export type DustParticle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  baseAlpha: number;     // baseline visibility
  alpha: number;         // current alpha (fades when being absorbed)
  orbitAngle: number;    // spiral angle around boss
  absorbed: boolean;     // being consumed
  absorbProgress: number; // 0 → 1 as it's eaten
};

export const ENEMY_TYPES: Omit<EnemyType, 'hp'>[] = [
  {
    id: 'scout',
    name: 'Скаут',
    color: '#00ff41',
    glowColor: 'rgba(0,255,65,0.6)',
    shape: 'circle',
    maxHp: 100, // 1 hit originally
    speed: 2.5,
    damage: 10,
    radius: 14,
    points: 10,
    pattern: 'straight',
    description: 'Быстрый и слабый. Умирает с одного попадания.',
  },
  {
    id: 'tank',
    name: 'Танк',
    color: '#ff6600',
    glowColor: 'rgba(255,102,0,0.6)',
    shape: 'hexagon',
    maxHp: 500, // 5 hits originally
    speed: 1.0,
    damage: 30,
    radius: 24,
    points: 40,
    pattern: 'straight',
    description: 'Медленный, но требует 5 попаданий. Наносит большой урон.',
  },
  {
    id: 'zigzagger',
    name: 'Зигзаг',
    color: '#ffff00',
    glowColor: 'rgba(255,255,0,0.6)',
    shape: 'diamond',
    maxHp: 200, // 2 hits
    speed: 2.0,
    damage: 15,
    radius: 16,
    points: 25,
    pattern: 'zigzag',
    special: 'Движется зигзагом',
    description: 'Движется зигзагом — сложно прицелиться. 2 попадания.',
  },
  {
    id: 'ghost',
    name: 'Призрак',
    color: '#bf00ff',
    glowColor: 'rgba(191,0,255,0.6)',
    shape: 'pentagon',
    maxHp: 300, // 3 hits
    speed: 1.8,
    damage: 20,
    radius: 18,
    points: 35,
    pattern: 'teleport',
    special: 'Телепортируется',
    description: 'Периодически телепортируется. Держи глаз востро!',
  },
  {
    id: 'splitter',
    name: 'Делитель',
    color: '#ff006e',
    glowColor: 'rgba(255,0,110,0.6)',
    shape: 'square',
    maxHp: 400, // 4 hits
    speed: 1.5,
    damage: 20,
    radius: 20,
    points: 50,
    pattern: 'straight',
    special: 'Делится при смерти',
    description: 'При гибели делится на 2 скаута. Будь осторожен!',
  },
  {
    id: 'berserker',
    name: 'Берсерк',
    color: '#ff0000',
    glowColor: 'rgba(255,0,0,0.7)',
    shape: 'star',
    maxHp: 300, // 3 hits
    speed: 3.5,
    damage: 30,
    radius: 17,
    points: 60,
    pattern: 'chase',
    special: 'Преследует игрока',
    description: 'Быстро несётся прямо на лук. Очень опасен!',
  },
  {
    id: 'bouncer',
    name: 'Рикошет',
    color: '#00ffff',
    glowColor: 'rgba(0,255,255,0.6)',
    shape: 'triangle',
    maxHp: 300, // 3 hits
    speed: 2.2,
    damage: 15,
    radius: 15,
    points: 45,
    pattern: 'bounce',
    special: 'Отражается от стен',
    description: 'Отскакивает от краёв экрана. Непредсказуемый!',
  },
  {
    id: 'spiraler',
    name: 'Вихрь',
    color: '#00e5ff',
    glowColor: 'rgba(0,229,255,0.6)',
    shape: 'diamond',
    maxHp: 200, // 2 hits
    speed: 3.2,
    damage: 15,
    radius: 14,
    points: 40,
    pattern: 'spiral',
    special: 'Орбитальное движение',
    description: 'Кружит вокруг лука, постепенно приближаясь. Очень юркий!',
  },
  {
    id: 'juggernaut',
    name: 'Джаггернаут',
    color: '#ff0033',
    glowColor: 'rgba(255,0,51,0.7)',
    shape: 'hexagon',
    maxHp: 1000, // 10 hits
    speed: 0.8,
    damage: 50,
    radius: 35,
    points: 150,
    pattern: 'chase',
    special: 'Тяжёлая броня',
    description: 'Огромный и медленный гигант. Пробивай его броню градом стрел!',
  },
  {
    id: 'phantom',
    name: 'Фантом',
    color: '#9d00ff',
    glowColor: 'rgba(157,0,255,0.6)',
    shape: 'triangle',
    maxHp: 200, // 2 hits
    speed: 1.8,
    damage: 25,
    radius: 16,
    points: 80,
    pattern: 'stealth',
    special: 'Невидимость',
    description: 'Скрывается в тени. Становится видимым только перед самой атакой!',
  },
  {
    id: 'necromancer',
    name: 'Некромант',
    color: '#ff00ff',
    glowColor: 'rgba(255,0,255,0.6)',
    shape: 'pentagon',
    maxHp: 800, // 8 hits
    speed: 0.6,
    damage: 40,
    radius: 28,
    points: 200,
    pattern: 'summoner',
    special: 'Призывает миньонов',
    description: 'Держится на расстоянии и постоянно призывает скаутов. Уничтожь его быстрее!',
  },
  {
    id: 'boss_omega',
    name: 'Омега',
    color: '#000000',
    glowColor: '#8000ff',
    shape: 'blackhole',
    hp: 20000,
    maxHp: 20000, 
    speed: 1.2,
    damage: 100,
    radius: 70,
    points: 500000,
    pattern: 'boss_omega',
    special: 'Чёрная дыра, рой',
    description: 'Ультимативная машина смерти! Долгий эпичный бой.',
  }
];

export function createEnemy(
  type: Omit<EnemyType, 'hp'>,
  canvasW: number,
  canvasH: number,
  overrides?: Partial<Enemy>
): Enemy {
  if (!type) {
    type = ENEMY_TYPES.find(t => t.id === 'scout')!;
  }
  const side = Math.floor(Math.random() * 4);
  let spawnX = 0, spawnY = 0;
  const margin = 60;
  switch (side) {
    case 0: spawnX = Math.random() * canvasW; spawnY = -margin; break;
    case 1: spawnX = canvasW + margin; spawnY = Math.random() * canvasH; break;
    case 2: spawnX = Math.random() * canvasW; spawnY = canvasH + margin; break;
    case 3: spawnX = -margin; spawnY = Math.random() * canvasH; break;
  }

  const finalX = overrides?.x ?? spawnX;
  const finalY = overrides?.y ?? spawnY;
  const speed = type.speed * (0.85 + Math.random() * 0.3);
  
  let angle;
  if (type.id === 'bouncer' && !overrides) {
    // Ricochet should aim at a wall, not the player
    const targetSide = (side + 1 + Math.floor(Math.random() * 3)) % 4;
    let tx = 0, ty = 0;
    switch (targetSide) {
      case 0: tx = Math.random() * canvasW; ty = 0; break;
      case 1: tx = canvasW; ty = Math.random() * canvasH; break;
      case 2: tx = Math.random() * canvasW; ty = canvasH; break;
      case 3: tx = 0; ty = Math.random() * canvasH; break;
    }
    angle = Math.atan2(ty - finalY, tx - finalX);
  } else {
    // Default: aim at player (center)
    angle = Math.atan2(canvasH / 2 - finalY, canvasW / 2 - finalX);
  }

  return {
    ...type,
    hp: type.maxHp,
    x: finalX,
    y: finalY,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    angle,
    trail: [],
    zigzagTimer: 0,
    teleportTimer: type.id === 'phantom' ? Math.random() * 60 : Math.random() * 180,
    splitDone: false,
    pulseRadius: type.radius,
    pulseGrowing: true,
    flashTimer: 0,
    bouncerEntered: false,
    teleportAlpha: (type.pattern === 'teleport' || type.pattern === 'stealth') ? 0 : 1,
    teleportFading: false,
    teleportsLeft: type.pattern === 'teleport' ? 2 + Math.floor(Math.random() * 3) : 0,
    teleportRingAnim: 0,
    ...overrides,
  };
}

export function drawShape(
  ctx: CanvasRenderingContext2D,
  shape: EnemyType['shape'],
  x: number,
  y: number,
  radius: number,
  color: string,
  glowColor: string,
  rotation: number = 0,
  flashTimer: number = 0,
  hp: number = 0,
  maxHp: number = 1,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation);

  const flashAlpha = flashTimer > 0 ? 1 : 0;
  
  if (shape === 'blackhole') {
    // ===== Epic Boss "Omega" render — layered cosmic horror (heavily optimized) =====
    const time = Date.now();
    // Phase indicator: 0 (full hp) → 2 (near death), intensifies visuals.
    // Guard against invalid/missing hp values (defaults: hp=0, maxHp=1 → treat as full).
    const hpRatio = (maxHp > 0 && hp > 0) ? hp / maxHp : 1;
    const phase = Math.min(2, Math.floor((1 - hpRatio) * 3));
    const danger = 0.3 + phase * 0.35; // 0.3 → 1.0 as boss takes damage

    // Pulsing factor
    const pulse = 1 + Math.sin(time / 280) * 0.04;

    // Precomputed phase-dependent colors (single source of truth)
    const isCritical = phase >= 2;
    const isDamaged = phase >= 1;
    const haloR = isCritical ? 255 : 128;
    const haloG = isCritical ? 30 : 0;
    const haloB = isCritical ? 60 : 255;
    const accentColor = isCritical ? '#ff0044' : (isDamaged ? '#ff0066' : '#ffffff');
    const sparkColor = isDamaged ? '#ffccff' : '#ffffff';
    const rimColor = isCritical ? 'rgba(255, 51, 102, 0.9)' : 'rgba(255, 255, 255, 0.85)';
    const rimGlowColor = isCritical ? '#ff0044' : glowColor;
    const diskInnerColor = isDamaged ? '#ff66aa' : '#dd99ff';
    const photonRingColor = isCritical ? '#ff3366' : '#ffffff';

    // ---- Precomputed geometry (avoid recomputing in loops) ----
    const lensR = radius * 3.2 * pulse;
    const diskR = radius * 2.6;
    const midRingR = radius * 2.25;
    const photonR = radius * 1.95;
    const perpR = radius * 2.9;
    const perpInnerR = radius * 2.5;
    const eventR = radius * 1.15 * pulse;
    const rimR = radius * 1.05 * pulse;
    const coreR = radius * 0.55 * pulse;
    const TAU = Math.PI * 2;

    // Layer 0 — Massive outer gravitational lens halo (color shifts red on damage)
    // Gradient is unavoidable here (needs radial fade), but only ONE fill.
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const lensGrad = ctx.createRadialGradient(0, 0, radius * 1.2, 0, 0, lensR);
    lensGrad.addColorStop(0, `rgba(${haloR}, ${haloG}, ${haloB}, ${0.18 + danger * 0.1})`);
    lensGrad.addColorStop(0.5, `rgba(${haloR}, ${haloG}, ${haloB}, ${0.08 + danger * 0.05})`);
    lensGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    ctx.arc(0, 0, lensR, 0, TAU);
    ctx.fillStyle = lensGrad;
    ctx.fill();
    ctx.restore();

    // Layer 1 — Rotating accretion disk (main, tilted, multi-band gradient)
    // Single save/restore + single shadowBlur for the whole disk group.
    ctx.save();
    ctx.rotate(rotation * 1.8);
    ctx.scale(1, 0.32);
    ctx.shadowBlur = 35;
    ctx.shadowColor = accentColor;
    // Outer disk band — gradient stroke
    ctx.beginPath();
    ctx.arc(0, 0, diskR, 0, TAU);
    const diskGrad = ctx.createRadialGradient(0, 0, radius * 0.9, 0, 0, diskR);
    diskGrad.addColorStop(0, '#ffffff');
    diskGrad.addColorStop(0.15, diskInnerColor);
    diskGrad.addColorStop(0.4, glowColor);
    diskGrad.addColorStop(0.7, glowColor + 'aa');
    diskGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.strokeStyle = diskGrad;
    ctx.lineWidth = 22;
    ctx.stroke();

    // Mid bright ring + Inner photon ring (shared shadowBlur=10, then reset)
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(0, 0, midRingR, 0, TAU);
    ctx.strokeStyle = `rgba(255, 255, 255, ${0.7 + danger * 0.3})`;
    ctx.lineWidth = 5;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(0, 0, photonR, 0, TAU);
    ctx.strokeStyle = photonRingColor;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.restore();

    // Layer 2 — Perpendicular secondary disk (gives 3D volume)
    ctx.save();
    ctx.rotate(-rotation * 1.3 + Math.PI / 3);
    ctx.scale(0.22, 1);
    ctx.shadowBlur = 18;
    ctx.shadowColor = glowColor;
    ctx.beginPath();
    ctx.arc(0, 0, perpR, 0, TAU);
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = 10;
    ctx.stroke();
    // thinner inner accent
    ctx.beginPath();
    ctx.arc(0, 0, perpInnerR, 0, TAU);
    ctx.strokeStyle = `rgba(255,255,255,${0.4 + danger * 0.3})`;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.restore();

    // Layer 3 — Orbiting energy sparks (radiating from the disk)
    // Optimized: group glow-pass and core-pass separately to minimize fillStyle switches.
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const sparkCount = 7 + phase * 2;
    const glowAlpha = 0.15 + danger * 0.1;
    // First pass: all glows (single fillStyle)
    ctx.fillStyle = `rgba(255, 255, 255, ${glowAlpha})`;
    for (let i = 0; i < sparkCount; i++) {
      const sa = rotation * 2.5 + (TAU / sparkCount) * i;
      const sr = radius * (1.8 + Math.sin(time / 200 + i) * 0.4);
      const sparkR = 3 + Math.sin(time / 120 + i * 1.7) * 1.5;
      ctx.beginPath();
      ctx.arc(Math.cos(sa) * sr, Math.sin(sa) * sr * 0.35, sparkR * 3, 0, TAU);
      ctx.fill();
    }
    // Second pass: all cores (single fillStyle)
    ctx.fillStyle = sparkColor;
    for (let i = 0; i < sparkCount; i++) {
      const sa = rotation * 2.5 + (TAU / sparkCount) * i;
      const sr = radius * (1.8 + Math.sin(time / 200 + i) * 0.4);
      const sparkR = 3 + Math.sin(time / 120 + i * 1.7) * 1.5;
      ctx.beginPath();
      ctx.arc(Math.cos(sa) * sr, Math.sin(sa) * sr * 0.35, sparkR, 0, TAU);
      ctx.fill();
    }
    ctx.restore();

    // Layer 4 — Event horizon (dark void with colored rim)
    ctx.beginPath();
    ctx.arc(0, 0, eventR, 0, TAU);
    const voidGrad = ctx.createRadialGradient(0, 0, radius * 0.7, 0, 0, eventR);
    voidGrad.addColorStop(0, '#000000');
    voidGrad.addColorStop(0.7, '#000000');
    voidGrad.addColorStop(0.92, isCritical ? '#660022' : glowColor + '88');
    voidGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = voidGrad;
    ctx.fill();

    // Layer 5 — Inner glowing rim around the singularity
    ctx.beginPath();
    ctx.arc(0, 0, rimR, 0, TAU);
    ctx.strokeStyle = rimColor;
    ctx.lineWidth = 3;
    ctx.shadowBlur = 20;
    ctx.shadowColor = rimGlowColor;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Layer 6 — Pulsing energy arcs inside the void (phase 1+)
    // Optimized: single beginPath for all arcs of the same style (where possible),
    // single shadowBlur set, precompute radii once.
    if (isDamaged) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.shadowBlur = 10;
      ctx.shadowColor = rimGlowColor;
      const arcCount = 3 + phase;
      ctx.strokeStyle = isCritical ? 'rgba(255, 80, 120, 0.7)' : 'rgba(200, 120, 255, 0.6)';
      ctx.lineWidth = 2;
      // Precompute arc parameters
      const baseRot = rotation * 4;
      const t180 = time / 180;
      const t250 = time / 250;
      for (let i = 0; i < arcCount; i++) {
        const aa = baseRot + (TAU / arcCount) * i;
        const arcLen = Math.PI * (0.3 + Math.sin(t180 + i) * 0.15);
        const arcRad = radius * (0.55 + Math.sin(t250 + i) * 0.1);
        ctx.beginPath();
        ctx.arc(0, 0, arcRad, aa, aa + arcLen);
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
      ctx.restore();
    }

    // Layer 7 — Core singularity (pure black, absorbs light)
    ctx.beginPath();
    ctx.arc(0, 0, coreR, 0, TAU);
    ctx.fillStyle = '#000000';
    ctx.fill();

    // Layer 8 — Phase warning glow (pulses red when boss is near death)
    if (isCritical) {
      const warnAlpha = (Math.sin(time / 150) + 1) / 2 * 0.4;
      ctx.beginPath();
      ctx.arc(0, 0, radius * 1.4, 0, TAU);
      ctx.fillStyle = `rgba(255, 0, 51, ${warnAlpha})`;
      ctx.globalCompositeOperation = 'lighter';
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
    }

    // Flash effect (when hit)
    if (flashTimer > 0) {
      ctx.beginPath();
      ctx.arc(0, 0, radius * 1.3, 0, TAU);
      ctx.fillStyle = `rgba(255, 255, 255, ${flashAlpha * 0.85})`;
      ctx.fill();
    }

    ctx.restore();
    return;
  }
  
  if (shape !== 'blackhole') {
    // Note: Removed global shadowBlur for performance
  }

  const drawPart = (pathFn: () => void, partColor: string = color, scale: number = 1, isCore: boolean = false) => {
    ctx.save();
    ctx.beginPath();
    pathFn();
    
    if (flashTimer > 0) {
      ctx.fillStyle = `rgba(255,255,255,${flashAlpha * 0.9})`;
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = isCore ? 2 : 4;
      ctx.stroke();
    } else {
      if (isCore) {
        // Cached time (shared across all drawPart calls for this enemy)
        const now = Date.now();
        const pulse = Math.sin(rotation * 12) * 0.15 + 0.85; 
        const coreRadius = radius * scale;
        const TAU = Math.PI * 2;

        // 1. Energy Aura (Radial Gradient)
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        const auraGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, coreRadius * 3 * pulse);
        auraGrad.addColorStop(0, color);
        auraGrad.addColorStop(0.3, color + '88');
        auraGrad.addColorStop(0.7, color + '22');
        auraGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.beginPath();
        ctx.arc(0, 0, coreRadius * 3 * pulse, 0, TAU);
        ctx.fillStyle = auraGrad;
        ctx.fill();
        ctx.restore();

        // 1.5. Radiating sparks — batched: glow pass + core pass (2 fillStyle changes total)
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        const now100 = now / 100;
        // Precompute spark positions
        const sparkPositions: { x: number; y: number }[] = [];
        for (let i = 0; i < 5; i++) {
          const sparkAngle = rotation * 2 + (TAU / 5) * i;
          const sparkDist = coreRadius * 1.5 + Math.sin(now100 + i) * coreRadius;
          sparkPositions.push({ x: Math.cos(sparkAngle) * sparkDist, y: Math.sin(sparkAngle) * sparkDist });
        }
        // Glow pass (single fillStyle)
        ctx.fillStyle = color + '66';
        for (let i = 0; i < 5; i++) {
          ctx.beginPath();
          ctx.arc(sparkPositions[i].x, sparkPositions[i].y, 4 * pulse, 0, TAU);
          ctx.fill();
        }
        // Core pass (single fillStyle)
        ctx.fillStyle = '#ffffff';
        for (let i = 0; i < 5; i++) {
          ctx.beginPath();
          ctx.arc(sparkPositions[i].x, sparkPositions[i].y, 1.5 * pulse, 0, TAU);
          ctx.fill();
        }
        ctx.restore();

        // 2. Swirling Vortex — reduced from 3 layers to 2 for performance,
        // keeping the visual volume via thicker lines + fake glow.
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.rotate(rotation * 1.5);
        const now300 = now / 300;
        const sin300 = Math.sin(now300);
        const cos300 = Math.cos(now300);
        for (let layer = 0; layer < 2; layer++) {
          ctx.beginPath();
          const numArms = 3 + layer; 
          const layerRadius = coreRadius * (3.0 - layer * 0.5);
          const offset = rotation * (layer * 0.4);
          
          for (let i = 0; i < numArms; i++) {
            const a = (TAU / numArms) * i + offset;
            ctx.moveTo(0, 0);
            ctx.bezierCurveTo(
              Math.cos(a) * layerRadius * 0.3, Math.sin(a) * layerRadius * 0.3,
              Math.cos(a + 1.2) * layerRadius * 0.7, Math.sin(a + 1.2) * layerRadius * 0.7,
              Math.cos(a + 2.0) * sin300 * layerRadius, Math.sin(a + 2.0) * cos300 * layerRadius
            );
          }
          
          ctx.strokeStyle = layer === 1 ? '#ffffff' : color;
          ctx.globalAlpha = layer === 1 ? 0.2 * pulse : 0.27 * pulse;
          ctx.lineWidth = (12 - layer * 3) * pulse;
          ctx.lineCap = 'round';
          ctx.stroke();
          // Fake glow
          ctx.lineWidth = (12 - layer * 3) * pulse * 2.5;
          ctx.globalAlpha = ctx.globalAlpha * 0.3;
          ctx.stroke();
        }
        ctx.restore();

        // 3. Main Core Shape (Colored)
        const coreGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, coreRadius);
        coreGrad.addColorStop(0, '#ffffff');
        coreGrad.addColorStop(0.3, color);
        coreGrad.addColorStop(1, color);
        ctx.fillStyle = coreGrad;
        ctx.fill();
        
        ctx.strokeStyle = color + '44';
        ctx.lineWidth = 15;
        ctx.stroke();
        
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // 4. Inner Rotating Energy
        ctx.save();
        ctx.rotate(-rotation * 5);
        ctx.scale(0.6 * pulse, 0.6 * pulse);
        ctx.beginPath();
        pathFn();
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.lineWidth = 8;
        ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.restore();
        
        // 5. Center Spark
        ctx.beginPath();
        ctx.arc(0, 0, coreRadius * 0.2, 0, TAU);
        ctx.strokeStyle = 'rgba(255,255,255,0.4)';
        ctx.lineWidth = 5;
        ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.fill();
      } else {
        // Dynamic Neon Wireframe style — cached Date.now()
        const now = Date.now();
        const TAU = Math.PI * 2;
        ctx.fillStyle = partColor + '15';
        ctx.fill();

        // Fake outer glow
        const pulseGlow = Math.sin(now / 200) * 5 + 10;
        ctx.strokeStyle = partColor + '44';
        ctx.lineWidth = pulseGlow;
        ctx.stroke();

        ctx.strokeStyle = partColor;
        ctx.lineWidth = 3;
        ctx.stroke();

        // Inner geometric floating lines
        ctx.save();
        ctx.rotate(rotation * 0.5);
        ctx.beginPath();
        ctx.scale(0.8, 0.8);
        pathFn();
        ctx.strokeStyle = partColor + '88';
        ctx.setLineDash([5, 10]);
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();

        // Third layer: spinning arcs inside
        ctx.save();
        ctx.rotate(rotation * 1.5);
        ctx.beginPath();
        ctx.arc(0, 0, radius * 0.7, 0, Math.PI);
        ctx.strokeStyle = partColor + 'dd';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, radius * 0.5, Math.PI, Math.PI * 2);
        ctx.strokeStyle = '#ffffff88';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();

        // Second inner layer rotating in opposite direction
        ctx.save();
        ctx.rotate(-rotation * 0.8);
        ctx.beginPath();
        ctx.scale(0.6, 0.6);
        pathFn();
        ctx.strokeStyle = '#ffffffaa';
        ctx.lineJoin = 'round';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();

        // Glass reflection
        ctx.save();
        ctx.clip();
        ctx.beginPath();
        ctx.ellipse(-radius * 0.2 * scale, -radius * 0.4 * scale, radius * 0.8 * scale, radius * 0.4 * scale, Math.PI / 6, 0, TAU);
        const highlightGrad = ctx.createLinearGradient(-radius, -radius, radius, radius);
        highlightGrad.addColorStop(0, 'rgba(255,255,255,0.4)');
        highlightGrad.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = highlightGrad;
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.restore();
  };

  const paths: Record<string, (r: number) => void> = {
    circle: (r: number) => {
      ctx.arc(0, 0, r, 0, Math.PI * 2);
    },
    triangle: (r: number) => {
      for (let i = 0; i < 3; i++) {
        const a = (i * Math.PI * 2) / 3 - Math.PI / 2;
        if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
        else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath();
    },
    square: (r: number) => {
      ctx.rect(-r * 0.8, -r * 0.8, r * 1.6, r * 1.6);
    },
    diamond: (r: number) => {
      ctx.moveTo(0, -r);
      ctx.lineTo(r * 0.8, 0);
      ctx.lineTo(0, r);
      ctx.lineTo(-r * 0.8, 0);
      ctx.closePath();
    },
    hexagon: (r: number) => {
      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI * 2) / 6;
        if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
        else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath();
    },
    pentagon: (r: number) => {
      for (let i = 0; i < 5; i++) {
        const a = (i * Math.PI * 2) / 5 - Math.PI / 2;
        if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
        else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath();
    },
    star: (r: number) => {
      for (let i = 0; i < 10; i++) {
        const a = (i * Math.PI) / 5 - Math.PI / 2;
        const rad = i % 2 === 0 ? r : r * 0.5;
        if (i === 0) ctx.moveTo(Math.cos(a) * rad, Math.sin(a) * rad);
        else ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
      }
      ctx.closePath();
    }
  };

  // Draw outer 3D shape
  drawPart(() => paths[shape as keyof typeof paths](radius), color, 1, false);
  
  // Draw inner glowing core
  drawPart(() => paths[shape as keyof typeof paths](radius * 0.4), '#ffffff', 0.4, true);

  ctx.restore();
}