'use client';

/**
 * @fileoverview Игровой цикл SPACE ARCHER (React-хук).
 *
 * Этот хук связывает React-компонент (GameCanvas) с игровым движком (gameLogic).
 * Он запускает requestAnimationFrame цикл, который каждый кадр:
 *
 * 1. UPDATE — вызывает tick* функции из gameLogic.ts:
 *    tickSpawn → tickReload → tickPlayer → tickEnemies → tickProjectiles
 *    → tickCleanup → tickDustParticles (boss mode only)
 *
 * 2. DRAW — вызывает render* функции из gameRenderer.ts:
 *    renderBackground → renderDustParticles → renderMiniBlackHoles
 *    → renderParticles → renderShockwaves → renderGravityBeams
 *    → renderProjectiles → renderEnemies → renderBow → renderAim → renderReload
 *
 * Также обрабатывает ввод: mousemove (прицел), click/Space (выстрел), Escape (пауза).
 *
 * @see gameLogic.ts — функции обновления состояния
 * @see gameRenderer.ts — функции отрисовки
 * @see GameCanvas.tsx — где используется этот хук
 */

import { useEffect, useRef, useCallback } from 'react';
import {
  InternalGameState,
  tickSpawn,
  tickReload,
  tickPlayer,
  tickEnemies,
  tickProjectiles,
  tickCleanup,
  tickDustParticles,
  initDustParticles,
  shootProjectile,
} from './gameLogic';
import {
  renderBackground,
  renderParticles,
  renderShockwaves,
  renderDustParticles,
  renderGravityBeams,
  renderMiniBlackHoles,
  renderProjectiles,
  renderEnemies,
  renderBow,
  renderAim,
  renderReload,
} from './gameRenderer';

interface GameState {
  hp: number;
  maxHp: number;
  score: number;
  wave: number;
  arrows: number;
  maxArrows: number;
  reloading: boolean;
  reloadProgress: number;
  paused: boolean;
  enemiesKilled: number;
}

interface UseGameLoopOptions {
  canvasRef: React.RefObject<HTMLCanvasElement>;
  mousePos: React.MutableRefObject<{ x: number; y: number }>;
  animRef: React.MutableRefObject<number>;
  gameStateRef: React.MutableRefObject<InternalGameState>;
  onGameOver: (score: number, enemiesKilled: number, wave: number, doubleCoresTriggered: number) => void;
  onStateChange: (state: GameState) => void;
}

export function useGameLoop({
  canvasRef,
  mousePos,
  animRef,
  gameStateRef,
  onGameOver,
  onStateChange,
}: UseGameLoopOptions) {
  const onGameOverRef = useRef(onGameOver);
  const onStateChangeRef = useRef(onStateChange);
  const lastEmitTime = useRef(0);
  const pendingEmit = useRef<number | null>(null);

  useEffect(() => {
    onGameOverRef.current = onGameOver;
    onStateChangeRef.current = onStateChange;
  }, [onGameOver, onStateChange]);

  const emitState = useCallback((force = false) => {
    const s = gameStateRef.current;
    
    const doEmit = () => {
      onStateChangeRef.current({
        hp: s.hp,
        maxHp: s.maxHp,
        score: s.score,
        wave: s.wave,
        arrows: s.arrows,
        maxArrows: s.maxArrows,
        reloading: s.reloading,
        reloadProgress: s.reloadProgress,
        paused: s.paused,
        enemiesKilled: s.enemiesKilled,
      });
      lastEmitTime.current = performance.now();
    };

    const now = performance.now();
    if (force || now - lastEmitTime.current > 60) {
      if (pendingEmit.current) {
        clearTimeout(pendingEmit.current);
        pendingEmit.current = null;
      }
      doEmit();
    } else if (!pendingEmit.current) {
      pendingEmit.current = window.setTimeout(() => {
        pendingEmit.current = null;
        doEmit();
      }, 60);
    }
  }, [gameStateRef]);

  const shoot = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    shootProjectile(gameStateRef.current, cx, cy, mousePos.current.x, mousePos.current.y, emitState);
  }, [canvasRef, gameStateRef, mousePos, emitState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const s = gameStateRef.current;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    // Initialize ambient dust particles for boss mode
    if (s.mode === 'boss' && s.dustParticles.length === 0) {
      initDustParticles(s, canvas.width, canvas.height);
    }

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mousePos.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const handleClick = () => shoot();
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        s.paused = !s.paused;
        emitState();
      }
      if (e.code === 'Space' && !s.paused) {
        shoot();
      }
    };

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('click', handleClick);
    window.addEventListener('keydown', handleKeyDown);

    let lastTime = performance.now();
    let frames = 0;
    let fps = 0;

    const loop = (time: number) => {
      frames++;
      if (time - lastTime >= 1000) {
        fps = frames;
        frames = 0;
        lastTime = time;
      }

      if (!s.alive) return;
      
      const W = canvas.width;
      const H = canvas.height;
      const cx = W / 2;
      const cy = H / 2;

      if (!s.paused) {
        s.frame = (s.frame || 0) + 1;
        
        tickSpawn(s, W, H);
        tickReload(s, cx, cy, emitState);
        tickPlayer(s, emitState);

        if (s.shootCooldown > 0) s.shootCooldown--;
        if (s.bowPulse > 0) s.bowPulse--;

        const deadEnemies = tickEnemies(s, W, H, cx, cy, emitState, (score) => onGameOverRef.current(score, s.enemiesKilled, s.wave, s.doubleCoresTriggered));
        
        let bossDefeated = false;
        tickProjectiles(s, W, H, deadEnemies, emitState, () => { bossDefeated = true; });
        
        tickCleanup(s, W, H, deadEnemies);

        // Update ambient dust particles (boss mode only)
        if (s.mode === 'boss') {
          tickDustParticles(s, W, H);
        }
        
        if (bossDefeated) {
          onGameOverRef.current(s.score, s.enemiesKilled, s.wave, s.doubleCoresTriggered);
        }
      }

      // Draw
      renderBackground(ctx, W, H, s.frame, cx, cy);
      renderDustParticles(ctx, s.dustParticles);
      renderMiniBlackHoles(ctx, s.miniBlackHoles);
      renderParticles(ctx, s.particles);
      renderShockwaves(ctx, s.activeShockwaves);
      renderGravityBeams(ctx, s.bossGravityBeams);
      renderProjectiles(ctx, s.projectiles);
      renderEnemies(ctx, s.enemies);
      renderBow(ctx, cx, cy, mousePos.current.x, mousePos.current.y, s);
      renderAim(ctx, cx, cy, mousePos.current.x, mousePos.current.y);
      if (s.reloading) renderReload(ctx, cx, cy, s.reloadProgress);

      ctx.fillStyle = '#00ffff';
      ctx.font = '12px "Orbitron", sans-serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'bottom';
      ctx.fillText(`FPS: ${fps}`, W - 10, H - 10);

      animRef.current = requestAnimationFrame(loop);
    };

    animRef.current = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('click', handleClick);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [shoot, emitState, canvasRef, gameStateRef, mousePos, animRef]);
}
