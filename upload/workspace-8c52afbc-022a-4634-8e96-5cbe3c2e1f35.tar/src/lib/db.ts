/**
 * @fileoverview Prisma Client (singleton).
 *
 * Используется во всех API маршрутах для доступа к SQLite базе данных.
 * В development режиме кэшируется в globalThis, чтобы не создавать
 * новые подключения при hot-reload.
 *
 * Логи: ['error', 'warn'] — только ошибки и предупреждения (без query-логов).
 *
 * @see prisma/schema.prisma — схема БД (User, LeaderboardEntry)
 */

import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['error', 'warn'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db