'use client';

// Local storage-based mock replacing Firebase Auth + Firestore.
// The original game used Firebase for user auth, progress sync, and leaderboard.
// In this sandbox preview environment, Google sign-in popups and cross-domain
// Firestore access don't work reliably, so we persist everything locally.

import type { GameProgress } from '@/types/game';

export interface LocalUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  emailVerified: boolean;
  isAnonymous: boolean;
}

export interface UserDoc {
  uid: string;
  email: string;
  displayName: string;
  createdAt: { seconds: number; nanoseconds: number };
  progress: GameProgress;
  stats: {
    highScore: number;
    maxWave: number;
    gamesPlayed: number;
    totalEnemiesKilled: number;
  };
  role: 'user' | 'admin';
}

export interface LeaderEntry {
  id: string;
  uid: string;
  name: string;
  score: number;
  wave: number;
  timestamp: { seconds: number; nanoseconds: number };
}

const USERS_KEY = 'neon_archer_users';
const LBOARD_KEY = 'neon_archer_leaderboard';
const SESSION_KEY = 'neon_archer_session';

function readUsers(): Record<string, UserDoc> {
  if (typeof window === 'undefined') return {};
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
  } catch {
    return {};
  }
}

function writeUsers(users: Record<string, UserDoc>) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function readLeaderboard(): LeaderEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    return JSON.parse(localStorage.getItem(LBOARD_KEY) || '[]');
  } catch {
    return [];
  }
}

function writeLeaderboard(entries: LeaderEntry[]) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(LBOARD_KEY, JSON.stringify(entries));
}

function nowTimestamp() {
  const ms = Date.now();
  return { seconds: Math.floor(ms / 1000), nanoseconds: (ms % 1000) * 1e6 };
}

function defaultProgress(): GameProgress {
  return {
    cores: 0,
    upgrades: {
      baseNode: 0,
      damage: 0,
      maxArrows: 0,
      reloadSpeed: 0,
      maxHp: 0,
      regenSpeed: 0,
      coreBonus: 0,
      piercing: 0,
      projectileSpeed: 0,
      critChance: 0,
      critDamage: 0,
      defense: 0,
      magnetArrow: 0,
      shockwave: 0,
      doubleCores: 0,
    },
  };
}

// ---------- Auth ----------

const ADMIN_EMAIL = 'natalya.atamankina1@yandex.ru';

export function getSessionUser(): LocalUser | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as LocalUser) : null;
  } catch {
    return null;
  }
}

export function signInWithDisplayName(name: string): LocalUser {
  const cleanName = name.trim() || 'Пилот';
  const uid = 'local-' + cleanName.toLowerCase().replace(/[^a-zа-я0-9]+/gi, '-').slice(0, 16) + '-' + Math.abs(hashCode(cleanName)).toString(36);
  const lower = cleanName.toLowerCase();
  const isAdmin = lower === ADMIN_EMAIL.toLowerCase() || lower.includes('natalya.atamankina1') || uid.includes('admin');
  const user: LocalUser = {
    uid,
    email: isAdmin ? ADMIN_EMAIL : `${cleanName.toLowerCase().replace(/\s+/g, '.')}@local.game`,
    displayName: cleanName,
    photoURL: null,
    emailVerified: true,
    isAnonymous: false,
  };
  if (typeof window !== 'undefined') {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  }

  // Ensure a user doc exists
  const users = readUsers();
  if (!users[uid]) {
    users[uid] = {
      uid,
      email: user.email || 'no-email@local.game',
      displayName: cleanName,
      createdAt: nowTimestamp(),
      progress: defaultProgress(),
      stats: { highScore: 0, maxWave: 1, gamesPlayed: 0, totalEnemiesKilled: 0 },
      role: isAdmin ? 'admin' : 'user',
    };
    writeUsers(users);
  }
  return user;
}

export function signOutLocal() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(SESSION_KEY);
  }
}

function hashCode(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  }
  return h;
}

// ---------- User doc operations ----------

export function getUserDoc(uid: string): UserDoc | null {
  const users = readUsers();
  return users[uid] || null;
}

export function getAllUsers(): UserDoc[] {
  return Object.values(readUsers());
}

export function setUserProgress(uid: string, progress: GameProgress) {
  const users = readUsers();
  if (users[uid]) {
    users[uid].progress = progress;
    writeUsers(users);
  }
}

export function updateUserStats(
  uid: string,
  stats: Partial<UserDoc['stats']>,
) {
  const users = readUsers();
  if (users[uid]) {
    users[uid].stats = { ...users[uid].stats, ...stats };
    writeUsers(users);
  }
}

export function ensureUserDoc(uid: string, fallback: { email: string; displayName: string }): UserDoc {
  const users = readUsers();
  if (!users[uid]) {
    users[uid] = {
      uid,
      email: fallback.email,
      displayName: fallback.displayName.slice(0, 50),
      createdAt: nowTimestamp(),
      progress: defaultProgress(),
      stats: { highScore: 0, maxWave: 1, gamesPlayed: 0, totalEnemiesKilled: 0 },
      role: 'user',
    };
    writeUsers(users);
  } else {
    // Migrate old user docs: ensure all upgrade fields exist
    const defaults = defaultProgress();
    let migrated = false;
    if (!users[uid].progress) {
      users[uid].progress = defaults;
      migrated = true;
    } else if (!users[uid].progress.upgrades) {
      users[uid].progress.upgrades = defaults.upgrades;
      migrated = true;
    } else {
      const merged = { ...defaults.upgrades, ...users[uid].progress.upgrades };
      if (JSON.stringify(merged) !== JSON.stringify(users[uid].progress.upgrades)) {
        users[uid].progress.upgrades = merged;
        migrated = true;
      }
    }
    if (!users[uid].stats) {
      users[uid].stats = { highScore: 0, maxWave: 1, gamesPlayed: 0, totalEnemiesKilled: 0 };
      migrated = true;
    }
    if (migrated) writeUsers(users);
  }
  return users[uid];
}

export function updateUserDoc(uid: string, patch: Partial<UserDoc>) {
  const users = readUsers();
  if (users[uid]) {
    users[uid] = { ...users[uid], ...patch };
    writeUsers(users);
  }
}

export function deleteUserDoc(uid: string) {
  const users = readUsers();
  delete users[uid];
  writeUsers(users);
}

export function getUserRole(uid: string): 'user' | 'admin' {
  const u = getUserDoc(uid);
  return u?.role || 'user';
}

// ---------- Leaderboard ----------

export function getLeaderboard(limit = 10): LeaderEntry[] {
  const entries = readLeaderboard();
  entries.sort((a, b) => b.score - a.score);
  return entries.slice(0, limit);
}

export function addLeaderboardEntry(entry: Omit<LeaderEntry, 'id' | 'timestamp'>) {
  const entries = readLeaderboard();
  const newEntry: LeaderEntry = {
    ...entry,
    id: 'lb-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8),
    timestamp: nowTimestamp(),
  };
  entries.push(newEntry);
  // Keep only top 50 to avoid unbounded growth
  entries.sort((a, b) => b.score - a.score);
  writeLeaderboard(entries.slice(0, 50));
  return newEntry;
}

export function formatDate(ts: { seconds: number; nanoseconds: number } | null | undefined): string {
  if (!ts) return 'Неизвестно';
  try {
    return new Date(ts.seconds * 1000).toLocaleDateString('ru-RU');
  } catch {
    return 'Неизвестно';
  }
}
