'use client';

/**
 * @fileoverview Клиентские API-функции (обёртки над fetch).
 *
 * Используются в React-компонентах для общения с сервером:
 * - updateProgressAPI: PUT /api/user/progress — синхронизация прогресса
 * - saveScoreAPI: POST /api/leaderboard — сохранение рекорда
 * - fetchLeaderboardAPI: GET /api/leaderboard — загрузка таблицы лидеров
 * - signOutAPI: POST /api/auth/logout — выход из аккаунта
 *
 * Все функции используют credentials: 'include' для отправки session cookie.
 *
 * @see app/api/ — серверные маршруты
 */

import type { GameProgress } from '@/types/game';

// Update the user's progress in the database via API.
// Optimistic: the caller updates local state first, then this syncs to DB.
export async function updateProgressAPI(progress: GameProgress): Promise<void> {
  try {
    await fetch('/api/user/progress', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({
        cores: progress.cores,
        upgrades: progress.upgrades,
        stats: progress.stats,
      }),
    });
  } catch (err) {
    console.error('Failed to sync progress to DB:', err);
  }
}

// Save a score to the leaderboard via API.
export async function saveScoreAPI(name: string, score: number, wave: number): Promise<boolean> {
  try {
    const res = await fetch('/api/leaderboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ name, score, wave }),
    });
    return res.ok;
  } catch (err) {
    console.error('Failed to save score:', err);
    return false;
  }
}

// Fetch the leaderboard from the API.
export async function fetchLeaderboardAPI(): Promise<{ id: string; name: string; score: number; wave: number; date: string }[]> {
  try {
    const res = await fetch('/api/leaderboard', { credentials: 'include' });
    const data = await res.json();
    return data.entries || [];
  } catch {
    return [];
  }
}

// Sign out via API.
export async function signOutAPI(): Promise<void> {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  } catch {
    // ignore
  }
}
