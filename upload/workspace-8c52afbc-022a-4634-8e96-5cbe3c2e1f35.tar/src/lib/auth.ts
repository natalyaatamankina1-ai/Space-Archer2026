/**
 * @fileoverview Серверная логика аутентификации.
 *
 * Содержит:
 * - hashPassword/verifyPassword — хеширование через bcryptjs (10 раундов)
 * - createSessionToken/verifySessionToken — подписанные HMAC-SHA256 токены
 * - getUserFromRequest — извлечение пользователя из cookie
 * - getSessionCookieName — имя cookie для сессии
 *
 * Токен имеет формат: base64url(userId) + "." + HMAC-SHA256(base64url(userId))
 * Это НЕ JWT — легковесная альтернатива без внешних зависимостей.
 *
 * @see app/api/auth/register, login, logout, me — где используются эти функции
 */

import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';

const SESSION_SECRET = process.env.SESSION_SECRET || 'space-archer-dev-secret-key-change-in-prod';
const SESSION_COOKIE_NAME = 'sa_session';

function base64UrlEncode(str: string): string {
  return Buffer.from(str).toString('base64url');
}

function base64UrlDecode(str: string): string {
  return Buffer.from(str, 'base64url').toString('utf8');
}

async function sign(data: string): Promise<string> {
  const crypto = await import('crypto');
  const hmac = crypto.createHmac('sha256', SESSION_SECRET);
  hmac.update(data);
  return hmac.digest('base64url');
}

export async function createSessionToken(userId: string): Promise<string> {
  const payload = base64UrlEncode(userId);
  const sig = await sign(payload);
  return `${payload}.${sig}`;
}

export async function verifySessionToken(token: string | undefined | null): Promise<string | null> {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expectedSig = await sign(payload);
  if (sig !== expectedSig) return null;
  try {
    return base64UrlDecode(payload);
  } catch {
    return null;
  }
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function getSessionCookieName(): string {
  return SESSION_COOKIE_NAME;
}

export interface SessionUser {
  id: string;
  email: string;
  displayName: string;
  role: string;
}

export async function getUserFromRequest(request: Request): Promise<SessionUser | null> {
  const cookieHeader = request.headers.get('cookie') || '';
  const cookies = Object.fromEntries(
    cookieHeader.split('; ').map(c => {
      const [k, ...v] = c.split('=');
      return [k, v.join('=')];
    })
  );
  const token = cookies[SESSION_COOKIE_NAME];
  const userId = await verifySessionToken(token);
  if (!userId) return null;

  const user = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, displayName: true, role: true },
  });
  return user;
}
