'use client';

/**
 * @fileoverview AuthContext — контекст аутентификации.
 *
 * Предоставляет:
 * - user: текущий пользователь (null если не авторизован)
 * - loading: true во время загрузки (показывается экран «ЗАГРУЗКА СИСТЕМЫ...»)
 * - isAdmin: true для админов (показывает кнопку админ-панели)
 * - progress: прогресс из БД (cores, upgrades, stats)
 * - refreshAuth(): перезагрузка состояния из API (вызывается после login/register)
 *
 * Использует httpOnly cookie для сессии (устанавливается сервером при login/register).
 *
 * @see lib/auth.ts — серверная логика (токены, хеширование)
 * @see app/api/auth/me — API endpoint для получения текущего пользователя
 */

import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { GameProgress } from '@/types/game';

export interface SessionUser {
  id: string;
  email: string;
  displayName: string;
  role: string;
  photoURL: null;
  emailVerified: boolean;
  isAnonymous: boolean;
}

interface AuthContextType {
  user: SessionUser | null;
  loading: boolean;
  isAdmin: boolean;
  progress: GameProgress | null;
  refreshAuth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  isAdmin: false,
  progress: null,
  refreshAuth: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [progress, setProgress] = useState<GameProgress | null>(null);

  const refreshAuth = useCallback(async () => {
    // Set loading true during refresh so the UI shows a loading state
    // instead of briefly flashing the auth screen.
    setLoading(true);
    try {
      const res = await fetch('/api/auth/me', { credentials: 'include' });
      const data = await res.json();
      if (data.user) {
        const u = data.user;
        setUser({
          id: u.id,
          email: u.email,
          displayName: u.displayName,
          role: u.role,
          photoURL: null,
          emailVerified: true,
          isAnonymous: false,
        });
        setIsAdmin(u.role === 'admin');
        setProgress({
          cores: u.cores,
          upgrades: u.upgrades,
          stats: u.stats,
        });
      } else {
        setUser(null);
        setIsAdmin(false);
        setProgress(null);
      }
    } catch {
      setUser(null);
      setIsAdmin(false);
      setProgress(null);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    refreshAuth();
  }, [refreshAuth]);

  return (
    <AuthContext.Provider value={{ user, loading, isAdmin, progress, refreshAuth }}>
      {children}
    </AuthContext.Provider>
  );
}
